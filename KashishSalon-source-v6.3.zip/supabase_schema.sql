-- ============================================================
-- Kashish Beauty Salon — backend tables
-- Supabase Dashboard → SQL Editor → New query → paste → Run
-- Sirf ek baar chalana hai
-- ============================================================

create table if not exists services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text default '',
  price int not null,
  duration_min int not null default 30,
  category text not null default 'general',
  active boolean not null default true,
  created_at timestamptz default now()
);

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null unique,
  loyalty_points int not null default 0,
  total_visits int not null default 0,
  created_at timestamptz default now()
);

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  customer_phone text not null,
  service_id uuid references services(id),
  service_name text not null,
  price int not null,
  booking_date date not null,
  time_slot text not null,
  status text not null default 'pending',
  payment_method text not null default 'cash',
  payment_status text not null default 'unpaid',
  payment_tid text default '',
  receipt_url text default '',
  loyalty_earned int not null default 0,
  loyalty_redeemed int not null default 0,
  notes text default '',
  created_at timestamptz default now(),
  unique (booking_date, time_slot)
);

create table if not exists loyalty_config (
  id int primary key,
  points_per_100rs int not null default 1,
  redeem_points int not null default 100,
  redeem_value_rs int not null default 100,
  min_redeem_points int not null default 100,
  updated_at timestamptz default now()
);
insert into loyalty_config (id) values (1) on conflict (id) do nothing;

-- Security: app ki public key se access (booking app ke liye)
alter table services enable row level security;
alter table customers enable row level security;
alter table bookings enable row level security;
alter table loyalty_config enable row level security;

create policy "public all" on services for all using (true) with check (true);
create policy "public all" on customers for all using (true) with check (true);
create policy "public all" on bookings for all using (true) with check (true);
create policy "public read" on loyalty_config for select using (true);
create policy "public update" on loyalty_config for update using (true) with check (true);
