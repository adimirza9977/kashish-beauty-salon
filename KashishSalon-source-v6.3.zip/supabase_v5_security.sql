-- ============================================================
-- Kashish Beauty Salon — v5.0 SECURITY HARDENING
-- Run ONCE in Supabase Dashboard → SQL Editor → New query → Run
-- Safe to re-run (all statements idempotent).
--
-- What this does:
--  1. LOCKS DOWN row-level security: the old "public all" policies
--     (anyone with the app's public key could read/write EVERYTHING:
--     customer phone numbers, bookings, loyalty points, prices) are
--     replaced with least-privilege read-only policies.
--  2. Moves every SENSITIVE operation into SECURITY DEFINER functions
--     that validate on the server: owner PIN check, customer
--     signup/login, booking placement (coupon + loyalty validated
--     server-side), loyalty award (with audit ledger), owner actions
--     (behind a 12-hour session token).
--  3. The owner PIN hash can no longer be read by anyone.
--  4. Storage uploads restricted to image files only.
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- new tables ----------
create table if not exists owner_sessions (
  token uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  expires_at timestamptz default now() + interval '12 hours'
);

create table if not exists loyalty_ledger (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references customers(id) on delete cascade,
  points int not null,
  reason text default '',
  ref text default '',
  created_at timestamptz default now()
);

alter table owner_sessions enable row level security;
alter table loyalty_ledger enable row level security;
-- no anon policies on these two: functions only.

-- ---------- helper: valid owner token ----------
create or replace function owner_check(p_token uuid)
returns boolean
language sql security definer set search_path = public
as $$
  select exists (
    select 1 from owner_sessions
    where token = p_token and expires_at > now()
  );
$$;

-- ---------- owner login (PIN never leaves the server) ----------
create or replace function owner_login(p_pin text)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_hash text;
  v_tok uuid;
begin
  select value into v_hash from salon_settings where key = 'owner_pin_hash';
  if v_hash is null then
    -- first run ever: accept default 1234 and store its hash
    v_hash := encode(digest('kashish-pin:1234', 'sha256'), 'hex');
    insert into salon_settings(key, value)
    values ('owner_pin_hash', v_hash)
    on conflict (key) do nothing;
  end if;
  if v_hash = encode(digest('kashish-pin:' || coalesce(p_pin, ''), 'sha256'), 'hex') then
    -- prune old sessions, issue a new 12h token
    delete from owner_sessions where expires_at < now();
    insert into owner_sessions(token) values (gen_random_uuid()) returning token into v_tok;
    return v_tok;
  end if;
  return null;
end;
$$;

-- ============================================================
-- owner_action: EVERY owner write goes through here.
-- p_action is whitelisted; anything else is rejected.
-- ============================================================
create or replace function owner_action(p_token uuid, p_action text, p_data jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  d jsonb := coalesce(p_data, '{}'::jsonb);
  v_id uuid;
begin
  if not owner_check(p_token) then
    return jsonb_build_object('error', 'bad-token');
  end if;

  case p_action
    -- ----- services -----
    when 'svc_upsert' then
      if (d->>'id') is null then
        insert into services(name, description, price, duration_min, category, image_url, is_featured, active)
        values (d->>'name', coalesce(d->>'description',''),
                (d->>'price')::int, coalesce((d->>'duration_min')::int, 30),
                coalesce(d->>'category','general'), nullif(d->>'image_url',''),
                coalesce((d->>'is_featured')::boolean, false),
                coalesce((d->>'active')::boolean, true))
        returning id into v_id;
      else
        update services set
          name = coalesce(d->>'name', name),
          description = coalesce(d->>'description', description),
          price = coalesce((d->>'price')::int, price),
          duration_min = coalesce((d->>'duration_min')::int, duration_min),
          category = coalesce(d->>'category', category),
          image_url = case when d ? 'image_url' then nullif(d->>'image_url','') else image_url end,
          is_featured = coalesce((d->>'is_featured')::boolean, is_featured),
          active = coalesce((d->>'active')::boolean, active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);

    when 'svc_delete' then
      update services set active = false where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- gallery -----
    when 'gal_add' then
      insert into gallery(image_url, caption, sort_order)
      values (d->>'image_url', coalesce(d->>'caption',''), coalesce((d->>'sort_order')::int, 0))
      returning id into v_id;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'gal_delete' then
      delete from gallery where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- offers -----
    when 'offer_upsert' then
      if (d->>'id') is null then
        insert into offers(title, description, discount_text, image_url, valid_till, terms, is_active)
        values (d->>'title', coalesce(d->>'description',''), coalesce(d->>'discount_text',''),
                nullif(d->>'image_url',''), nullif(d->>'valid_till','')::date,
                coalesce(d->>'terms',''), coalesce((d->>'is_active')::boolean, true))
        returning id into v_id;
      else
        update offers set
          title = coalesce(d->>'title', title),
          description = coalesce(d->>'description', description),
          discount_text = coalesce(d->>'discount_text', discount_text),
          image_url = case when d ? 'image_url' then nullif(d->>'image_url','') else image_url end,
          valid_till = case when d ? 'valid_till' then nullif(d->>'valid_till','')::date else valid_till end,
          terms = coalesce(d->>'terms', terms),
          is_active = coalesce((d->>'is_active')::boolean, is_active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'offer_delete' then
      delete from offers where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- coupons -----
    when 'coupon_upsert' then
      if (d->>'id') is null then
        insert into coupons(code, discount_percent, discount_rs, min_amount, valid_till, is_active)
        values (upper(d->>'code'), (d->>'discount_percent')::int, (d->>'discount_rs')::int,
                coalesce((d->>'min_amount')::int, 0),
                nullif(d->>'valid_till','')::date,
                coalesce((d->>'is_active')::boolean, true))
        returning id into v_id;
      else
        update coupons set
          code = coalesce(upper(d->>'code'), code),
          discount_percent = case when d ? 'discount_percent' then (d->>'discount_percent')::int else discount_percent end,
          discount_rs = case when d ? 'discount_rs' then (d->>'discount_rs')::int else discount_rs end,
          min_amount = coalesce((d->>'min_amount')::int, min_amount),
          valid_till = case when d ? 'valid_till' then nullif(d->>'valid_till','')::date else valid_till end,
          is_active = coalesce((d->>'is_active')::boolean, is_active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'coupon_delete' then
      delete from coupons where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- beauticians -----
    when 'beaut_upsert' then
      if (d->>'id') is null then
        insert into beauticians(name, specialty, is_active)
        values (d->>'name', coalesce(d->>'specialty',''), coalesce((d->>'is_active')::boolean, true))
        returning id into v_id;
      else
        update beauticians set
          name = coalesce(d->>'name', name),
          specialty = coalesce(d->>'specialty', specialty),
          is_active = coalesce((d->>'is_active')::boolean, is_active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'beaut_delete' then
      delete from beauticians where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- bookings (owner views / manages) -----
    when 'booking_list' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from bookings order by booking_date desc, time_slot desc
        limit coalesce((d->>'limit')::int, 200)) t);
    when 'booking_by_date' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from bookings
        where booking_date = (d->>'date')::date and status <> 'cancelled'
        order by time_slot) t);
    when 'pending_payments' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from bookings where payment_status = 'proof_submitted'
        order by created_at desc) t);
    when 'booking_status' then
      update bookings set status = d->>'status' where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'booking_payment' then
      update bookings set payment_status = d->>'payment_status' where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- customers (owner views / manages) -----
    when 'customers_list' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select id, name, phone, whatsapp, loyalty_points, total_visits, created_at
        from customers order by total_visits desc, loyalty_points desc limit 300) t);
    when 'customer_delete' then
      delete from customers where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    -- ----- loyalty: owner awards points (ledger + balance, atomic) -----
    when 'loyalty_award' then
      if coalesce((d->>'points')::int, 0) = 0 then
        return jsonb_build_object('error', 'no-points');
      end if;
      if abs((d->>'points')::int) > 10000 then
        return jsonb_build_object('error', 'points-range');
      end if;
      update customers set loyalty_points = loyalty_points + (d->>'points')::int
      where id = (d->>'id')::uuid;
      insert into loyalty_ledger(customer_id, points, reason, ref)
      values ((d->>'id')::uuid, (d->>'points')::int,
              coalesce(d->>'reason','owner award'), coalesce(d->>'ref',''));
      return (select jsonb_build_object('ok', true, 'loyalty_points', loyalty_points)
              from customers where id = (d->>'id')::uuid);
    when 'loyalty_ledger' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from loyalty_ledger
        where ((d->>'customer_id') is null or customer_id = (d->>'customer_id')::uuid)
        order by created_at desc limit 100) t);

    -- ----- loyalty config -----
    when 'loyalty_config_save' then
      update loyalty_config set
        points_per_100rs = coalesce((d->>'points_per_100rs')::int, points_per_100rs),
        redeem_points = coalesce((d->>'redeem_points')::int, redeem_points),
        redeem_value_rs = coalesce((d->>'redeem_value_rs')::int, redeem_value_rs),
        min_redeem_points = coalesce((d->>'min_redeem_points')::int, min_redeem_points),
        updated_at = now()
      where id = 1;
      return jsonb_build_object('ok', true);

    -- ----- settings (PIN hash is blocklisted here) -----
    when 'setting_set' then
      if d->>'key' = 'owner_pin_hash' then
        return jsonb_build_object('error', 'blocked-key');
      end if;
      insert into salon_settings(key, value, updated_at)
      values (d->>'key', d->>'value', now())
      on conflict (key) do update set value = excluded.value, updated_at = now();
      return jsonb_build_object('ok', true);
    when 'pin_change' then
      if encode(digest('kashish-pin:' || coalesce(d->>'old_pin',''), 'sha256'), 'hex')
         <> (select value from salon_settings where key = 'owner_pin_hash') then
        return jsonb_build_object('error', 'wrong-pin');
      end if;
      update salon_settings set
        value = encode(digest('kashish-pin:' || (d->>'new_pin'), 'sha256'), 'hex'),
        updated_at = now()
      where key = 'owner_pin_hash';
      delete from owner_sessions where token <> p_token; -- log out other devices
      return jsonb_build_object('ok', true);

    -- ----- password-reset requests -----
    when 'reset_list' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select id, phone, otp, expires_at, used, created_at from password_resets
        where used = false and expires_at > now()
        order by created_at desc limit 50) t);
    when 'reset_dismiss' then
      delete from password_resets where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    else
      return jsonb_build_object('error', 'unknown-action');
  end case;
end;
$$;

-- ============================================================
-- CUSTOMER functions
-- ============================================================

create or replace function customer_signup(p_name text, p_phone text, p_whatsapp text, p_hash text)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  c customers%rowtype;
begin
  if p_phone is null or length(regexp_replace(p_phone, '\D', '', 'g')) < 10 then
    return jsonb_build_object('error', 'bad-phone');
  end if;
  if p_hash is null or length(p_hash) <> 64 then
    return jsonb_build_object('error', 'bad-hash');
  end if;
  insert into customers(name, phone, whatsapp, password_hash, loyalty_points, total_visits)
  values (left(coalesce(p_name,'Customer'), 80), p_phone,
          coalesce(p_whatsapp,''), p_hash, 0, 0)
  on conflict (phone) do nothing
  returning * into c;
  if c.id is null then
    return jsonb_build_object('error', 'phone-exists');
  end if;
  return jsonb_build_object('id', c.id, 'name', c.name, 'phone', c.phone);
end;
$$;

create or replace function customer_login(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select jsonb_build_object(
      'id', id, 'name', name, 'phone', phone, 'whatsapp', whatsapp,
      'loyalty_points', loyalty_points, 'total_visits', total_visits)
  from customers
  where phone = p_phone and password_hash = p_hash
  limit 1;
$$;

create or replace function customer_get(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select jsonb_build_object(
      'id', id, 'name', name, 'phone', phone, 'whatsapp', whatsapp,
      'loyalty_points', loyalty_points, 'total_visits', total_visits)
  from customers
  where phone = p_phone and password_hash = p_hash
  limit 1;
$$;

create or replace function customer_set_whatsapp(p_phone text, p_hash text, p_wa text)
returns boolean
language plpgsql security definer set search_path = public
as $$
begin
  update customers set whatsapp = left(coalesce(p_wa,''), 30)
  where phone = p_phone and password_hash = p_hash;
  return found;
end;
$$;

-- ---------- coupon validation (server-side) ----------
create or replace function validate_coupon(p_code text, p_amount int)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  c coupons%rowtype;
  v_disc int := 0;
begin
  if p_code is null or p_code = '' then
    return jsonb_build_object('valid', false, 'discount_rs', 0, 'reason', 'empty');
  end if;
  select * into c from coupons
  where code = upper(p_code) and is_active = true limit 1;
  if c.id is null then
    return jsonb_build_object('valid', false, 'discount_rs', 0, 'reason', 'invalid');
  end if;
  if c.valid_till is not null and c.valid_till < current_date then
    return jsonb_build_object('valid', false, 'discount_rs', 0, 'reason', 'expired');
  end if;
  if coalesce(p_amount, 0) < coalesce(c.min_amount, 0) then
    return jsonb_build_object('valid', false, 'discount_rs', 0, 'reason', 'min-amount');
  end if;
  if coalesce(c.discount_percent, 0) > 0 then
    v_disc := floor(coalesce(p_amount,0) * c.discount_percent / 100);
  else
    v_disc := coalesce(c.discount_rs, 0);
  end if;
  v_disc := least(v_disc, coalesce(p_amount, 0));
  return jsonb_build_object('valid', true, 'discount_rs', v_disc,
                            'code', c.code, 'reason', 'ok');
end;
$$;

-- ---------- booking placement (EVERYTHING validated server-side) ----------
create or replace function place_booking(p_data jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  d jsonb := p_data;
  c customers%rowtype;
  s services%rowtype;
  cfg loyalty_config%rowtype;
  v_price int;
  v_coupon jsonb;
  v_coupon_disc int := 0;
  v_coupon_code text := '';
  v_redeem_pts int := 0;
  v_redeem_disc int := 0;
  v_total int;
  v_earned int;
  v_ref text;
  v_bid uuid;
begin
  -- auth the customer
  select * into c from customers
  where phone = d->>'customer_phone' and password_hash = d->>'password_hash' limit 1;
  if c.id is null then
    return jsonb_build_object('error', 'auth');
  end if;

  -- service must exist, be active; PRICE comes from the server, never the client
  select * into s from services
  where id = (d->>'service_id')::uuid and active = true limit 1;
  if s.id is null then
    return jsonb_build_object('error', 'bad-service');
  end if;
  v_price := s.price;

  -- coupon validated server-side
  if coalesce(d->>'coupon_code','') <> '' then
    v_coupon := validate_coupon(d->>'coupon_code', v_price);
    if not (v_coupon->>'valid')::boolean then
      return jsonb_build_object('error', 'bad-coupon',
                                'reason', v_coupon->>'reason');
    end if;
    v_coupon_disc := (v_coupon->>'discount_rs')::int;
    v_coupon_code := v_coupon->>'code';
  end if;

  -- loyalty redeem validated server-side
  select * into cfg from loyalty_config where id = 1;
  v_redeem_pts := coalesce((d->>'redeem_points')::int, 0);
  if v_redeem_pts > 0 then
    if v_redeem_pts > c.loyalty_points then
      return jsonb_build_object('error', 'not-enough-points');
    end if;
    if v_redeem_pts < cfg.min_redeem_points
       or v_redeem_pts % cfg.redeem_points <> 0 then
      return jsonb_build_object('error', 'bad-redeem');
    end if;
    v_redeem_disc := (v_redeem_pts / cfg.redeem_points) * cfg.redeem_value_rs;
  end if;

  v_total := greatest(v_price - v_coupon_disc - least(v_redeem_disc, v_price - v_coupon_disc), 0);
  v_earned := floor(v_total / 100) * cfg.points_per_100rs;

  -- unique ref code
  loop
    v_ref := 'KBS-' || upper(substr(md5(random()::text), 1, 6));
    exit when not exists (select 1 from bookings where ref_code = v_ref);
  end loop;

  -- slot conflict guard (unique constraint is the final arbiter)
  if exists (select 1 from bookings
             where booking_date = (d->>'booking_date')::date
               and time_slot = d->>'time_slot'
               and status <> 'cancelled') then
    return jsonb_build_object('error', 'slot-taken');
  end if;

  begin
    insert into bookings(customer_name, customer_phone, service_id, service_name,
        price, booking_date, time_slot, ref_code, beautician_id,
        coupon_code, discount_rs, status, payment_method, payment_status,
        payment_tid, loyalty_earned, loyalty_redeemed, notes)
    values (left(coalesce(d->>'customer_name', c.name), 80), c.phone, s.id, s.name,
        v_total, (d->>'booking_date')::date, d->>'time_slot', v_ref,
        nullif(d->>'beautician_id','')::uuid,
        v_coupon_code, v_coupon_disc, 'pending',
        coalesce(d->>'payment_method','cash'),
        case when coalesce(d->>'payment_method','cash') = 'cash' then 'unpaid' else 'proof_submitted' end,
        left(coalesce(d->>'payment_tid',''), 60),
        v_earned, v_redeem_pts,
        left(coalesce(d->>'notes',''), 500))
    returning id into v_bid;
  exception when unique_violation then
    return jsonb_build_object('error', 'slot-taken');
  end;

  -- loyalty: atomic balance update + ledger
  update customers set
    loyalty_points = loyalty_points + v_earned - v_redeem_pts,
    total_visits = total_visits + 1
  where id = c.id;
  if v_earned > 0 then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (c.id, v_earned, 'booking earned', v_ref);
  end if;
  if v_redeem_pts > 0 then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (c.id, -v_redeem_pts, 'booking redeemed', v_ref);
  end if;

  return jsonb_build_object('ok', true, 'ref_code', v_ref, 'booking_id', v_bid,
                            'total', v_total, 'earned', v_earned);
end;
$$;

-- ---------- my bookings / cancel / rate ----------
create or replace function my_bookings(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select case when exists (select 1 from customers
                           where phone = p_phone and password_hash = p_hash)
    then coalesce((select jsonb_agg(t order by booking_date desc, time_slot desc)
                   from (select * from bookings
                         where customer_phone = p_phone
                         order by booking_date desc, time_slot desc limit 100) t),
                 '[]'::jsonb)
    else jsonb_build_object('error', 'auth')
  end;
$$;

create or replace function cancel_booking(p_ref text, p_phone text, p_hash text)
returns boolean
language plpgsql security definer set search_path = public
as $$
begin
  if not exists (select 1 from customers
                 where phone = p_phone and password_hash = p_hash) then
    return false;
  end if;
  update bookings set status = 'cancelled'
  where ref_code = p_ref and customer_phone = p_phone
    and status in ('pending', 'confirmed');
  return found;
end;
$$;

create or replace function rate_service(p_ref text, p_phone text, p_hash text,
                                        p_rating int, p_review text)
returns boolean
language plpgsql security definer set search_path = public
as $$
begin
  if p_rating < 1 or p_rating > 5 then return false; end if;
  if not exists (select 1 from customers
                 where phone = p_phone and password_hash = p_hash) then
    return false;
  end if;
  update bookings set rating = p_rating, review = left(coalesce(p_review,''), 500)
  where ref_code = p_ref and customer_phone = p_phone and status = 'completed';
  return found;
end;
$$;

-- ---------- public reads that must not leak PII ----------
create or replace function slots_taken(p_date date)
returns jsonb
language sql security definer set search_path = public
as $$
  select coalesce(jsonb_agg(time_slot), '[]'::jsonb) from bookings
  where booking_date = p_date and status <> 'cancelled';
$$;

create or replace function service_reviews(p_service_id uuid)
returns jsonb
language sql security definer set search_path = public
as $$
  select coalesce(jsonb_agg(t), '[]'::jsonb) from (
    select rating, review, customer_name, created_at from bookings
    where service_id = p_service_id and rating is not null and status = 'completed'
    order by created_at desc limit 20) t;
$$;

-- ---------- favorites ----------
create or replace function fav_list(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select case when exists (select 1 from customers
                           where phone = p_phone and password_hash = p_hash)
    then coalesce((select jsonb_agg(service_id) from favorites f
                   join customers c on c.id = f.customer_id
                   where c.phone = p_phone), '[]'::jsonb)
    else jsonb_build_object('error', 'auth')
  end;
$$;

create or replace function fav_add(p_phone text, p_hash text, p_service_id text)
returns boolean
language plpgsql security definer set search_path = public
as $$
declare v_cid uuid;
begin
  select id into v_cid from customers
  where phone = p_phone and password_hash = p_hash limit 1;
  if v_cid is null then return false; end if;
  insert into favorites(customer_id, service_id)
  values (v_cid, p_service_id) on conflict do nothing;
  return true;
end;
$$;

create or replace function fav_remove(p_phone text, p_hash text, p_service_id text)
returns boolean
language plpgsql security definer set search_path = public
as $$
declare v_cid uuid;
begin
  select id into v_cid from customers
  where phone = p_phone and password_hash = p_hash limit 1;
  if v_cid is null then return false; end if;
  delete from favorites where customer_id = v_cid and service_id = p_service_id;
  return true;
end;
$$;

-- ---------- password-reset OTP (rate-limited, server-side) ----------
create or replace function otp_request(p_phone text)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  c customers%rowtype;
  v_otp text;
  v_count int;
begin
  select * into c from customers where phone = p_phone limit 1;
  if c.id is null then
    return jsonb_build_object('error', 'no-account');
  end if;
  select count(*) into v_count from password_resets
  where phone = p_phone and created_at > now() - interval '1 hour';
  if v_count >= 3 then
    return jsonb_build_object('error', 'rate-limited');
  end if;
  delete from password_resets where expires_at < now() or used = true;
  v_otp := lpad(floor(random() * 900000 + 100000)::int::text, 6, '0');
  insert into password_resets(phone, otp, expires_at, used)
  values (p_phone, v_otp, now() + interval '15 minutes', false);
  return jsonb_build_object('ok', true, 'otp', v_otp, 'name', c.name);
end;
$$;

create or replace function otp_reset(p_phone text, p_otp text, p_new_hash text)
returns boolean
language plpgsql security definer set search_path = public
as $$
declare v_id uuid;
begin
  if p_new_hash is null or length(p_new_hash) <> 64 then return false; end if;
  select id into v_id from password_resets
  where phone = p_phone and otp = p_otp and used = false
    and expires_at > now() limit 1;
  if v_id is null then return false; end if;
  update password_resets set used = true where id = v_id;
  update customers set password_hash = p_new_hash where phone = p_phone;
  return found;
end;
$$;

-- ============================================================
-- PERMISSIONS: functions callable by anon; tables locked down
-- ============================================================
do $$
declare f text;
begin
  foreach f in array array[
    'owner_login(text)', 'owner_check(uuid)', 'owner_action(uuid,text,jsonb)',
    'customer_signup(text,text,text,text)', 'customer_login(text,text)',
    'customer_get(text,text)', 'customer_set_whatsapp(text,text,text)',
    'validate_coupon(text,int)', 'place_booking(jsonb)',
    'my_bookings(text,text)', 'cancel_booking(text,text,text)',
    'rate_service(text,text,text,int,text)',
    'slots_taken(date)', 'service_reviews(uuid)',
    'fav_list(text,text)', 'fav_add(text,text,text)', 'fav_remove(text,text,text)',
    'otp_request(text)', 'otp_reset(text,text,text)']
  loop
    execute format('revoke all on function %s from public, anon', f);
    execute format('grant execute on function %s to anon', f);
  end loop;
end $$;

-- ---------- RLS: drop the old "public all" holes ----------
drop policy if exists "public all" on services;
drop policy if exists "public all" on customers;
drop policy if exists "public all" on bookings;
drop policy if exists "gallery public all" on gallery;
drop policy if exists "public read" on loyalty_config;
drop policy if exists "public update" on loyalty_config;

-- ---------- RLS: least privilege ----------
-- public catalog reads (no PII, no prices to change)
drop policy if exists "anon read" on services;
create policy "anon read" on services for select to anon using (true);

drop policy if exists "anon read" on gallery;
create policy "anon read" on gallery for select to anon using (true);

drop policy if exists "anon read" on offers;
create policy "anon read" on offers for select to anon using (true);

drop policy if exists "anon read" on coupons;
create policy "anon read" on coupons for select to anon using (true);

drop policy if exists "anon read" on beauticians;
create policy "anon read" on beauticians for select to anon using (true);

drop policy if exists "anon read" on loyalty_config;
create policy "anon read" on loyalty_config for select to anon using (true);

-- settings: everything EXCEPT the owner PIN hash
drop policy if exists "anon read non-secret" on salon_settings;
create policy "anon read non-secret" on salon_settings
  for select to anon using (key <> 'owner_pin_hash');

-- customers / bookings / favorites / password_resets / owner_sessions /
-- loyalty_ledger: NO anon policies (deny by default). All access via functions.

-- ---------- storage: images only, no public overwrite/delete ----------
drop policy if exists "salon-media public upload" on storage.objects;
drop policy if exists "salon-media public update" on storage.objects;
drop policy if exists "salon-media public delete" on storage.objects;
create policy "salon-media upload images" on storage.objects
  for insert to anon
  with check (bucket_id = 'salon-media'
              and name ~* '\.(jpg|jpeg|png|webp|gif)$');
-- public read stays as-is.
