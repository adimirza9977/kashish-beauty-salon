package com.kashish.salon;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Upload any crash report saved by a previous crashed run.
        try { CrashInitProvider.flushSavedCrash(this); } catch (Throwable ignored) {}
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            private boolean handleUrl(String url) {
                // Local app pages stay inside the WebView
                if (url.startsWith("file://") || url.startsWith("about:") || url.startsWith("data:")) {
                    return false;
                }
                // WhatsApp deep link: open directly in the WhatsApp app (most reliable).
                // If WhatsApp is not installed, fall back to the wa.me web link.
                if (url.startsWith("whatsapp://")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        String fallback = toWaMe(url);
                        if (fallback != null) {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                            } catch (ActivityNotFoundException ignored) {}
                        }
                    }
                    return true;
                }
                // Everything else (https, tel:, mailto:, ...) opens in the right app
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (ActivityNotFoundException e) {
                    // No app can handle it - stay put
                }
                return true;
            }

            // whatsapp://send?phone=923...&text=...  ->  https://wa.me/923...?text=...
            private String toWaMe(String waUrl) {
                try {
                    Uri u = Uri.parse(waUrl);
                    String phone = u.getQueryParameter("phone");
                    String text = u.getQueryParameter("text");
                    if (phone == null || phone.isEmpty()) return null;
                    String out = "https://wa.me/" + phone;
                    if (text != null && !text.isEmpty()) out += "?text=" + Uri.encode(text);
                    return out;
                } catch (Exception e) {
                    return null;
                }
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
        setContentView(webView);
        setupFileChooser();

        // Offer/discount phone notifications: background check every 4 hours
        // (also right now), plus runtime permission on Android 13+.
        NotifHelper.schedule(this);
        askNotificationPermission();
        new Thread(new Runnable() {
            @Override public void run() {
                NotifHelper.checkForUpdates(MainActivity.this);
            }
        }).start();

        // Instant push (FCM): register this device's token with the server
        try {
            KashishMessagingService.syncToken(this);
        } catch (Throwable ignored) {}
    }

    // File picker support for <input type="file"> (gallery / service picture uploads)
    // v6.1 fix: the picker was HARD-CODED to image/* with single selection, so
    // videos never appeared and multiple files could not be picked no matter
    // what the HTML asked for. Now the intent follows the page's own accept
    // types (image-only, video-only or mixed) and allows multiple selection
    // whenever the input has the `multiple` attribute.
    private void setupFileChooser(){
        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params){
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] accepts = null;
                try { accepts = params.getAcceptTypes(); } catch (Throwable ignored) {}
                boolean hasImage = false, hasVideo = false, hasOther = false;
                if (accepts != null){
                    for (String a : accepts){
                        if (a == null) continue;
                        String t = a.trim().toLowerCase();
                        if (t.startsWith("image/") || t.equals(".jpg") || t.equals(".jpeg")
                                || t.equals(".png") || t.equals(".webp") || t.equals(".gif")
                                || t.equals(".heic") || t.equals(".heif")) hasImage = true;
                        else if (t.startsWith("video/") || t.equals(".mp4") || t.equals(".mov")
                                || t.equals(".webm") || t.equals(".3gp") || t.equals(".mkv")) hasVideo = true;
                        else if (t.length() > 0) hasOther = true;
                    }
                }
                if (hasImage && !hasVideo && !hasOther) i.setType("image/*");
                else if (hasVideo && !hasImage && !hasOther) i.setType("video/*");
                else if (hasImage || hasVideo){
                    i.setType("*/*");
                    java.util.ArrayList<String> mimes = new java.util.ArrayList<String>();
                    if (hasImage) mimes.add("image/*");
                    if (hasVideo) mimes.add("video/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
                } else {
                    i.setType("*/*");
                }
                boolean multi = false;
                try { multi = params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE; }
                catch (Throwable ignored) {}
                if (multi) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose files"), FILE_CHOOSER_REQ);
                } catch (ActivityNotFoundException e){
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQ && filePathCallback != null){
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null){
                if (data.getClipData() != null){
                    // multiple files picked at once
                    int n = data.getClipData().getItemCount();
                    java.util.ArrayList<Uri> list = new java.util.ArrayList<Uri>();
                    for (int k = 0; k < n; k++){
                        Uri u = data.getClipData().getItemAt(k).getUri();
                        if (u != null) list.add(u);
                    }
                    if (!list.isEmpty()) results = list.toArray(new Uri[0]);
                } else if (data.getData() != null){
                    results = new Uri[]{ data.getData() };
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    /* ---------- notification permission (v5.7) ---------- */
    /* Shows an in-app explanation first, then the system permission dialog.
       This ensures EVERY new user sees a prompt, even on phones where the
       system dialog alone doesn't appear reliably. */
    private static final int NOTIF_PERM_REQ = 2001;
    private static final String PREFS_MAIN = "kashish_main";
    private static final String KEY_NOTIF_ASKED = "notif_asked";

    private void askNotificationPermission() {
        // Create the notification channel early so Settings shows it properly
        createNotificationChannel();
        // Only relevant on Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                == PackageManager.PERMISSION_GRANTED) return;
        // Only ask once per install - if denied, user can enable in Settings
        android.content.SharedPreferences p =
                getSharedPreferences(PREFS_MAIN, MODE_PRIVATE);
        if (p.getBoolean(KEY_NOTIF_ASKED, false)) return;

        new android.app.AlertDialog.Builder(this)
                .setTitle("Stay Updated!")
                .setMessage("Allow notifications to get instant alerts about new offers, " +
                        "discounts, and new services at Kashish Beauty Salon.")
                .setPositiveButton("Allow", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        getSharedPreferences(PREFS_MAIN, MODE_PRIVATE)
                                .edit().putBoolean(KEY_NOTIF_ASKED, true).apply();
                        requestPermissions(
                                new String[]{"android.permission.POST_NOTIFICATIONS"},
                                NOTIF_PERM_REQ);
                    }
                })
                .setNegativeButton("Not Now", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        getSharedPreferences(PREFS_MAIN, MODE_PRIVATE)
                                .edit().putBoolean(KEY_NOTIF_ASKED, true).apply();
                        d.dismiss();
                    }
                })
                .setCancelable(false)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Nothing to do - permission is either granted or not. If denied,
        // the user can enable it later in Settings > Apps > Notifications.
    }

    /* Create the notification channel at startup so the system Settings
       shows the channel properly (not greyed out). */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            android.app.NotificationChannel ch = new android.app.NotificationChannel(
                    "kashish_offers", "Offers & Discounts",
                    android.app.NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("New offers and service discounts at Kashish Beauty Salon");
            nm.createNotificationChannel(ch);
        } catch (Exception ignored) {}
    }
}
