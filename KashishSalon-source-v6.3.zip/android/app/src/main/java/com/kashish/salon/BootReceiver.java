package com.kashish.salon;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-registers the offer-check job after the phone reboots. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            NotifHelper.schedule(ctx);
        }
    }
}
