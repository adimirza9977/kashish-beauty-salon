package com.kashish.salon;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * Receives FCM pushes for Kashish Beauty Salon.
 * - onNewToken: registers the device token in Supabase (push_tokens).
 * - onMessageReceived: shows the notification from the data payload.
 */
public class KashishMessagingService extends FirebaseMessagingService {

    private static final String TAG = "KashishFCM";

    @Override
    public void onNewToken(String token) {
        Log.i(TAG, "new FCM token");
        registerToken(getApplicationContext(), token);
    }

    @Override
    public void onMessageReceived(RemoteMessage msg) {
        Map<String, String> d = msg.getData();
        String title = d.get("title");
        String body = d.get("body");
        if (title == null || title.isEmpty()) title = "Kashish Beauty Salon";
        if (body == null || body.isEmpty()) {
            if (msg.getNotification() != null) body = msg.getNotification().getBody();
        }
        if (body == null || body.isEmpty()) return;
        String type = d.get("type");
        int nid = ("app_update".equals(type)) ? 9001
                : ("service_new".equals(type)) ? 9002
                : ("service_off".equals(type)) ? 9003 : 9000;
        NotifHelper.showPush(this, nid, title, body);
    }

    /** Fetch current token (e.g. on app start) and register it. */
    public static void syncToken(final android.content.Context ctx) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    com.google.firebase.messaging.FirebaseMessaging fm =
                            com.google.firebase.messaging.FirebaseMessaging.getInstance();
                    // blocking get with timeout via Tasks.await
                    String token = com.google.android.gms.tasks.Tasks.await(
                            fm.getToken(), 20, java.util.concurrent.TimeUnit.SECONDS);
                    if (token != null && !token.isEmpty()) registerToken(ctx, token);
                } catch (Exception e) {
                    Log.w(TAG, "token sync failed: " + e.getMessage());
                }
            }
        }).start();
    }

    private static void registerToken(android.content.Context ctx, String token) {
        HttpURLConnection c = null;
        try {
            String[] cfg = SupaConfig.read(ctx);
            if (cfg == null) return;
            URL url = new URL(cfg[0] + "/rest/v1/push_tokens");
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("apikey", cfg[1]);
            c.setRequestProperty("Authorization", "Bearer " + cfg[1]);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Prefer", "resolution=merge-duplicates");
            JSONObject body = new JSONObject();
            body.put("token", token);
            byte[] b = body.toString().getBytes("UTF-8");
            OutputStream os = c.getOutputStream();
            os.write(b);
            os.close();
            int rc = c.getResponseCode();
            Log.i(TAG, "token register -> " + rc);
        } catch (Exception e) {
            Log.w(TAG, "register failed: " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
