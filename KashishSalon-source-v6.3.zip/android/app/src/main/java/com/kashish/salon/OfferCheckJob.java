package com.kashish.salon;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Background job: checks Supabase for new offers / service discounts. */
public class OfferCheckJob extends JobService {
    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(new Runnable() {
            @Override public void run() {
                NotifHelper.checkForUpdates(OfferCheckJob.this);
                jobFinished(params, false);
            }
        }).start();
        return true; // work continues on our thread
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true; // reschedule if interrupted
    }
}
