package com.kashish.salon;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads SUPABASE_URL + SUPABASE_ANON_KEY from assets/www/js/config.js */
public class SupaConfig {
    public static String[] read(Context ctx) {
        try {
            InputStream in = ctx.getAssets().open("www/js/config.js");
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            br.close();
            String t = sb.toString();
            Matcher mu = Pattern.compile("SUPABASE_URL:\\s*\"([^\"]+)\"").matcher(t);
            Matcher mk = Pattern.compile("SUPABASE_ANON_KEY:\\s*\"([^\"]+)\"").matcher(t);
            if (mu.find() && mk.find()) return new String[]{mu.group(1), mk.group(1)};
        } catch (Exception ignored) {}
        return null;
    }
}
