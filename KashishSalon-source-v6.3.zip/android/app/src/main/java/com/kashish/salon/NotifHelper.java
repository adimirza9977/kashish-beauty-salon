package com.kashish.salon;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Background offer/discount watcher for Kashish Beauty Salon.
 *
 * - schedule(ctx): registers a JobScheduler job that runs every 4 hours
 *   (persisted across reboots; BootReceiver re-registers after BOOT_COMPLETED).
 * - checkForUpdates(ctx): MUST run on a background thread. Fetches active
 *   offers + discounted services from Supabase, compares with the last-seen
 *   state in SharedPreferences, and posts a phone notification for anything
 *   new. First run only seeds the state (no notification spam).
 *
 * Framework APIs only  -  no external libraries needed.
 */
public class NotifHelper {

    private static final String PREFS = "kashish_notif";
    private static final String CHANNEL_ID = "kashish_offers";
    private static final int JOB_ID = 4101;
    private static final long PERIOD_MS = 4L * 3600L * 1000L; // every 4 hours

    /** Register (or re-register) the periodic background check. */
    public static void schedule(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        try {
            JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            JobInfo job = new JobInfo.Builder(JOB_ID,
                    new ComponentName(ctx, OfferCheckJob.class))
                    .setPeriodic(PERIOD_MS)
                    .setPersisted(true)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .build();
            js.schedule(job);
        } catch (Exception ignored) {}
    }

    /** Fetch + compare + notify. Call ONLY from a background thread. */
    public static void checkForUpdates(Context ctx) {
        try {
            String[] cfg = readSupabaseConfig(ctx);
            if (cfg == null) return;
            String base = cfg[0];
            String key = cfg[1];

            SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            boolean seeded = p.getBoolean("seeded", false);
            Set<String> seenOffers = new HashSet<>(p.getStringSet("seen_offers", new HashSet<String>()));
            Map<String, Integer> seenSvc = parseMap(p.getString("seen_svc", ""));

            JSONArray offers = getJson(base + "/rest/v1/offers"
                    + "?select=id,title,discount_text,valid_till,created_at"
                    + "&is_active=eq.true&order=created_at.desc&limit=25", key);
            JSONArray svcs = getJson(base + "/rest/v1/services"
                    + "?select=id,name,price,discount_percent"
                    + "&discount_percent=gt.0&limit=100", key);

            if (offers == null && svcs == null) return; // offline  -  try next time

            if (!seeded) {
                // First run: remember everything silently so the user is not
                // spammed with notifications for old offers.
                SharedPreferences.Editor e = p.edit();
                e.putStringSet("seen_offers", idsOf(offers));
                e.putString("seen_svc", toMapStr(svcMap(svcs)));
                e.putBoolean("seeded", true);
                e.apply();
                return;
            }

            int shown = 0;
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());

            // --- new offers ---
            if (offers != null) {
                for (int i = 0; i < offers.length() && shown < 3; i++) {
                    JSONObject o = offers.getJSONObject(i);
                    String id = o.optString("id", "");
                    if (id.isEmpty() || seenOffers.contains(id)) continue;
                    seenOffers.add(id);
                    String vt = o.optString("valid_till", "");
                    if (!vt.isEmpty() && vt.compareTo(today) < 0) continue; // expired
                    String title = o.optString("title", "Special Offer");
                    String dtxt = o.optString("discount_text", "");
                    String msg = dtxt.isEmpty() ? title : (dtxt + " \u2014 " + title);
                    if (!vt.isEmpty()) msg += " (valid till " + vt + ")";
                    show(ctx, 1000 + shown, "\uD83C\uDF89 New Offer at Kashish!", msg);
                    shown++;
                }
            }

            // --- new / increased service discounts ---
            Map<String, Integer> cur = svcMap(svcs);
            if (svcs != null) {
                for (int i = 0; i < svcs.length() && shown < 3; i++) {
                    JSONObject s = svcs.getJSONObject(i);
                    String id = s.optString("id", "");
                    if (id.isEmpty()) continue;
                    int disc = s.optInt("discount_percent", 0);
                    Integer old = seenSvc.get(id);
                    if (disc > 0 && (old == null || disc > old.intValue())) {
                        String name = s.optString("name", "Service");
                        long price = (long) s.optDouble("price", 0);
                        long now = Math.round(price * (100 - disc) / 100.0);
                        show(ctx, 2000 + shown,
                                "\uD83D\uDC9B " + disc + "% OFF on " + name,
                                "Now Rs " + fmtRs(now) + " (was Rs " + fmtRs(price) + ") \u2014 book now!");
                        shown++;
                    }
                }
            }

            SharedPreferences.Editor e = p.edit();
            e.putStringSet("seen_offers", seenOffers);
            e.putString("seen_svc", toMapStr(cur));
            e.apply();
        } catch (Exception ignored) {}
    }

    // ---------- notification plumbing ----------

    /** Public entry for FCM pushes (KashishMessagingService). */
    public static void showPush(Context ctx, int nid, String title, String text) {
        show(ctx, nid, title, text);
    }

    private static void show(Context ctx, int nid, String title, String text) {
        try {
            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, "Offers & Discounts",
                        NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("New offers and service discounts at Kashish Beauty Salon");
                nm.createNotificationChannel(ch);
            }
            Intent it = new Intent(ctx, MainActivity.class);
            it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(ctx, nid, it, flags);
            Notification.Builder b = new Notification.Builder(ctx)
                    .setSmallIcon(R.drawable.ic_stat_bell)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setWhen(System.currentTimeMillis());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                b.setChannelId(CHANNEL_ID);
            }
            nm.notify(nid, b.build());
        } catch (Exception ignored) {}
    }

    // ---------- helpers ----------

    private static String fmtRs(long n) {
        return String.format(Locale.US, "%,d", n);
    }

    private static Set<String> idsOf(JSONArray arr) {
        Set<String> s = new HashSet<>();
        if (arr == null) return s;
        for (int i = 0; i < arr.length(); i++) {
            String id = arr.optJSONObject(i).optString("id", "");
            if (!id.isEmpty()) s.add(id);
        }
        return s;
    }

    private static Map<String, Integer> svcMap(JSONArray arr) {
        Map<String, Integer> m = new HashMap<>();
        if (arr == null) return m;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            String id = o.optString("id", "");
            if (!id.isEmpty()) m.put(id, o.optInt("discount_percent", 0));
        }
        return m;
    }

    private static Map<String, Integer> parseMap(String s) {
        Map<String, Integer> m = new HashMap<>();
        if (s == null) return m;
        for (String part : s.split(";")) {
            String[] kv = part.split(":", 2);
            if (kv.length == 2) {
                try { m.put(kv[0], Integer.parseInt(kv[1])); } catch (Exception ignored) {}
            }
        }
        return m;
    }

    private static String toMapStr(Map<String, Integer> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : m.entrySet()) {
            if (sb.length() > 0) sb.append(';');
            sb.append(e.getKey()).append(':').append(e.getValue());
        }
        return sb.toString();
    }

    private static String[] readSupabaseConfig(Context ctx) {
        return SupaConfig.read(ctx);
    }

    private static JSONArray getJson(String urlStr, String key) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(urlStr);
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            c.setRequestProperty("apikey", key);
            c.setRequestProperty("Authorization", "Bearer " + key);
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return new JSONArray(sb.toString());
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
