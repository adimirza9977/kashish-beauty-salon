package com.kashish.salon;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Runs BEFORE FirebaseInitProvider (initOrder 101 > 100) and installs a
 * global crash handler. On any uncaught crash it saves the stack trace to
 * crash.log and best-effort POSTs it to Supabase crash_reports, so the
 * developer can see the exact crash without the device.
 */
public class CrashInitProvider extends ContentProvider {

    private static final String TAG = "KashishCrash";
    static final String CRASH_FILE = "crash.log";

    @Override
    public boolean onCreate() {
        final android.content.Context ctx = getContext().getApplicationContext();
        final Thread.UncaughtExceptionHandler prev =
                Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringBuilder sb = new StringBuilder();
                    sb.append("TIME: ").append(new SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())).append("\n");
                    sb.append("THREAD: ").append(t.getName()).append("\n");
                    sb.append("EX: ").append(e.toString()).append("\n");
                    for (StackTraceElement st : e.getStackTrace()) {
                        sb.append("  at ").append(st.toString()).append("\n");
                    }
                    Throwable c = e.getCause();
                    while (c != null) {
                        sb.append("CAUSED BY: ").append(c.toString()).append("\n");
                        for (StackTraceElement st : c.getStackTrace()) {
                            sb.append("  at ").append(st.toString()).append("\n");
                        }
                        c = c.getCause();
                    }
                    String report = sb.toString();
                    Log.e(TAG, report);
                    // 1) save locally so next launch can retry the upload
                    try {
                        File f = new File(ctx.getFilesDir(), CRASH_FILE);
                        FileWriter w = new FileWriter(f, true);
                        w.write(report);
                        w.write("\n-----\n");
                        w.close();
                    } catch (Exception ignored) {}
                    // 2) best-effort immediate upload (short timeout; process is dying)
                    uploadReport(ctx, report);
                } catch (Exception ignored) {
                } finally {
                    if (prev != null) prev.uncaughtException(t, e);
                    else android.os.Process.killProcess(android.os.Process.myPid());
                }
            }
        });
        // If a previous run crashed, try uploading the saved log now.
        flushSavedCrash(ctx);
        return true;
    }

    /** Upload a saved crash.log from a previous run (called on fresh start). */
    static void flushSavedCrash(final android.content.Context ctx) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    File f = new File(ctx.getFilesDir(), CRASH_FILE);
                    if (!f.exists()) return;
                    StringBuilder sb = new StringBuilder();
                    java.io.FileReader r = new java.io.FileReader(f);
                    char[] buf = new char[8192];
                    int n;
                    while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                    r.close();
                    if (sb.length() == 0) { f.delete(); return; }
                    if (uploadReport(ctx, sb.toString())) f.delete();
                } catch (Exception ignored) {}
            }
        }).start();
    }

    /** POST the report to Supabase. Returns true on HTTP 2xx. */
    static boolean uploadReport(android.content.Context ctx, String report) {
        HttpURLConnection c = null;
        try {
            String[] cfg = SupaConfig.read(ctx);
            if (cfg == null) return false;
            URL url = new URL(cfg[0] + "/rest/v1/crash_reports");
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("apikey", cfg[1]);
            c.setRequestProperty("Authorization", "Bearer " + cfg[1]);
            c.setRequestProperty("Content-Type", "application/json");
            JSONObject body = new JSONObject();
            if (report.length() > 8000) report = report.substring(0, 8000);
            body.put("report", report);
            byte[] b = body.toString().getBytes("UTF-8");
            OutputStream os = c.getOutputStream();
            os.write(b);
            os.close();
            int rc = c.getResponseCode();
            Log.i(TAG, "crash upload -> " + rc);
            return rc >= 200 && rc < 300;
        } catch (Exception e) {
            Log.w(TAG, "crash upload failed: " + e.getMessage());
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // ---- ContentProvider stubs ----
    @Override public Cursor query(Uri u, String[] p, String s, String[] sa, String so) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] sa) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] sa) { return 0; }
}
