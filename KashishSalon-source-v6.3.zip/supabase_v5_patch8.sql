-- ============================================================
-- Kashish Beauty Salon — Patch 8 (v6.0)
--  1. deals table (owner-managed package deals with picture)
--  2. gallery_categories + gallery.category_id (gallery folders)
--  3. service_images (extra pictures per service)
--  4. owner_action: gal_add category-aware + new cases
--     (gal_cat_add / gal_cat_delete / gal_set_cat /
--      deal_upsert / deal_delete / svc_img_add / svc_img_delete)
--  5. place_booking: accepts deal_id (deal priced server-side)
--  6. One-time fix: the HEIC gallery photo uploaded 2026-10-13
--     (stored as .jpg but really HEIC — replaced with a true JPEG
--      converted copy already uploaded to storage)
-- Idempotent: safe to run more than once.
-- ============================================================

-- ---------- 1. deals ----------
create table if not exists deals (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price int not null default 0,
  duration_min int not null default 120,
  image_url text,
  active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz default now()
);
alter table deals enable row level security;
drop policy if exists "deals public read" on deals;
create policy "deals public read" on deals for select to anon using (true);

-- ---------- 2. gallery categories ----------
create table if not exists gallery_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  sort_order int not null default 0,
  created_at timestamptz default now()
);
alter table gallery_categories enable row level security;
drop policy if exists "gal cats public read" on gallery_categories;
create policy "gal cats public read" on gallery_categories for select to anon using (true);

alter table gallery add column if not exists category_id uuid
  references gallery_categories(id) on delete set null;

-- gallery can hold videos too (image_url stores the media URL either way)
alter table gallery add column if not exists media_type text not null default 'image';

-- storage: allow video files alongside images (name-extension based,
-- same pattern as the v5 policy; the app always uploads the TRUE format)
drop policy if exists "salon-media upload images" on storage.objects;
drop policy if exists "salon-media upload media" on storage.objects;
create policy "salon-media upload media" on storage.objects
  for insert to anon
  with check (bucket_id = 'salon-media'
              and name ~* '\.(jpg|jpeg|png|webp|gif|mp4|mov|webm|3gp)$');

-- ---------- 3. service images ----------
create table if not exists service_images (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  image_url text not null,
  sort_order int not null default 0,
  created_at timestamptz default now()
);
alter table service_images enable row level security;
drop policy if exists "svc imgs public read" on service_images;
create policy "svc imgs public read" on service_images for select to anon using (true);

-- ---------- 6. HEIC gallery photo fix ----------
update gallery
set image_url = 'https://uzqbtsbcquwwejgtobsx.supabase.co/storage/v1/object/public/salon-media/img_heicfix_67c1b9a5.jpg'
where id = '67c1b9a5-ba01-4aca-90cf-335f5ec8b081'
  and image_url like '%img_1791913336741%';

-- ---------- 4. owner_action_v6: NEW standalone function ----------
-- (v2 approach: the live owner_action text has drifted from the local
--  copy, so instead of string surgery on it we add a separate
--  token-gated function for the v6.0 actions only. owner_action and
--  the v5.9 app keep working untouched.)
create or replace function owner_action_v6(p_token uuid, p_action text, p_data jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $v6$
declare
  d jsonb := coalesce(p_data, '{}'::jsonb);
  v_id uuid;
begin
  if not owner_check(p_token) then
    return jsonb_build_object('error', 'bad-token');
  end if;

  case p_action
    when 'gal_add' then
      insert into gallery(image_url, caption, sort_order, category_id, media_type)
      values (d->>'image_url', coalesce(d->>'caption',''), coalesce((d->>'sort_order')::int, 0),
              nullif(d->>'category_id','')::uuid,
              coalesce(nullif(d->>'media_type',''), 'image'))
      returning id into v_id;
      return jsonb_build_object('ok', true, 'id', v_id);

    when 'gal_cat_add' then
      if length(trim(coalesce(d->>'name',''))) < 2 then
        return jsonb_build_object('error', 'bad-name');
      end if;
      insert into gallery_categories(name)
      values (left(trim(d->>'name'), 60))
      returning id into v_id;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'gal_cat_delete' then
      delete from gallery_categories where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'gal_set_cat' then
      update gallery set category_id = nullif(d->>'category_id','')::uuid
      where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    when 'deal_upsert' then
      if (d->>'id') is null then
        insert into deals(name, description, price, duration_min, image_url, active, sort_order)
        values (left(trim(d->>'name'), 120), coalesce(d->>'description',''),
                greatest(0, coalesce((d->>'price')::int, 0)),
                coalesce((d->>'duration_min')::int, 120),
                nullif(d->>'image_url',''),
                coalesce((d->>'active')::boolean, true),
                coalesce((d->>'sort_order')::int, 0))
        returning id into v_id;
      else
        update deals set
          name = coalesce(nullif(d->>'name',''), name),
          description = coalesce(d->>'description', description),
          price = coalesce((d->>'price')::int, price),
          duration_min = coalesce((d->>'duration_min')::int, duration_min),
          image_url = case when d ? 'image_url' then nullif(d->>'image_url','') else image_url end,
          active = coalesce((d->>'active')::boolean, active),
          sort_order = coalesce((d->>'sort_order')::int, sort_order)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'deal_delete' then
      update deals set active = false where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    when 'svc_img_add' then
      insert into service_images(service_id, image_url, sort_order)
      values ((d->>'service_id')::uuid, d->>'image_url', coalesce((d->>'sort_order')::int, 0))
      returning id into v_id;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'svc_img_delete' then
      delete from service_images where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);

    else
      return jsonb_build_object('error', 'unknown-action');
  end case;
end;
$v6$;
revoke all on function owner_action_v6(uuid,text,jsonb) from public, anon;
grant execute on function owner_action_v6(uuid,text,jsonb) to anon;

-- ---------- 5. place_booking: deal support ----------
-- Anchors below are the EXACT live text (fetched from pg_get_functiondef
-- on 2026-10-13 — the live function has no "-- service must exist"
-- comment; it was created from an earlier draft than the local file).
DO $patch$
DECLARE
  func_src text;
  old_txt text;
  new_txt text;
BEGIN
  SELECT pg_get_functiondef(oid) INTO func_src
  FROM pg_proc WHERE proname = 'place_booking' AND pronamespace = 'public'::regnamespace;

  IF position('deal_id' in func_src) = 0 THEN
    old_txt := $old$  s services%rowtype;$old$;
    new_txt := $new$  s services%rowtype;
  dl deals%rowtype;$new$;
    IF position(old_txt in func_src) = 0 THEN
      RAISE EXCEPTION 'patch8: place_booking declare anchor not found - aborting';
    END IF;
    func_src := replace(func_src, old_txt, new_txt);

    old_txt := $old$  select * into s from services
  where id = (d->>'service_id')::uuid and active = true limit 1;
  if s.id is null then
    return jsonb_build_object('error', 'bad-service');
  end if;
  v_price := s.price;$old$;
    new_txt := $new$  -- v6.0: p_data may carry deal_id instead of service_id (deal priced server-side)
  if coalesce(d->>'deal_id','') <> '' then
    select * into dl from deals
    where id = (d->>'deal_id')::uuid and active = true limit 1;
    if dl.id is null then
      return jsonb_build_object('error', 'bad-service');
    end if;
    s.id := null;
    s.name := dl.name;
    s.duration_min := dl.duration_min;
    s.discount_percent := 0;
    v_price := dl.price;
  else
    select * into s from services
    where id = (d->>'service_id')::uuid and active = true limit 1;
    if s.id is null then
      return jsonb_build_object('error', 'bad-service');
    end if;
    v_price := s.price;
  end if;$new$;
    IF position(old_txt in func_src) = 0 THEN
      RAISE EXCEPTION 'patch8: place_booking service anchor not found - aborting';
    END IF;
    func_src := replace(func_src, old_txt, new_txt);

    EXECUTE func_src;
    RAISE NOTICE 'patch8: place_booking extended for deals';
  END IF;
END $patch$;
