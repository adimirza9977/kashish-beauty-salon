-- ============================================================
-- Kashish Beauty Salon — v5.0 patch 2 (run AFTER v5 delta)
-- Enables RLS on tables that never had it. Without this, the
-- v5 least-privilege policies do nothing and these tables stay
-- wide open to the anon key.
-- Idempotent — safe to re-run.
-- ============================================================

-- Supabase installs extensions into the "extensions" schema, but the v5
-- functions run with search_path = public. Move pgcrypto to public so
-- digest() / gen_random_uuid() resolve inside them.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pgcrypto') THEN
    CREATE EXTENSION pgcrypto WITH SCHEMA public;
  ELSE
    ALTER EXTENSION pgcrypto SET SCHEMA public;
  END IF;
END $$;

alter table offers enable row level security;
alter table coupons enable row level security;
alter table beauticians enable row level security;
alter table salon_settings enable row level security;
alter table favorites enable row level security;
alter table password_resets enable row level security;

-- verification: every table should report 't'
select tablename,
       (select relrowsecurity from pg_class where relname = tablename) as rls_on
from (values ('services'),('customers'),('bookings'),('loyalty_config'),
             ('gallery'),('offers'),('coupons'),('beauticians'),
             ('salon_settings'),('favorites'),('password_resets'),
             ('owner_sessions'),('loyalty_ledger')) as t(tablename)
order by tablename;
