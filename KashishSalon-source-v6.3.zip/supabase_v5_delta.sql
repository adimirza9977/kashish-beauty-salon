-- ============================================================
-- Kashish Beauty Salon — v5.0 delta (run AFTER supabase_v5_security.sql)
-- Adds: minimal slot objects, customer reschedule, owner walk-in
-- booking, owner customer lookup, PIN recovery functions.
-- ============================================================

-- pgcrypto provides digest() / gen_random_uuid() used by v5 functions
create extension if not exists pgcrypto;

-- slots_taken now returns minimal objects (no PII): id, time_slot, status, beautician_id
create or replace function slots_taken(p_date date)
returns jsonb
language sql security definer set search_path = public
as $$
  select coalesce(jsonb_agg(
           jsonb_build_object('id', id, 'time_slot', time_slot,
                              'status', status, 'beautician_id', beautician_id)),
         '[]'::jsonb)
  from bookings
  where booking_date = p_date and status <> 'cancelled';
$$;

-- customer reschedules their own booking (ownership + slot validated)
create or replace function reschedule_booking(p_ref text, p_phone text, p_hash text,
                                              p_date date, p_slot text)
returns boolean
language plpgsql security definer set search_path = public
as $$
begin
  if not exists (select 1 from customers
                 where phone = p_phone and password_hash = p_hash) then
    return false;
  end if;
  if exists (select 1 from bookings
             where booking_date = p_date and time_slot = p_slot
               and status <> 'cancelled' and ref_code <> p_ref) then
    return false; -- slot taken
  end if;
  update bookings set booking_date = p_date, time_slot = p_slot
  where ref_code = p_ref and customer_phone = p_phone
    and status in ('pending', 'confirmed');
  return found;
exception when unique_violation then
  return false;
end;
$$;

revoke all on function slots_taken(date) from public, anon;
grant execute on function slots_taken(date) to anon;
revoke all on function reschedule_booking(text,text,text,date,text) from public, anon;
grant execute on function reschedule_booking(text,text,text,date,text) to anon;

-- owner_action: add booking_walkin + customer_lookup cases
create or replace function owner_action(p_token uuid, p_action text, p_data jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  d jsonb := coalesce(p_data, '{}'::jsonb);
  v_id uuid;
  -- walk-in locals
  w_s services%rowtype;
  w_c customers%rowtype;
  w_cfg loyalty_config%rowtype;
  w_ref text;
  w_bid uuid;
  w_earned int;
begin
  if not owner_check(p_token) then
    return jsonb_build_object('error', 'bad-token');
  end if;

  case p_action
    when 'svc_upsert' then
      if (d->>'id') is null then
        insert into services(name, description, price, duration_min, category, image_url, is_featured, active)
        values (d->>'name', coalesce(d->>'description',''),
                (d->>'price')::int, coalesce((d->>'duration_min')::int, 30),
                coalesce(d->>'category','general'), nullif(d->>'image_url',''),
                coalesce((d->>'is_featured')::boolean, false),
                coalesce((d->>'active')::boolean, true))
        returning id into v_id;
      else
        update services set
          name = coalesce(d->>'name', name),
          description = coalesce(d->>'description', description),
          price = coalesce((d->>'price')::int, price),
          duration_min = coalesce((d->>'duration_min')::int, duration_min),
          category = coalesce(d->>'category', category),
          image_url = case when d ? 'image_url' then nullif(d->>'image_url','') else image_url end,
          is_featured = coalesce((d->>'is_featured')::boolean, is_featured),
          active = coalesce((d->>'active')::boolean, active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'svc_delete' then
      update services set active = false where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'gal_add' then
      insert into gallery(image_url, caption, sort_order)
      values (d->>'image_url', coalesce(d->>'caption',''), coalesce((d->>'sort_order')::int, 0))
      returning id into v_id;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'gal_delete' then
      delete from gallery where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'offer_upsert' then
      if (d->>'id') is null then
        insert into offers(title, description, discount_text, image_url, valid_till, terms, is_active)
        values (d->>'title', coalesce(d->>'description',''), coalesce(d->>'discount_text',''),
                nullif(d->>'image_url',''), nullif(d->>'valid_till','')::date,
                coalesce(d->>'terms',''), coalesce((d->>'is_active')::boolean, true))
        returning id into v_id;
      else
        update offers set
          title = coalesce(d->>'title', title),
          description = coalesce(d->>'description', description),
          discount_text = coalesce(d->>'discount_text', discount_text),
          image_url = case when d ? 'image_url' then nullif(d->>'image_url','') else image_url end,
          valid_till = case when d ? 'valid_till' then nullif(d->>'valid_till','')::date else valid_till end,
          terms = coalesce(d->>'terms', terms),
          is_active = coalesce((d->>'is_active')::boolean, is_active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'offer_delete' then
      delete from offers where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'coupon_upsert' then
      if (d->>'id') is null then
        insert into coupons(code, discount_percent, discount_rs, min_amount, valid_till, is_active)
        values (upper(d->>'code'), (d->>'discount_percent')::int, (d->>'discount_rs')::int,
                coalesce((d->>'min_amount')::int, 0),
                nullif(d->>'valid_till','')::date,
                coalesce((d->>'is_active')::boolean, true))
        returning id into v_id;
      else
        update coupons set
          code = coalesce(upper(d->>'code'), code),
          discount_percent = case when d ? 'discount_percent' then (d->>'discount_percent')::int else discount_percent end,
          discount_rs = case when d ? 'discount_rs' then (d->>'discount_rs')::int else discount_rs end,
          min_amount = coalesce((d->>'min_amount')::int, min_amount),
          valid_till = case when d ? 'valid_till' then nullif(d->>'valid_till','')::date else valid_till end,
          is_active = coalesce((d->>'is_active')::boolean, is_active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'coupon_delete' then
      delete from coupons where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'beaut_upsert' then
      if (d->>'id') is null then
        insert into beauticians(name, specialty, is_active)
        values (d->>'name', coalesce(d->>'specialty',''), coalesce((d->>'is_active')::boolean, true))
        returning id into v_id;
      else
        update beauticians set
          name = coalesce(d->>'name', name),
          specialty = coalesce(d->>'specialty', specialty),
          is_active = coalesce((d->>'is_active')::boolean, is_active)
        where id = (d->>'id')::uuid returning id into v_id;
      end if;
      return jsonb_build_object('ok', true, 'id', v_id);
    when 'beaut_delete' then
      delete from beauticians where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'booking_list' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from bookings order by booking_date desc, time_slot desc
        limit coalesce((d->>'limit')::int, 200)) t);
    when 'booking_by_date' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from bookings
        where booking_date = (d->>'date')::date and status <> 'cancelled'
        order by time_slot) t);
    when 'pending_payments' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from bookings where payment_status = 'proof_submitted'
        order by created_at desc) t);
    when 'booking_status' then
      update bookings set status = d->>'status' where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'booking_payment' then
      update bookings set payment_status = d->>'payment_status' where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'booking_walkin' then
      -- owner creates a booking for a walk-in customer (registered or not)
      select * into w_s from services
      where id = (d->>'service_id')::uuid and active = true limit 1;
      if w_s.id is null then
        return jsonb_build_object('error', 'bad-service');
      end if;
      if exists (select 1 from bookings
                 where booking_date = (d->>'booking_date')::date
                   and time_slot = d->>'time_slot'
                   and status <> 'cancelled') then
        return jsonb_build_object('error', 'slot-taken');
      end if;
      loop
        w_ref := 'KBS-' || upper(substr(md5(random()::text), 1, 6));
        exit when not exists (select 1 from bookings where ref_code = w_ref);
      end loop;
      select * into w_cfg from loyalty_config where id = 1;
      w_earned := floor(w_s.price / 100) * w_cfg.points_per_100rs;
      begin
        insert into bookings(customer_name, customer_phone, service_id, service_name,
            price, booking_date, time_slot, ref_code, beautician_id,
            status, payment_method, payment_status, loyalty_earned, notes)
        values (left(d->>'customer_name', 80), d->>'customer_phone', w_s.id, w_s.name,
            w_s.price, (d->>'booking_date')::date, d->>'time_slot', w_ref,
            nullif(d->>'beautician_id','')::uuid,
            'confirmed', 'cash', 'unpaid', w_earned, 'Walk-in')
        returning id into w_bid;
      exception when unique_violation then
        return jsonb_build_object('error', 'slot-taken');
      end;
      select * into w_c from customers where phone = d->>'customer_phone' limit 1;
      if w_c.id is not null then
        update customers set loyalty_points = loyalty_points + w_earned,
                              total_visits = total_visits + 1
        where id = w_c.id;
        if w_earned > 0 then
          insert into loyalty_ledger(customer_id, points, reason, ref)
          values (w_c.id, w_earned, 'walk-in earned', w_ref);
        end if;
      end if;
      return jsonb_build_object('ok', true, 'ref_code', w_ref, 'booking_id', w_bid);
    when 'customers_list' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select id, name, phone, whatsapp, loyalty_points, total_visits, created_at
        from customers order by total_visits desc, loyalty_points desc limit 300) t);
    when 'customer_delete' then
      delete from customers where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    when 'customer_lookup' then
      return (select jsonb_build_object('id', id, 'name', name, 'phone', phone)
              from customers where phone = d->>'phone' limit 1);
    when 'loyalty_award' then
      if coalesce((d->>'points')::int, 0) = 0 then
        return jsonb_build_object('error', 'no-points');
      end if;
      if abs((d->>'points')::int) > 10000 then
        return jsonb_build_object('error', 'points-range');
      end if;
      update customers set loyalty_points = loyalty_points + (d->>'points')::int
      where id = (d->>'id')::uuid;
      insert into loyalty_ledger(customer_id, points, reason, ref)
      values ((d->>'id')::uuid, (d->>'points')::int,
              coalesce(d->>'reason','owner award'), coalesce(d->>'ref',''));
      return (select jsonb_build_object('ok', true, 'loyalty_points', loyalty_points)
              from customers where id = (d->>'id')::uuid);
    when 'loyalty_ledger' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select * from loyalty_ledger
        where ((d->>'customer_id') is null or customer_id = (d->>'customer_id')::uuid)
        order by created_at desc limit 100) t);
    when 'loyalty_config_save' then
      update loyalty_config set
        points_per_100rs = coalesce((d->>'points_per_100rs')::int, points_per_100rs),
        redeem_points = coalesce((d->>'redeem_points')::int, redeem_points),
        redeem_value_rs = coalesce((d->>'redeem_value_rs')::int, redeem_value_rs),
        min_redeem_points = coalesce((d->>'min_redeem_points')::int, min_redeem_points),
        updated_at = now()
      where id = 1;
      return jsonb_build_object('ok', true);
    when 'setting_set' then
      if d->>'key' = 'owner_pin_hash' then
        return jsonb_build_object('error', 'blocked-key');
      end if;
      insert into salon_settings(key, value, updated_at)
      values (d->>'key', d->>'value', now())
      on conflict (key) do update set value = excluded.value, updated_at = now();
      return jsonb_build_object('ok', true);
    when 'pin_change' then
      if encode(digest('kashish-pin:' || coalesce(d->>'old_pin',''), 'sha256'), 'hex')
         <> (select value from salon_settings where key = 'owner_pin_hash') then
        return jsonb_build_object('error', 'wrong-pin');
      end if;
      update salon_settings set
        value = encode(digest('kashish-pin:' || (d->>'new_pin'), 'sha256'), 'hex'),
        updated_at = now()
      where key = 'owner_pin_hash';
      delete from owner_sessions where token <> p_token;
      return jsonb_build_object('ok', true);
    when 'reset_list' then
      return (select coalesce(jsonb_agg(t), '[]'::jsonb) from (
        select id, phone, otp, expires_at, used, created_at from password_resets
        where used = false and expires_at > now()
        order by created_at desc limit 50) t);
    when 'reset_dismiss' then
      delete from password_resets where id = (d->>'id')::uuid;
      return jsonb_build_object('ok', true);
    else
      return jsonb_build_object('error', 'unknown-action');
  end case;
end;
$$;

revoke all on function owner_action(uuid,text,jsonb) from public, anon;
grant execute on function owner_action(uuid,text,jsonb) to anon;

-- ============================================================
-- Owner PIN recovery via one-time recovery code.
-- The code is shown ONCE when generated (owner writes it down);
-- only its SHA-256 hash is stored. Entering it allows setting a
-- new PIN and immediately issues a fresh code.
-- ============================================================
create or replace function owner_recovery_status(p_token uuid)
returns boolean
language sql security definer set search_path = public
as $$
  select owner_check(p_token)
    and exists (select 1 from salon_settings where key = 'owner_recovery_hash');
$$;

create or replace function owner_recovery_issue(p_token uuid)
returns text
language plpgsql security definer set search_path = public
as $$
declare
  v_code text;
begin
  if not owner_check(p_token) then return null; end if;
  -- 8-char code, unambiguous alphabet (no 0/O, 1/I)
  v_code := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
  v_code := translate(v_code, '01', 'AB');
  insert into salon_settings(key, value, updated_at)
  values ('owner_recovery_hash', encode(digest(v_code, 'sha256'), 'hex'), now())
  on conflict (key) do update set value = excluded.value, updated_at = now();
  return v_code;
end;
$$;

create or replace function owner_recovery_reset(p_code text, p_new_pin text)
returns text
language plpgsql security definer set search_path = public
as $$
declare
  v_hash text;
  v_new text;
begin
  if p_new_pin is null or p_new_pin !~ '^[0-9]{4}$' then return null; end if;
  select value into v_hash from salon_settings where key = 'owner_recovery_hash';
  if v_hash is null then return null; end if;
  if v_hash <> encode(digest(upper(coalesce(p_code,'')), 'sha256'), 'hex') then
    return null;
  end if;
  -- set the new PIN
  update salon_settings set
    value = encode(digest('kashish-pin:' || p_new_pin, 'sha256'), 'hex'),
    updated_at = now()
  where key = 'owner_pin_hash';
  -- kill all owner sessions
  delete from owner_sessions;
  -- issue a FRESH recovery code (old one is single-use)
  v_new := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
  v_new := translate(v_new, '01', 'AB');
  update salon_settings set
    value = encode(digest(v_new, 'sha256'), 'hex'), updated_at = now()
  where key = 'owner_recovery_hash';
  return v_new;
end;
$$;

revoke all on function owner_recovery_status(uuid) from public, anon;
grant execute on function owner_recovery_status(uuid) to anon;
revoke all on function owner_recovery_issue(uuid) from public, anon;
grant execute on function owner_recovery_issue(uuid) to anon;
revoke all on function owner_recovery_reset(text,text) from public, anon;
grant execute on function owner_recovery_reset(text,text) to anon;
