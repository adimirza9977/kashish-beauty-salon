#!/bin/bash
# Kashish Beauty Salon — manual APK build (aapt2 -> javac -> d8 -> zipalign -> apksigner)
# (Gradle daemon cannot run on this VM, so we compile manually.)
set -e
cd "$(dirname "$0")"
BASEDIR="$(pwd)"
OUT="$BASEDIR/build/apk-out"
SDK=/home/hatch/android-sdk
BT=$SDK/build-tools/34.0.0
PLATFORM=$SDK/platforms/android-34/android.jar
PROJ=android/app/src/main
KS=build/debug.keystore
KSPASS=android

# ---- version sync FIRST: AndroidManifest is the single source of truth ----
# (the WebView UI reads CFG.APP_VERSION_CODE for the update banner,
#  so config.js must match the manifest BEFORE aapt2 packages the assets)
VNAME=$(grep -o 'android:versionName="[^"]*"' "$PROJ/AndroidManifest.xml" | cut -d'"' -f2)
VCODE=$(grep -o 'android:versionCode="[0-9]*"' "$PROJ/AndroidManifest.xml" | cut -d'"' -f2)
CFGJS="$PROJ/assets/www/js/config.js"
sed -i "s/APP_VERSION: \"[^\"]*\"/APP_VERSION: \"$VNAME\"/; s/APP_VERSION_CODE: [0-9]*/APP_VERSION_CODE: $VCODE/" "$CFGJS"
echo "version sync -> $VNAME ($VCODE) in config.js"
CGV=$(grep -o 'APP_VERSION: "[^"]*"' "$CFGJS" | cut -d'"' -f2)
CGVC=$(grep -o 'APP_VERSION_CODE: [0-9]*' "$CFGJS" | grep -o '[0-9]*')
if [ "$CGV" != "$VNAME" ] || [ "$CGVC" != "$VCODE" ]; then
  echo "FATAL: config.js ($CGV/$CGVC) does not match manifest ($VNAME/$VCODE) — aborting build"
  exit 1
fi
echo "QA gate 1 passed: manifest and config.js agree ($VNAME/$VCODE)"

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/dex"

echo "==> aapt2 compile (resources)"
$BT/aapt2 compile --dir "$PROJ/res" -o "$OUT/compiled_res.zip"
# FCM library resources (merged from AARs)
FCM_RES="$BASEDIR/fcm/build/res"
if [ -d "$FCM_RES" ]; then
  $BT/aapt2 compile --dir "$FCM_RES" -o "$OUT/compiled_fcm_res.zip"
  FCM_RES_ZIP="$OUT/compiled_fcm_res.zip"
else
  FCM_RES_ZIP=""
fi

echo "==> aapt2 link"
$BT/aapt2 link -o "$OUT/app-unsigned.apk" \
  -I "$PLATFORM" \
  --manifest "$PROJ/AndroidManifest.xml" \
  --java "$OUT/gen" \
  -A "$PROJ/assets" \
  "$OUT/compiled_res.zip" $FCM_RES_ZIP

echo "==> javac"
find "$OUT/gen" -name "*.java" > "$OUT/sources.txt"
find "$PROJ/java" -name "*.java" >> "$OUT/sources.txt"
# library R stubs (FCM/play-services/androidx .class files reference their own R)
FCM_CLS="$BASEDIR/fcm/build/classes"
if [ -d "$FCM_RES" ]; then
  python3 "$BASEDIR/fcm/gen_r_stubs.py" "$OUT/gen/com/kashish/salon/R.java" "$OUT/rstubs"
  find "$OUT/rstubs" -name "*.java" >> "$OUT/sources.txt"
fi
CP="$PLATFORM"
if [ -d "$FCM_CLS" ]; then CP="$CP:$FCM_CLS"; fi
javac -source 8 -target 8 -cp "$CP" -d "$OUT/classes" @"$OUT/sources.txt" 2>/dev/null || \
javac --release 8 -cp "$CP" -d "$OUT/classes" @"$OUT/sources.txt"

echo "==> d8 (dex)"
FCM_CLS="$BASEDIR/fcm/build/classes"
if [ -d "$FCM_CLS" ]; then
  $BT/d8 --lib "$PLATFORM" --output "$OUT/dex" $(find "$OUT/classes" "$FCM_CLS" -name "*.class")
else
  $BT/d8 --lib "$PLATFORM" --output "$OUT/dex" $(find "$OUT/classes" -name "*.class")
fi

echo "==> add classes.dex + align + sign"
cp "$OUT/app-unsigned.apk" "$OUT/app.apk"
# add dex at root of apk
(cd "$OUT/dex" && zip -q -j "$OUT/app.apk" classes.dex)
$BT/zipalign -f -p 4 "$OUT/app.apk" "$OUT/app-aligned.apk"
cp "$OUT/app-aligned.apk" "$OUT/KashishBeautySalon.apk"
$BT/apksigner sign --ks "$KS" --ks-pass pass:"$KSPASS" --out "$OUT/KashishBeautySalon-signed.apk" "$OUT/KashishBeautySalon.apk"

echo "==> verify"
$BT/apksigner verify --print-certs "$OUT/KashishBeautySalon-signed.apk" | head -3
ls -la "$OUT/KashishBeautySalon-signed.apk"

# publish to your_files
cp "$OUT/KashishBeautySalon-signed.apk" ~/workspace/your_files/KashishBeautySalon.apk
echo "DONE -> ~/workspace/your_files/KashishBeautySalon.apk"

# ---- QA gate 2: verify the version INSIDE the built APK (not just the source) ----
APKCFG_V=$(python3 -c "
import zipfile, re
z = zipfile.ZipFile('$OUT/KashishBeautySalon-signed.apk')
t = z.read('assets/www/js/config.js').decode()
v = re.search(r'APP_VERSION: \"([^\"]+)\"', t).group(1)
c = re.search(r'APP_VERSION_CODE: (\d+)', t).group(1)
print(v + '/' + c)
")
if [ "$APKCFG_V" != "$VNAME/$VCODE" ]; then
  echo "FATAL: APK internal config.js ($APKCFG_V) does not match manifest ($VNAME/$VCODE) — aborting"
  exit 1
fi
echo "QA gate 2 passed: APK internal config.js matches ($VNAME/$VCODE)"

# ---- source backup (standing rule: every version gets a source zip) ----
SRCZIP=~/workspace/your_files/KashishSalon-source-v${VNAME}.zip
rm -f "$SRCZIP"
(cd "$BASEDIR" && zip -qr "$SRCZIP" android build_apk.sh VERSION.md DELIVERY_CHECKLIST.md supabase_schema.sql supabase_v3.sql supabase_v5_security.sql supabase_v5_delta.sql supabase_v5_patch2.sql supabase_v5_patch3.sql supabase_v5_patch4.sql supabase_v5_patch5.sql supabase_v5_patch6.sql supabase_v5_patch7.sql supabase_v5_patch8.sql supabase_patch9_beautician_ranking.sql supabase_patch10_loyalty_on_completion.sql -x "*/build/*")
ls -la "$SRCZIP"
echo "BACKUP -> $SRCZIP"
