-- Patch 7: booking_walkin accepts custom service_name + manual price
DO $$
DECLARE
  func_src text;
  old_case text;
  new_case text;
BEGIN
  -- Get current function source
  SELECT pg_get_functiondef(oid) INTO func_src
  FROM pg_proc WHERE proname = 'owner_action' AND pronamespace = 'public'::regnamespace;
  
  -- Define the old booking_walkin case (exact text from v5_delta.sql)
  old_case := $$    when 'booking_walkin' then
      -- owner creates a booking for a walk-in customer (registered or not)
      select * into w_s from services
      where id = (d->>'service_id')::uuid and active = true limit 1;
      if w_s.id is null then
        return jsonb_build_object('error', 'bad-service');
      end if;$$;
  
  -- Define the new case: accept custom service_name + price, OR service_id fallback
  new_case := $$    when 'booking_walkin' then
      -- owner creates a booking for a walk-in customer (registered or not)
      -- v5.9: accepts custom service_name + manual price (for bargaining)
      --       OR falls back to service_id lookup for backward compatibility
      if d ? 'service_name' and trim(d->>'service_name') <> '' then
        -- Custom service: owner typed the name and set the price manually
        w_s.id := null;
        w_s.name := left(trim(d->>'service_name'), 120);
        w_s.price := greatest(0, coalesce((d->>'price')::int, 0));
      else
        -- Legacy: lookup from services table by service_id
        select * into w_s from services
        where id = (d->>'service_id')::uuid and active = true limit 1;
        if w_s.id is null then
          return jsonb_build_object('error', 'bad-service');
        end if;
      end if;$$;
  
  IF position(old_case in func_src) = 0 THEN
    RAISE EXCEPTION 'Old booking_walkin case not found - patch cannot be applied safely';
  END IF;
  
  func_src := replace(func_src, old_case, new_case);
  
  -- Also update the loyalty calculation to use w_s.price (which is now set correctly)
  -- and the INSERT to handle null service_id
  -- The existing code already uses w_s.price and w_s.name, and w_s.id (which is null for custom)
  -- So no further changes needed!
  
  EXECUTE func_src;
  RAISE NOTICE 'Patch 7 applied successfully';
END $$;
