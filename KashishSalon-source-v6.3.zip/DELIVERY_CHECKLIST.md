# Kashish Salon APK — Delivery Checklist (adeel's standing order 2026-10-12:
# "har cheez double check karni hai" — no update ships without every box ticked)

## Before build
- [ ] AndroidManifest.xml: versionCode bumped by 1, versionName updated
- [ ] VERSION.md: new version entry written
- [ ] All touched JS files pass `node --check`
- [ ] Every `DB.*` call resolves to a defined method (cross-check script)

## After build (build_apk.sh auto-syncs config.js + QA-gates the version match)
- [ ] `aapt dump badging` on the APK shows the expected versionCode/versionName
- [ ] Unzipped `assets/www/js/config.js` inside the APK matches manifest version
- [ ] Source backup zip exists: `~/workspace/your_files/KashishSalon-source-v<VERSION>.zip`

## After upload
- [ ] Both commit SHAs recorded (APK + source zip)
- [ ] jsDelivr cache purged for the new commit-SHA URL
- [ ] Fresh download from the delivered link: byte-size matches the built APK,
      and `aapt` on the download shows the expected version
- [ ] If the DB changed: migrations run + live-probed via anon key
      (reads blocked as intended, functions behave, no test residue left behind)
- [ ] Update notice set in salon_settings (latest_version / latest_version_code /
      latest_apk_url) and verified with a SELECT
- [ ] Delivered link is the commit-SHA jsDelivr URL in a code box (never @main,
      never a release link)

## After delivery
- [ ] MEMORY.md updated (version, SHAs, lessons)
