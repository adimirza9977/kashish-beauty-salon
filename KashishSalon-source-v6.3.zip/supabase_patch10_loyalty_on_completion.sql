-- Kashish Salon patch10 (v6.3): loyalty points ONLY on completion.
-- adeel's order 2026-10-14: "loyalty points tab hone chahiye jab owner
-- booking ko complete kar de — tab tak add na hon."
--
-- BEFORE: place_booking credited earned points + total_visits the moment
-- a booking was placed. AFTER:
--   * place_booking only deducts REDEEMED points at booking time (a hold,
--     so points cannot be double-spent across parallel bookings) and
--     stores the earned amount on the booking row (loyalty_earned).
--   * A trigger on bookings awards the earned points (+1 visit) when the
--     status becomes 'completed', and reverses them if a completed
--     booking is moved back. The award is net-aware via the ledger, so
--     legacy bookings (already credited under the old rule, incl.
--     walk-ins with reason 'walk-in earned') can never double-award.

-- ---------- part A: award / reversal trigger ----------
create or replace function public.loyalty_on_booking_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $trg$
declare
  v_cust uuid;
  v_net int;
  v_earn int;
begin
  if NEW.status is not distinct from OLD.status then return NEW; end if;
  v_earn := coalesce(NEW.loyalty_earned, 0);
  if v_earn <= 0 then return NEW; end if;
  select id into v_cust from customers where phone = NEW.customer_phone limit 1;
  if v_cust is null then return NEW; end if;
  select coalesce(sum(points), 0) into v_net
  from loyalty_ledger
  where ref = NEW.ref_code
    and reason in ('booking earned', 'walk-in earned', 'earned reversed');
  if NEW.status = 'completed' and v_net < v_earn then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (v_cust, v_earn - v_net, 'booking earned', NEW.ref_code);
    update customers
    set loyalty_points = loyalty_points + (v_earn - v_net),
        total_visits = total_visits + 1
    where id = v_cust;
  elsif NEW.status <> 'completed' and v_net > 0 then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (v_cust, -v_net, 'earned reversed', NEW.ref_code);
    update customers
    set loyalty_points = greatest(loyalty_points - v_net, 0),
        total_visits = greatest(total_visits - 1, 0)
    where id = v_cust;
  end if;
  return NEW;
end;
$trg$;

drop trigger if exists trg_loyalty_status on public.bookings;
create trigger trg_loyalty_status
after update of status on public.bookings
for each row execute function public.loyalty_on_booking_status();

-- ---------- part B: place_booking stops crediting earned points ----------
-- Surgical replace against the LIVE definition (fetched 2026-10-14);
-- aborts loudly if the anchor is not found, changing nothing.
do $patch$
declare
  v_def text;
  v_old text := $old$
  update customers set
    loyalty_points = loyalty_points + v_earned - v_redeem_pts,
    total_visits = total_visits + 1
  where id = c.id;
  if v_earned > 0 then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (c.id, v_earned, 'booking earned', v_ref);
  end if;
$old$;
  v_new text := $new$
  -- patch10 (v6.3): earned points are NOT credited at booking time any
  -- more. The loyalty_on_booking_status trigger awards them when the
  -- owner marks this booking 'completed' (bookings.loyalty_earned
  -- holds the amount). Redemption stays deducted here so the points
  -- cannot be double-spent across parallel bookings.
  update customers set
    loyalty_points = loyalty_points - v_redeem_pts
  where id = c.id;
$new$;
begin
  select pg_get_functiondef(p.oid) into v_def
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
  where n.nspname = 'public' and p.proname = 'place_booking';
  if v_def is null then raise exception 'place_booking not found'; end if;
  if position(v_old in v_def) = 0 then
    raise exception 'patch10 anchor NOT FOUND - live place_booking differs, aborting';
  end if;
  v_def := replace(v_def, v_old, v_new);
  execute v_def;
end
$patch$;
--
