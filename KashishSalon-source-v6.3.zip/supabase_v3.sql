-- Kashish Beauty Salon — v3.0 migration
-- Run AFTER the original supabase_schema.sql

-- 1. Customer auth fields
alter table customers add column if not exists password_hash text;
alter table customers add column if not exists whatsapp text;

-- 2. Gallery table (owner-managed pictures)
create table if not exists gallery (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  caption text default '',
  sort_order int not null default 0,
  created_at timestamptz default now()
);
alter table gallery enable row level security;
drop policy if exists "gallery public all" on gallery;
create policy "gallery public all" on gallery for all using (true) with check (true);

-- 3. Public storage bucket for salon pictures (services + gallery uploads)
insert into storage.buckets (id, name, public)
values ('salon-media', 'salon-media', true)
on conflict (id) do nothing;

-- Storage policies (idempotent via DO block)
do $$
begin
  if not exists (select 1 from pg_policies where policyname = 'salon-media public read' and tablename = 'objects') then
    create policy "salon-media public read" on storage.objects
      for select using (bucket_id = 'salon-media');
  end if;
  if not exists (select 1 from pg_policies where policyname = 'salon-media public upload' and tablename = 'objects') then
    create policy "salon-media public upload" on storage.objects
      for insert with check (bucket_id = 'salon-media');
  end if;
  if not exists (select 1 from pg_policies where policyname = 'salon-media public update' and tablename = 'objects') then
    create policy "salon-media public update" on storage.objects
      for update using (bucket_id = 'salon-media') with check (bucket_id = 'salon-media');
  end if;
  if not exists (select 1 from pg_policies where policyname = 'salon-media public delete' and tablename = 'objects') then
    create policy "salon-media public delete" on storage.objects
      for delete using (bucket_id = 'salon-media');
  end if;
end $$;
