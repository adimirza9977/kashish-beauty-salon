-- ============================================================
-- Kashish Beauty Salon — v5.0 patch 4
-- Customer BLOCK / UNBLOCK + owner customer helpers.
-- - adds customers.is_blocked
-- - blocked customers: login rejected, booking rejected, sessions dropped
-- - owner functions: list (with is_blocked), set blocked, per-customer bookings
-- - cleans up the v5 test customer (0300000000)
-- Idempotent — safe to re-run.
-- ============================================================

alter table customers add column if not exists is_blocked boolean default false;

-- ---------- customer_login: reject blocked accounts ----------
create or replace function customer_login(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select case
    when not exists (select 1 from customers
                     where phone = p_phone and password_hash = p_hash)
      then null
    when exists (select 1 from customers
                 where phone = p_phone and password_hash = p_hash
                   and coalesce(is_blocked, false) = true)
      then jsonb_build_object('error', 'blocked')
    else (select jsonb_build_object(
            'id', id, 'name', name, 'phone', phone, 'whatsapp', whatsapp,
            'loyalty_points', loyalty_points, 'total_visits', total_visits,
            'is_blocked', coalesce(is_blocked, false))
          from customers
          where phone = p_phone and password_hash = p_hash limit 1)
  end;
$$;

-- ---------- customer_get: include blocked flag (lets the app drop sessions) ----------
create or replace function customer_get(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select jsonb_build_object(
      'id', id, 'name', name, 'phone', phone, 'whatsapp', whatsapp,
      'loyalty_points', loyalty_points, 'total_visits', total_visits,
      'is_blocked', coalesce(is_blocked, false))
  from customers
  where phone = p_phone and password_hash = p_hash
  limit 1;
$$;

-- ---------- place_booking: reject blocked customers ----------
create or replace function place_booking(p_data jsonb)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  d jsonb := p_data;
  c customers%rowtype;
  s services%rowtype;
  cfg loyalty_config%rowtype;
  v_price int;
  v_coupon jsonb;
  v_coupon_disc int := 0;
  v_coupon_code text := '';
  v_redeem_pts int := 0;
  v_redeem_disc int := 0;
  v_total int;
  v_earned int;
  v_ref text;
  v_bid uuid;
begin
  -- auth the customer
  select * into c from customers
  where phone = d->>'customer_phone' and password_hash = d->>'password_hash' limit 1;
  if c.id is null then
    return jsonb_build_object('error', 'auth');
  end if;
  if coalesce(c.is_blocked, false) then
    return jsonb_build_object('error', 'blocked');
  end if;

  -- service must exist, be active; PRICE comes from the server, never the client
  select * into s from services
  where id = (d->>'service_id')::uuid and active = true limit 1;
  if s.id is null then
    return jsonb_build_object('error', 'bad-service');
  end if;
  v_price := s.price;

  -- coupon validated server-side
  if coalesce(d->>'coupon_code','') <> '' then
    v_coupon := validate_coupon(d->>'coupon_code', v_price);
    if not (v_coupon->>'valid')::boolean then
      return jsonb_build_object('error', 'bad-coupon',
                                'reason', v_coupon->>'reason');
    end if;
    v_coupon_disc := (v_coupon->>'discount_rs')::int;
    v_coupon_code := v_coupon->>'code';
  end if;

  -- loyalty redeem validated server-side
  select * into cfg from loyalty_config where id = 1;
  v_redeem_pts := coalesce((d->>'redeem_points')::int, 0);
  if v_redeem_pts > 0 then
    if v_redeem_pts > c.loyalty_points then
      return jsonb_build_object('error', 'not-enough-points');
    end if;
    if v_redeem_pts < cfg.min_redeem_points
       or v_redeem_pts % cfg.redeem_points <> 0 then
      return jsonb_build_object('error', 'bad-redeem');
    end if;
    v_redeem_disc := (v_redeem_pts / cfg.redeem_points) * cfg.redeem_value_rs;
  end if;

  v_total := greatest(v_price - v_coupon_disc - least(v_redeem_disc, v_price - v_coupon_disc), 0);
  v_earned := floor(v_total / 100) * cfg.points_per_100rs;

  -- unique ref code
  loop
    v_ref := 'KBS-' || upper(substr(md5(random()::text), 1, 6));
    exit when not exists (select 1 from bookings where ref_code = v_ref);
  end loop;

  -- slot conflict guard (unique constraint is the final arbiter)
  if exists (select 1 from bookings
             where booking_date = (d->>'booking_date')::date
               and time_slot = d->>'time_slot'
               and status <> 'cancelled') then
    return jsonb_build_object('error', 'slot-taken');
  end if;

  begin
    insert into bookings(customer_name, customer_phone, service_id, service_name,
        price, booking_date, time_slot, ref_code, beautician_id,
        coupon_code, discount_rs, status, payment_method, payment_status,
        payment_tid, loyalty_earned, loyalty_redeemed, notes)
    values (left(coalesce(d->>'customer_name', c.name), 80), c.phone, s.id, s.name,
        v_total, (d->>'booking_date')::date, d->>'time_slot', v_ref,
        nullif(d->>'beautician_id','')::uuid,
        v_coupon_code, v_coupon_disc, 'pending',
        coalesce(d->>'payment_method','cash'),
        case when coalesce(d->>'payment_method','cash') = 'cash' then 'unpaid' else 'proof_submitted' end,
        left(coalesce(d->>'payment_tid',''), 60),
        v_earned, v_redeem_pts,
        left(coalesce(d->>'notes',''), 500))
    returning id into v_bid;
  exception when unique_violation then
    return jsonb_build_object('error', 'slot-taken');
  end;

  -- loyalty: atomic balance update + ledger
  update customers set
    loyalty_points = loyalty_points + v_earned - v_redeem_pts,
    total_visits = total_visits + 1
  where id = c.id;
  if v_earned > 0 then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (c.id, v_earned, 'booking earned', v_ref);
  end if;
  if v_redeem_pts > 0 then
    insert into loyalty_ledger(customer_id, points, reason, ref)
    values (c.id, -v_redeem_pts, 'booking redeemed', v_ref);
  end if;

  return jsonb_build_object('ok', true, 'ref_code', v_ref, 'booking_id', v_bid,
                            'total', v_total, 'earned', v_earned);
end;
$$;

-- ---------- owner: customer list (with blocked flag) ----------
create or replace function owner_customers_list(p_token uuid)
returns jsonb
language sql security definer set search_path = public
as $$
  select case when owner_check(p_token)
    then coalesce((select jsonb_agg(t) from (
      select id, name, phone, whatsapp, loyalty_points, total_visits,
             coalesce(is_blocked, false) as is_blocked, created_at
      from customers
      order by total_visits desc, loyalty_points desc limit 300) t), '[]'::jsonb)
    else jsonb_build_object('error', 'bad-token')
  end;
$$;

-- ---------- owner: block / unblock a customer ----------
create or replace function owner_customer_set_blocked(p_token uuid, p_customer_id uuid,
                                                      p_blocked boolean)
returns boolean
language plpgsql security definer set search_path = public
as $$
begin
  if not owner_check(p_token) then return false; end if;
  update customers set is_blocked = coalesce(p_blocked, false)
  where id = p_customer_id;
  return found;
end;
$$;

-- ---------- owner: one customer's bookings ----------
create or replace function owner_customer_bookings(p_token uuid, p_phone text)
returns jsonb
language sql security definer set search_path = public
as $$
  select case when owner_check(p_token)
    then coalesce((select jsonb_agg(t) from (
      select * from bookings
      where customer_phone = p_phone
      order by booking_date desc, time_slot desc limit 100) t), '[]'::jsonb)
    else jsonb_build_object('error', 'bad-token')
  end;
$$;

revoke all on function owner_customers_list(uuid) from public, anon;
grant execute on function owner_customers_list(uuid) to anon;
revoke all on function owner_customer_set_blocked(uuid,uuid,boolean) from public, anon;
grant execute on function owner_customer_set_blocked(uuid,uuid,boolean) to anon;
revoke all on function owner_customer_bookings(uuid,text) from public, anon;
grant execute on function owner_customer_bookings(uuid,text) to anon;

-- ---------- cleanup: remove the v5 test customer and its data ----------
delete from bookings where customer_phone = '0300000000';
delete from loyalty_ledger where customer_id in
  (select id from customers where phone = '0300000000');
delete from favorites where customer_id in
  (select id from customers where phone = '0300000000');
delete from password_resets where phone = '0300000000';
delete from customers where phone = '0300000000';

-- verification
select 'is_blocked col' as check_,
       count(*) as ok from information_schema.columns
where table_name = 'customers' and column_name = 'is_blocked'
union all
select 'test user remaining (want 0)', count(*) from customers where phone = '0300000000';
