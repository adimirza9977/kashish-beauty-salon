-- ============================================================
-- Kashish Beauty Salon — v5.0 patch 3 (run AFTER patch 2)
-- Rebuilds ALL table policies from scratch. Reason: old permissive
-- policies with unknown names survived the v5 migration's
-- name-based DROPs (proven: anon could INSERT into coupons and
-- read salon_settings.owner_pin_hash). This wipes every policy on
-- every app table and creates exactly the intended least-privilege
-- set. Idempotent — safe to re-run.
-- ============================================================

DO $$
DECLARE p record;
BEGIN
  FOR p IN SELECT tablename, policyname FROM pg_policies
           WHERE schemaname = 'public'
             AND tablename IN ('services','customers','bookings','gallery','offers',
                               'coupons','beauticians','loyalty_config','salon_settings',
                               'favorites','password_resets','owner_sessions','loyalty_ledger')
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', p.policyname, p.tablename);
  END LOOP;
END $$;

-- public catalog: anon SELECT only (no insert/update/delete)
create policy "anon read" on services      for select to anon using (true);
create policy "anon read" on gallery       for select to anon using (true);
create policy "anon read" on offers        for select to anon using (true);
create policy "anon read" on coupons       for select to anon using (true);
create policy "anon read" on beauticians   for select to anon using (true);
create policy "anon read" on loyalty_config for select to anon using (true);

-- settings: everything EXCEPT the owner PIN hash
create policy "anon read non-secret" on salon_settings
  for select to anon using (key <> 'owner_pin_hash');

-- customers / bookings / favorites / password_resets / owner_sessions /
-- loyalty_ledger: NO policies at all (deny by default; access via
-- SECURITY DEFINER functions only).

-- verification: list every remaining policy per table
select tablename, policyname, cmd, roles
from pg_policies
where schemaname = 'public'
  and tablename in ('services','customers','bookings','gallery','offers',
                    'coupons','beauticians','loyalty_config','salon_settings',
                    'favorites','password_resets','owner_sessions','loyalty_ledger')
order by tablename, policyname;
