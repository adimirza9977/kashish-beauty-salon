-- v5.6: customer profile editing + optional email
-- Idempotent migration.

alter table public.customers
  add column if not exists email text;

-- signup: accept optional email
create or replace function customer_signup(p_name text, p_phone text, p_whatsapp text, p_hash text, p_email text default null)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  c customers%rowtype;
begin
  if p_phone is null or length(regexp_replace(p_phone, '\D', '', 'g')) < 10 then
    return jsonb_build_object('error', 'bad-phone');
  end if;
  if p_hash is null or length(p_hash) <> 64 then
    return jsonb_build_object('error', 'bad-hash');
  end if;
  insert into customers(name, phone, whatsapp, password_hash, email, loyalty_points, total_visits)
  values (left(coalesce(p_name,'Customer'), 80), p_phone,
          coalesce(p_whatsapp,''), p_hash,
          nullif(left(coalesce(p_email,''), 120), ''), 0, 0)
  on conflict (phone) do nothing
  returning * into c;
  if c.id is null then
    return jsonb_build_object('error', 'phone-exists');
  end if;
  return jsonb_build_object('id', c.id, 'name', c.name, 'phone', c.phone, 'email', c.email);
end;
$$;

-- login/get: include email
create or replace function customer_login(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select jsonb_build_object(
      'id', id, 'name', name, 'phone', phone, 'whatsapp', whatsapp,
      'email', email,
      'loyalty_points', loyalty_points, 'total_visits', total_visits)
  from customers
  where phone = p_phone and password_hash = p_hash
    and coalesce(is_blocked, false) = false
  limit 1;
$$;

create or replace function customer_get(p_phone text, p_hash text)
returns jsonb
language sql security definer set search_path = public
as $$
  select jsonb_build_object(
      'id', id, 'name', name, 'phone', phone, 'whatsapp', whatsapp,
      'email', email,
      'loyalty_points', loyalty_points, 'total_visits', total_visits)
  from customers
  where phone = p_phone and password_hash = p_hash
    and coalesce(is_blocked, false) = false
  limit 1;
$$;

-- profile update: user edits own name/email (verified by phone+hash)
create or replace function customer_update_profile(p_phone text, p_hash text, p_name text, p_email text)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  c customers%rowtype;
begin
  if p_name is null or length(trim(p_name)) < 2 then
    return jsonb_build_object('error', 'bad-name');
  end if;
  update customers
     set name = left(trim(p_name), 80),
         email = nullif(left(trim(coalesce(p_email,'')), 120), '')
   where phone = p_phone and password_hash = p_hash
  returning * into c;
  if c.id is null then
    return jsonb_build_object('error', 'invalid');
  end if;
  return jsonb_build_object('id', c.id, 'name', c.name, 'phone', c.phone, 'email', c.email);
end;
$$;
