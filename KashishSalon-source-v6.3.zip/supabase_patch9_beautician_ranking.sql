-- Kashish Salon patch9 (v6.3): beautician ranking stats.
-- Ranking rule (adeel's order 2026-10-14): the beautician selected/booked
-- the most ranks #1. Counts every booking that was NOT cancelled
-- (app bookings + owner walk-ins); completed count breaks ties.
-- v2: also returns WEEKLY counts (last 7 days by booking_date) for the
-- owner's Weekly Ranking board. Aggregate counts only — no customer data.
create or replace function public.beautician_stats()
returns table(beautician_id text, total_bookings bigint, completed_bookings bigint,
              week_bookings bigint, week_completed bigint)
language sql
security definer
set search_path = public
stable
as $fn$
  select b.beautician_id::text,
         count(*) filter (where b.status <> 'cancelled'),
         count(*) filter (where b.status = 'completed'),
         count(*) filter (where b.status <> 'cancelled'
                          and b.booking_date >= current_date - 6),
         count(*) filter (where b.status = 'completed'
                          and b.booking_date >= current_date - 6)
  from public.bookings b
  where b.beautician_id is not null
  group by b.beautician_id
$fn$;

grant execute on function public.beautician_stats() to anon, authenticated;
--
