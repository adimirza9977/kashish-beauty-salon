# Kashish Beauty Salon — Version Log (MASTER APK)

Package: com.kashish.salon
Source of truth for version: AndroidManifest.xml (versionCode + versionName)

RULE (adeel's order 2026-10-12): every update bumps versionCode by 1 and
updates versionName. Same package always — updates install OVER the old APK,
never a new app.

## History
- v1.0 (versionCode 1) — 2026-10-09: first app (services list, gallery, contact)
- v2.0 (versionCode 2) — 2026-10-12: full rebuild — online booking (Supabase),
  payments (Cash/Easypaisa/JazzCash/Bank/Card), loyalty points, owner panel
  (PIN 1234), WhatsApp booking alerts, rose-gold redesign, Redmi Note 13 fix
  (minSdk 24 / targetSdk 34), WhatsApp external-intent fix, topbar owner button.
- v2.1 (versionCode 3) — 2026-10-12: WhatsApp deep-link fix (whatsapp://send opens
  chat directly; wa.me fallback if WhatsApp not installed); owner-panel WhatsApp
  button param fix (?text= -> &text=).
- v3.0 (versionCode 4) — 2026-10-12: customer accounts — signup/login/profile;
  booking requires login; user sees own bookings + statuses + cancel option;
  owner PIN stored in Supabase (survives reinstall); owner bookings show all
  upcoming by default; OWNER MANAGERS: services (add/edit/delete, rates, pictures),
  gallery (upload/delete pictures); file picker support in app.
- v3.1 (versionCode 5) — 2026-10-12: forgot password — 6-digit OTP reset flow
  (user requests code via WhatsApp to salon, owner sends code from new Resets
  tab, user sets new password); OTP valid 15 min.
- v3.2 (versionCode 6) — 2026-10-12: in-app update notice — non-blocking English
  banner on Home when a newer version is published; owner sets latest version +
  APK link in Owner > Settings > App Update Notice (stored in Supabase).
- v3.3 (versionCode 7) — 2026-10-12: owner editable featured services (star toggle
  in Services manager + custom pictures); Instagram link editable in Owner >
  Settings (default fixed to @kashish_beautysalon); payment accounts now have
  separate title (holder name) + number fields, title shown to customers.
- v3.4 (versionCode 8) — 2026-10-12: prominent owner logout — Lock Panel button
  moved to the top of the owner panel (always visible golden bar), no longer
  buried in Settings.
- v3.5 (versionCode 9) — 2026-10-12: real salon branding — Instagram page
  (kashish_salon_sahiwal) logo as app icon + in-app header/splash logo;
  Instagram link corrected; gallery replaced with 8 HD salon pictures
  (old stock photos deleted).
- v4.0 (versionCode 10) — 2026-10-12: MODERN LUXURY redesign (ChatGPT UI/UX
  plan): HOME — hero banner with Book Appointment CTA, Popular Services row,
  Recommended For You, Today's Offers carousel (owner-managed), Upcoming
  Appointment card, Visit Us (address/hours/Call/WhatsApp/Instagram);
  SERVICE DETAILS screen (image, price, duration, ratings, inclusions, prep
  tips, Book Now, favorite heart); BOOKING — beautician selection (Any
  Available + staff list), coupon code apply (percent/flat, min amount,
  expiry), booking reference number (KBS-XXXXXX), full confirmation screen
  (View My Bookings, WhatsApp salon); reschedule upcoming bookings;
  PROFILE — Upcoming/Completed/Cancelled tabs, 5-star ratings + reviews on
  completed bookings, My Favorites, WhatsApp reminder toggles, delete
  account, privacy policy; OWNER — Dashboard (today's bookings/revenue,
  pending, upcoming, overlap alerts, walk-in booking, quick actions),
  Customers list + history, Offers manager, Coupons manager, Beauticians
  manager. DB: services.duration_min, bookings ref_code/rating/review/
  coupon_code/discount_rs/beautician_id, new tables beauticians, favorites,
  offers, coupons.
- v4.1 (versionCode 11) — 2026-10-12: LUXURY RESKIN (Dribbble inspiration
  pictures from the ChatGPT plan): blush-pink canvas with gold/rose glows,
  white floating cards (20-28px radii), royal burgundy #4B2438 + champagne
  gold #C9AC78 + rose #D96C85, Playfair Display serif headings + Jost body
  (Google Fonts, offline fallbacks), gold eyebrow section headers, maroon
  gradient pill CTAs, floating white pill bottom nav, taller hero with
  burgundy gradient overlay, photo offer banners with gold badges, gold
  loyalty card, gold-ringed splash. Pure visual redesign — all features and
  IDs unchanged.

## v4.2 (versionCode 12) — 2026-10-12
- Hero kicker text: "Ladies Beauty Salon" → "Kashish Beauty Salon · Sahiwal" (user's correction)
- Page horizontal-scroll lock: `overflow-x:hidden` + `overscroll-behavior-x:none` on html/body — app no longer wobbles side-to-side like a website; fixed like a proper app
- All 40 services now have real cover pictures (10 per-category stock photos uploaded to Supabase salon-media bucket; owner can change any picture from Owner → Services → edit)

## v4.3 (versionCode 13) — 2026-10-12
- FIX: home "Popular Services" / "Recommended For You" cards showed letter placeholders instead of pictures. Root cause: home rendered from the local fallback list before the network fetch of services finished, and never re-rendered. Now home cards re-render after DB services load (initDB + refreshServices), so pictures show whenever set — letters only when a service truly has no picture.

## v4.4 (versionCode 14) — 2026-10-12
- Owner → Offers → Coupons: new "Share" button on every coupon — opens WhatsApp with a ready discount message (code, discount, min order, validity) so the owner can send the coupon to customers. Coupon creation itself (code, % or Rs discount, min order, valid-till) already existed.

## v5.0 (versionCode 15) — 2026-10-12 — SECURITY HARDENING
- Closed 4 critical holes: (1) RLS locked down — anon key can only read the
  public catalog (services/offers/coupons/gallery/beauticians/loyalty config);
  customers/bookings/favorites/password_resets are INVISIBLE to the anon key.
  (2) Owner PIN now verified SERVER-SIDE (12-hour session tokens) — the hash is
  no longer readable or comparable from the app. (3) Loyalty points are computed
  and awarded SERVER-SIDE inside place_booking — cannot be forged from the app.
  (4) Coupon validation + prices validated server-side on every booking.
- New: customer signup/login/password-hash auth via secure functions; booking
  cancel/reschedule/rate by ref code + password proof; owner does everything
  through an allow-listed server dispatcher (booking_walkin, loyalty_award with
  ledger, pin_change, etc.).
- New: Owner PIN recovery — "Forgot PIN?" on the PIN pad + a one-time
  8-character recovery code in Owner → Settings. The code is shown once (write
  it down); entering it resets the PIN and issues a fresh code.
- Requires Supabase migration: supabase_v5_security.sql + supabase_v5_delta.sql
  (both idempotent; add pgcrypto extension).
- Source backup: KashishSalon-source-v5.0.zip (build_apk.sh now auto-creates it).

## v5.0 rebuild 2 (versionCode 15, versionName 5.0 — NO bump, adeel's order)
- Owner → Customers → customer detail: new **Block/Unblock** button (blocked
  customers cannot login or book; their sessions are dropped) and **Delete**
  button (double-confirm; bookings stay in history). Blocked badge in the list.
- Server: customers.is_blocked; customer_login/customer_get return blocked
  state; place_booking rejects blocked customers; new owner functions
  owner_customers_list / owner_customer_set_blocked / owner_customer_bookings.
- Migration: supabase_v5_patch4.sql (also removed the v5 test customer).

## v5.1 (versionCode 16) — 2026-10-12
- Version bump from 5.0 rebuild 2 (adeel's order: banner should appear).
  No functional changes vs 5.0 rebuild 2 — same block/delete features.
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@105b8bb1bb943d35cb3a274b3a2c8e108497a8c9/KashishBeautySalon.apk (commit 105b8bb "Update to v5.1 APK (fixed: internal version now 5.1/16)" — first v5.1 build had stale internal config.js 5.0/15 because the version sync ran AFTER aapt2 packaging; build_apk.sh fixed: sync now runs BEFORE packaging + QA gate 2 verifies the version inside the built APK). Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@c5e51a8bf8d7183942bc08c29c9a5c5a2f5fe2d/KashishSalon-source-v5.1.zip (commit c5e51a8 "Update v5.1 source backup zip" — zip now also includes patch SQL files + checklist).
