/* Kashish Beauty Salon — Supabase REST wrapper (v5: security hardened)
   - Public catalog reads stay direct (services, gallery, offers, coupons, beauticians, settings)
   - EVERYTHING sensitive goes through SECURITY DEFINER functions (rpc):
     customer auth, bookings, loyalty, coupons, owner actions (token-gated)
   - The owner PIN hash can no longer be read by anyone. */
var DB = (function(){
  "use strict";
  var base = CFG.SUPABASE_URL + "/rest/v1";

  function hdrs(){
    return {
      "apikey": CFG.SUPABASE_ANON_KEY,
      "Authorization": "Bearer " + CFG.SUPABASE_ANON_KEY,
      "Content-Type": "application/json"
    };
  }

  function handle(res){
    if (!res.ok) {
      return res.text().then(function(t){
        var err = new Error("DB error " + res.status);
        err.status = res.status; err.body = t;
        throw err;
      });
    }
    return res.json().catch(function(){ return null; });
  }

  function get(table, params){
    var qs = params ? "?" + params : "";
    return fetch(base + "/" + table + qs, { headers: hdrs() }).then(handle);
  }

  /* Call a SECURITY DEFINER function. Server-side {error: code} becomes a thrown Error with .code */
  function rpc(name, args){
    return fetch(base + "/rpc/" + name, {
      method: "POST",
      headers: hdrs(),
      body: JSON.stringify(args || {})
    }).then(handle).then(function(r){
      if (r && typeof r === "object" && !Array.isArray(r) && r.error){
        var e = new Error(r.error);
        e.code = r.error;
        throw e;
      }
      return r;
    });
  }

  function enc(v){ return encodeURIComponent(v); }

  function sha256(str){
    var buf = new TextEncoder().encode(str);
    return crypto.subtle.digest("SHA-256", buf).then(function(hash){
      return Array.prototype.map.call(new Uint8Array(hash), function(b){
        return ("0" + b.toString(16)).slice(-2);
      }).join("");
    });
  }

  /* ---------- owner session token (12h, validated server-side) ---------- */
  var OWNER_KEY = "kashish_owner_token";
  function ownerToken(){
    try { return localStorage.getItem(OWNER_KEY); } catch(e){ return null; }
  }
  function forgetToken(){
    try { localStorage.removeItem(OWNER_KEY); } catch(e){}
  }
  /* Owner-gated call: every owner write goes through owner_action */
  function ocall(action, data){
    var t = ownerToken();
    if (!t) return Promise.reject(Object.assign(new Error("no-token"), { code: "no-token" }));
    return rpc("owner_action", { p_token: t, p_action: action, p_data: data || {} })
      .then(function(r){
        if (r && r.error === "bad-token"){
          forgetToken();
          throw Object.assign(new Error("bad-token"), { code: "bad-token" });
        }
        return r;
      });
  }
  /* Owner-gated call to a standalone owner_* function (token injected) */
  function ocallFn(fn, args){
    var t = ownerToken();
    if (!t) return Promise.reject(Object.assign(new Error("no-token"), { code: "no-token" }));
    args = args || {};
    args.p_token = t;
    return rpc(fn, args).then(function(r){
      if (r && r.error === "bad-token"){
        forgetToken();
        throw Object.assign(new Error("bad-token"), { code: "bad-token" });
      }
      return r;
    });
  }

  return {
    sha256: sha256,
    rpc: rpc,

    /* ---- owner session ---- */
    ownerLogin: function(pin){
      return rpc("owner_login", { p_pin: pin }).then(function(tok){
        if (!tok) throw Object.assign(new Error("wrong-pin"), { code: "wrong-pin" });
        try { localStorage.setItem(OWNER_KEY, tok); } catch(e){}
        return tok;
      });
    },
    ownerLogout: function(){ forgetToken(); },
    ownerToken: ownerToken,
    ownerAuthed: function(){ return !!ownerToken(); },
    changePin: function(oldPin, newPin){
      return ocall("pin_change", { old_pin: oldPin, new_pin: newPin });
    },
    /* PIN recovery via one-time recovery code */
    recoveryStatus: function(){
      var t = ownerToken();
      if (!t) return Promise.resolve(false);
      return rpc("owner_recovery_status", { p_token: t }).catch(function(){ return false; });
    },
    recoveryIssue: function(){
      var t = ownerToken();
      if (!t) return Promise.reject(new Error("no-token"));
      return rpc("owner_recovery_issue", { p_token: t });
    },
    recoveryReset: function(code, newPin){
      return rpc("owner_recovery_reset", { p_code: code, p_new_pin: newPin })
        .then(function(newCode){
          if (!newCode) throw Object.assign(new Error("bad-code"), { code: "bad-code" });
          return newCode;
        });
    },

    /* ---- services (public catalog read) ---- */
    getServices: function(){
      return get("services", "select=*&active=eq.true&order=category,name");
    },
    seedServices: function(list){
      // post-v5: anon cannot insert services; kept best-effort for legacy DBs
      var chain = Promise.resolve();
      list.forEach(function(s){
        chain = chain.then(function(){
          return ocall("svc_upsert", {
            name: s.name, description: s.desc || "",
            price: s.price, duration_min: s.dur || 30,
            category: s.cat, active: true
          }).catch(function(){ /* ignore */ });
        });
      });
      return chain;
    },

    /* ---- bookings ---- */
    /* minimal slot info (no PII): [{id, time_slot, status, beautician_id}] */
    getBookingsByDate: function(dateIso){
      return rpc("slots_taken", { p_date: dateIso });
    },
    getAllBookings: function(limit){
      return ocall("booking_list", { limit: limit || 200 });
    },
    getUpcomingBookings: function(){
      var today = new Date().toISOString().slice(0, 10);
      return ocall("booking_list", { limit: 200 }).then(function(rows){
        return (rows || []).filter(function(b){
          return b.booking_date >= today &&
            (b.status === "pending" || b.status === "confirmed");
        }).sort(function(a, b){
          return (a.booking_date + a.time_slot) < (b.booking_date + b.time_slot) ? -1 : 1;
        });
      });
    },
    getPendingPayments: function(){
      return ocall("pending_payments", {});
    },
    /* secure booking: price/coupon/loyalty all validated server-side */
    placeBooking: function(data){
      return rpc("place_booking", { p_data: data });
    },
    rescheduleBooking: function(ref, phone, hash, date, slot){
      return rpc("reschedule_booking", {
        p_ref: ref, p_phone: phone, p_hash: hash, p_date: date, p_slot: slot
      });
    },
    setBookingStatus: function(id, status){
      return ocall("booking_status", { id: id, status: status });
    },
    setPaymentStatus: function(id, payment_status){
      return ocall("booking_payment", { id: id, payment_status: payment_status });
    },
    walkinBooking: function(data){
      return ocall("booking_walkin", data);
    },

    /* ---- customers / auth (all server-side) ---- */
    signupCustomer: function(name, phone, whatsapp, passwordHash){
      return rpc("customer_signup", {
        p_name: name, p_phone: phone, p_whatsapp: whatsapp || "", p_hash: passwordHash
      });
    },
    loginCustomer: function(phone, passwordHash){
      return rpc("customer_login", { p_phone: phone, p_hash: passwordHash });
    },
    getCustomerAuth: function(phone, passwordHash){
      return rpc("customer_get", { p_phone: phone, p_hash: passwordHash });
    },
    setCustomerWhatsapp: function(phone, passwordHash, whatsapp){
      return rpc("customer_set_whatsapp", {
        p_phone: phone, p_hash: passwordHash, p_wa: whatsapp
      });
    },
    getBookingsByPhone: function(phone, passwordHash){
      return rpc("my_bookings", { p_phone: phone, p_hash: passwordHash });
    },
    cancelBooking: function(refCode, phone, passwordHash){
      return rpc("cancel_booking", {
        p_ref: refCode, p_phone: phone, p_hash: passwordHash
      });
    },
    rateBooking: function(refCode, phone, passwordHash, rating, review){
      return rpc("rate_service", {
        p_ref: refCode, p_phone: phone, p_hash: passwordHash,
        p_rating: rating, p_review: review || ""
      });
    },

    /* ---- loyalty config (public read; owner writes) ---- */
    getLoyaltyConfig: function(){
      return get("loyalty_config", "select=*&id=eq.1").then(function(r){
        return (r && r[0]) || { points_per_100rs: 1, redeem_points: 100, redeem_value_rs: 100, min_redeem_points: 100 };
      });
    },
    saveLoyaltyConfig: function(cfg){
      return ocall("loyalty_config_save", cfg);
    },
    awardLoyalty: function(customerId, points, reason){
      return ocall("loyalty_award", { id: customerId, points: points, reason: reason || "" });
    },

    /* ---- connectivity probe ---- */
    ping: function(){
      return get("services", "select=id&limit=1").then(function(){ return true; })
        .catch(function(e){ if (e && e.status === 404) return "no-tables"; throw e; });
    },

    /* ---- services manager (owner) ---- */
    addService: function(row){ return ocall("svc_upsert", row); },
    updateService: function(id, patch){
      var d = {}; for (var k in patch) d[k] = patch[k];
      d.id = id;
      return ocall("svc_upsert", d);
    },
    deleteService: function(id){ return ocall("svc_delete", { id: id }); },

    /* ---- gallery (public read; owner writes) ---- */
    getGallery: function(){
      return get("gallery", "select=*&order=sort_order,created_at");
    },
    addGalleryItem: function(imageUrl, caption){
      return ocall("gal_add", { image_url: imageUrl, caption: caption || "" });
    },
    deleteGalleryItem: function(id){ return ocall("gal_delete", { id: id }); },

    /* ---- salon settings (PIN hash blocked server-side) ---- */
    getSetting: function(key){
      return get("salon_settings", "select=value&key=eq." + enc(key))
        .then(function(r){ return (r && r.length) ? r[0].value : null; })
        .catch(function(){ return null; });
    },
    setSetting: function(key, value){
      return ocall("setting_set", { key: key, value: value });
    },

    /* ---- forgot password / OTP reset (server-side, rate-limited) ---- */
    createResetOTP: function(phone){
      return rpc("otp_request", { p_phone: phone });
    },
    resetPassword: function(phone, otp, newHash){
      return rpc("otp_reset", { p_phone: phone, p_otp: otp, p_new_hash: newHash })
        .then(function(ok){
          if (!ok) throw Object.assign(new Error("invalid-otp"), { code: "invalid-otp" });
          return true;
        });
    },
    getPendingResets: function(){ return ocall("reset_list", {}); },
    markResetSent: function(id){ return ocall("reset_dismiss", { id: id }); },

    /* ---- image upload to Supabase Storage (images only, server-enforced) ---- */
    uploadImage: function(file){
      var ext = (file.name && file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      var filename = "img_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8) + "." + ext;
      var url = CFG.SUPABASE_URL + "/storage/v1/object/salon-media/" + filename;
      return fetch(url, {
        method: "POST",
        headers: {
          "apikey": CFG.SUPABASE_ANON_KEY,
          "Authorization": "Bearer " + CFG.SUPABASE_ANON_KEY,
          "Content-Type": file.type || "image/jpeg"
        },
        body: file
      }).then(function(res){
        if (!res.ok) throw new Error("upload failed " + res.status);
        return CFG.SUPABASE_URL + "/storage/v1/object/public/salon-media/" + filename;
      });
    },

    /* ---- beauticians (public read; owner writes) ---- */
    getBeauticians: function(){
      return get("beauticians", "select=*&is_active=eq.true&order=name").catch(function(){ return []; });
    },
    getAllBeauticians: function(){
      return get("beauticians", "select=*&order=name").catch(function(){ return []; });
    },
    addBeautician: function(row){ return ocall("beaut_upsert", row); },
    updateBeautician: function(id, patch){
      var d = {}; for (var k in patch) d[k] = patch[k];
      d.id = id;
      return ocall("beaut_upsert", d);
    },

    /* ---- offers (public read; owner writes) ---- */
    getOffers: function(){
      var today = new Date().toISOString().slice(0, 10);
      return get("offers",
        "select=*&is_active=eq.true&or=(valid_till.is.null,valid_till.gte." + today + ")&order=created_at.desc"
      ).catch(function(){ return []; });
    },
    getAllOffers: function(){
      return get("offers", "select=*&order=created_at.desc").catch(function(){ return []; });
    },
    addOffer: function(row){ return ocall("offer_upsert", row); },
    updateOffer: function(id, patch){
      var d = {}; for (var k in patch) d[k] = patch[k];
      d.id = id;
      return ocall("offer_upsert", d);
    },

    /* ---- coupons ---- */
    /* server-side preview (validity + exact discount) */
    validateCoupon: function(code, amount){
      return rpc("validate_coupon", { p_code: code, p_amount: amount });
    },
    getAllCoupons: function(){
      return get("coupons", "select=*&order=created_at.desc").catch(function(){ return []; });
    },
    addCoupon: function(row){ return ocall("coupon_upsert", row); },
    updateCoupon: function(id, patch){
      var d = {}; for (var k in patch) d[k] = patch[k];
      d.id = id;
      return ocall("coupon_upsert", d);
    },

    /* ---- favorites (authed) ---- */
    getFavorites: function(phone, passwordHash){
      return rpc("fav_list", { p_phone: phone, p_hash: passwordHash })
        .then(function(r){
          if (!r || r.error) return [];
          return r.map(function(sid){ return { service_id: sid }; });
        });
    },
    addFavorite: function(phone, passwordHash, serviceId){
      return rpc("fav_add", {
        p_phone: phone, p_hash: passwordHash, p_service_id: String(serviceId)
      }).catch(function(){ return null; });
    },
    removeFavorite: function(phone, passwordHash, serviceId){
      return rpc("fav_remove", {
        p_phone: phone, p_hash: passwordHash, p_service_id: String(serviceId)
      }).catch(function(){ return null; });
    },

    /* ---- reviews (public, no PII beyond first name) ---- */
    getServiceReviews: function(serviceId){
      return rpc("service_reviews", { p_service_id: serviceId }).catch(function(){ return []; });
    },

    /* ---- customers list / delete (owner) ---- */
    getCustomers: function(){ return ocallFn("owner_customers_list", {}); },
    deleteCustomer: function(id){ return ocall("customer_delete", { id: id }); },
    setCustomerBlocked: function(id, blocked){
      return ocallFn("owner_customer_set_blocked", { p_customer_id: id, p_blocked: !!blocked });
    },
    getCustomerBookings: function(phone){
      return ocallFn("owner_customer_bookings", { p_phone: phone });
    },
    lookupCustomer: function(phone){ return ocall("customer_lookup", { phone: phone }); }
  };
})();
