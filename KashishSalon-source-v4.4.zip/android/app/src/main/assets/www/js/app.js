/* Kashish Beauty Salon — main app */
(function(){
  "use strict";

  /* ---------- helpers (global) ---------- */
  window.toast = function(msg){
    var t = document.getElementById("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(t._h);
    t._h = setTimeout(function(){ t.classList.remove("show"); }, 2600);
  };

  window.gotoPage = function(name){
    document.querySelectorAll(".page").forEach(function(p){ p.classList.remove("active"); });
    var pg = document.getElementById("page-" + name);
    if (pg) pg.classList.add("active");
    document.querySelectorAll("#tabbar .tab").forEach(function(t){
      t.classList.toggle("active", t.getAttribute("data-goto") === name);
    });
    window.scrollTo(0, 0);
  };

  function waLink(text){
    return "whatsapp://send?phone=" + CFG.SALON.whatsapp + "&text=" +
      encodeURIComponent(text || "Assalam-o-Alaikum! I want to book an appointment at Kashish Beauty Salon.");
  }

  function esc(s){ return String(s == null ? "" : s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"); }

  /* ---------- modal helper (v4) ---------- */
  function openModal(html){
    var m = document.getElementById("modal");
    document.getElementById("modalBox").innerHTML = html;
    m.classList.add("show");
    m.onclick = function(e){ if (e.target === m) closeModal(); };
  }
  function closeModal(){
    document.getElementById("modal").classList.remove("show");
  }

  /* ---------- favorites (v4) ---------- */
  var FAVS = []; // service ids as strings
  function loadFavs(){
    var s = Auth.current();
    if (!s){ FAVS = []; return Promise.resolve([]); }
    return DB.getFavorites(s.id).then(function(rows){
      FAVS = (rows || []).map(function(r){ return String(r.service_id); });
      return FAVS;
    }).catch(function(){ FAVS = []; return []; });
  }
  function isFav(id){ return FAVS.indexOf(String(id)) >= 0; }
  function toggleFav(id, btn){
    var s = Auth.current();
    if (!s){ toast("Please login to save favorites"); gotoPage("profile"); return; }
    var sid = String(id);
    if (isFav(sid)){
      DB.removeFavorite(s.id, sid).then(function(){
        FAVS = FAVS.filter(function(x){ return x !== sid; });
        if (btn) btn.innerHTML = "&#9825;";
        toast("Removed from favorites");
        renderFavSection();
      }).catch(function(){ toast("Failed — check internet"); });
    } else {
      DB.addFavorite(s.id, sid).then(function(){
        if (!isFav(sid)) FAVS.push(sid);
        if (btn) btn.innerHTML = "&#10084;";
        toast("Added to favorites");
        renderFavSection();
      }).catch(function(){ toast("Failed — check internet"); });
    }
  }

  /* ---------- service lookup / stars ---------- */
  function findSvcById(id){
    return svcList().filter(function(s){ return String(s.id) === String(id); })[0] || null;
  }
  function findSvcByName(name){
    var n = String(name || "").toLowerCase();
    return svcList().filter(function(s){ return String(s.name).toLowerCase() === n; })[0] || null;
  }
  function starRow(n){
    var s = "";
    for (var i = 1; i <= 5; i++) s += i <= n ? "&#9733;" : "&#9734;";
    return s;
  }
  function firstName(n){
    return String(n || "Guest").trim().split(" ")[0] || "Guest";
  }

  /* ---------- splash ---------- */
  function hideSplash(){
    var s = document.getElementById("splash");
    if (s) s.classList.add("hide");
  }
  window.addEventListener("load", function(){
    setTimeout(hideSplash, 1200);
  });
  // fallback: hide even if window load is delayed
  setTimeout(hideSplash, 4000);

  /* ---------- contact wiring (tel: bug fixed — real number) ---------- */
  document.getElementById("waBookHero") && (document.getElementById("waBookHero").href = waLink());
  document.getElementById("waBtn").href = waLink();
  document.getElementById("callBtn").href = "tel:" + CFG.SALON.phone;
  document.getElementById("callBtn2").href = "tel:" + CFG.SALON.phone;
  document.getElementById("instaBtn").href = CFG.SALON.instagram;
  document.getElementById("homeWaBtn").href = waLink();
  document.getElementById("addrText").textContent = CFG.SALON.address;
  document.getElementById("phoneText").textContent = "+92 312 7830765";

  /* ---------- navigation ---------- */
  document.querySelectorAll("[data-goto]").forEach(function(elm){
    elm.addEventListener("click", function(e){
      e.preventDefault();
      var name = elm.getAttribute("data-goto");
      if (name === "owner"){ Owner.open(); return; }
      if (name === "booking" && !Auth.isLoggedIn()){
        toast("Please login or sign up to book");
        gotoPage("profile");
        return;
      }
      if (name === "profile") renderProfile();
      gotoPage(name);
    });
  });
  document.getElementById("ownerBtn").addEventListener("click", function(){ Owner.open(); });
  document.getElementById("ownerLink").addEventListener("click", function(e){
    e.preventDefault(); Owner.open();
  });

  /* ---------- gallery (v3: owner-managed via Supabase, local fallback) ---------- */
  var GALLERY_REMOTE = null;
  function galList(){
    return GALLERY_REMOTE && GALLERY_REMOTE.length ? GALLERY_REMOTE : GALLERY;
  }
  function renderGalleryInto(elm, list, limit){
    elm.innerHTML = "";
    (limit ? list.slice(0, limit) : list).forEach(function(src){
      var img = document.createElement("img");
      img.src = src; img.alt = "";
      img.onerror = function(){ this.style.display = "none"; };
      elm.appendChild(img);
    });
  }
  function loadGallery(){
    DB.getGallery().then(function(rows){
      if (rows && rows.length){
        GALLERY_REMOTE = rows.map(function(g){ return g.image_url; });
      }
      renderGalleryInto(document.getElementById("galPreview"), galList(), 6);
      renderGalleryInto(document.getElementById("galGrid"), galList());
    }).catch(function(){
      renderGalleryInto(document.getElementById("galPreview"), galList(), 6);
      renderGalleryInto(document.getElementById("galGrid"), galList());
    });
  }

  /* ---------- home ---------- */
  function catName(id){
    var c = CATEGORIES.filter(function(x){ return x.id === id; })[0];
    return c ? c.icon + " " + c.name : id;
  }

  /* ---------- v4 home: popular / recommended / offers / upcoming ---------- */
  function svcCardEl(s){
    var d = document.createElement("div");
    d.className = "pop-card";
    var img = s.image_url
      ? '<img src="' + s.image_url + '" alt="" onerror="this.style.display=\'none\'">'
      : '<div class="pop-noimg">' + esc(String(s.name || "?").charAt(0)) + "</div>";
    d.innerHTML = img +
      '<button class="fav-btn" title="Favorite">' + (isFav(s.id) ? "&#10084;" : "&#9825;") + "</button>" +
      '<div class="pop-info"><strong>' + esc(s.name) + "</strong>" +
      "<span>" + rs(s.price) + " • " + (s.duration_min || 30) + " min</span></div>";
    d.querySelector(".fav-btn").addEventListener("click", function(e){
      e.stopPropagation();
      toggleFav(s.id, this);
    });
    d.addEventListener("click", function(){ showServiceDetail(s.id); });
    return d;
  }

  function renderPopular(){
    var row = document.getElementById("popularRow");
    if (!row) return;
    row.innerHTML = "";
    var list = svcList().filter(function(s){ return s.is_featured; }).slice(0, 10);
    if (!list.length) list = svcList().slice(0, 10);
    list.forEach(function(s){ row.appendChild(svcCardEl(s)); });
  }

  function renderRecommended(){
    var sec = document.getElementById("recoSection");
    var row = document.getElementById("recoRow");
    if (!sec || !row) return;
    sec.style.display = "none";
    var s = Auth.current();
    if (!s) return;
    Promise.all([DB.getFavorites(s.id), DB.getBookingsByPhone(s.phone)]).then(function(r){
      var favIds = (r[0] || []).map(function(x){ return String(x.service_id); });
      var bookings = r[1] || [];
      var bookedIds = {}, bookedCats = {};
      bookings.forEach(function(b){
        if (b.service_id){
          bookedIds[String(b.service_id)] = true;
          var sv1 = findSvcById(b.service_id);
          if (sv1) bookedCats[sv1.category] = true;
        }
        var sv2 = findSvcByName(b.service_name);
        if (sv2){ bookedIds[String(sv2.id)] = true; bookedCats[sv2.category] = true; }
      });
      var all = svcList();
      var picks = [];
      favIds.forEach(function(fid){
        if (picks.length >= 6) return;
        var svc = all.filter(function(x){ return String(x.id) === fid; })[0];
        if (svc) picks.push(svc);
      });
      all.forEach(function(svc){
        if (picks.length >= 6) return;
        if (bookedIds[String(svc.id)]) return;
        if (picks.indexOf(svc) >= 0) return;
        if (bookedCats[svc.category]) picks.push(svc);
      });
      if (!picks.length) return;
      row.innerHTML = "";
      picks.forEach(function(svc){ row.appendChild(svcCardEl(svc)); });
      sec.style.display = "";
    }).catch(function(){ /* stay hidden */ });
  }

  function renderOffers(){
    var sec = document.getElementById("offersSection");
    var list = document.getElementById("offersList");
    if (!sec || !list) return;
    sec.style.display = "none";
    DB.getOffers().then(function(rows){
      if (!rows || !rows.length) return;
      list.innerHTML = "";
      rows.forEach(function(o){
        var d = document.createElement("div");
        d.className = "offer-slide";
        d.innerHTML =
          (o.image_url ? '<img src="' + o.image_url + '" alt="" onerror="this.style.display=\'none\'">' : "") +
          '<div class="offer-slide-body"><strong>' + esc(o.title) + "</strong>" +
          (o.discount_text ? '<span class="offer-code">' + esc(o.discount_text) + "</span>" : "") +
          (o.valid_till ? "<small>Valid till " + fmtDate(o.valid_till) + "</small>" : "") +
          "</div>";
        d.addEventListener("click", function(){ showOffer(o); });
        list.appendChild(d);
      });
      sec.style.display = "";
    }).catch(function(){ /* stay hidden */ });
  }

  function showOffer(o){
    openModal(
      '<h3 class="sec-title">' + esc(o.title) + "</h3>" +
      (o.image_url ? '<img src="' + o.image_url + '" style="width:100%;border-radius:12px;margin-bottom:10px" alt="">' : "") +
      (o.discount_text ? '<p style="margin-bottom:8px"><span class="offer-code">' + esc(o.discount_text) + "</span></p>" : "") +
      "<p>" + esc(o.description || "") + "</p>" +
      (o.terms ? '<p class="muted" style="margin-top:8px"><strong>Terms:</strong> ' + esc(o.terms) + "</p>" : "") +
      (o.valid_till ? '<p class="muted">Valid till ' + fmtDate(o.valid_till) + "</p>" : "") +
      '<button class="btn btn-gold btn-block" id="offerClose">Close</button>'
    );
    document.getElementById("offerClose").onclick = closeModal;
  }

  function renderUpcomingCard(){
    var card = document.getElementById("upcomingCard");
    if (!card) return;
    card.style.display = "none";
    var s = Auth.current();
    if (!s) return;
    DB.getBookingsByPhone(s.phone).then(function(rows){
      var today = new Date().toISOString().slice(0, 10);
      var next = (rows || []).filter(function(b){
        return (b.status === "pending" || b.status === "confirmed") && b.booking_date >= today;
      }).sort(function(a, b){
        var ka = a.booking_date + a.time_slot, kb = b.booking_date + b.time_slot;
        return ka < kb ? -1 : (ka > kb ? 1 : 0);
      })[0];
      if (!next) return;
      card.innerHTML =
        '<div class="up-head"><span class="up-label">Upcoming Appointment</span>' +
        (next.ref_code ? '<span class="ref-chip">' + esc(next.ref_code) + "</span>" : "") + "</div>" +
        "<strong>" + esc(next.service_name) + "</strong>" +
        "<p>" + fmtDate(next.booking_date) + " • " + fmtSlot(next.time_slot) + "</p>" +
        '<button class="btn btn-outline btn-block" id="upViewBtn">View</button>';
      card.style.display = "";
      document.getElementById("upViewBtn").addEventListener("click", function(){
        renderProfile();
        gotoPage("profile");
      });
    }).catch(function(){ /* stay hidden */ });
  }

  function applyInstagram(url){
    var els = [document.getElementById("instaBtn")].filter(Boolean);
    document.querySelectorAll('a[href*="instagram.com"]').forEach(function(a){ els.push(a); });
    els.forEach(function(a){ a.href = url; });
  }

  function loadInstagram(){
    DB.getSetting("instagram_url").then(function(v){
      applyInstagram(v || CFG.DEFAULT_INSTAGRAM || CFG.SALON.instagram);
    }).catch(function(){ applyInstagram(CFG.DEFAULT_INSTAGRAM || CFG.SALON.instagram); });
  }

  function renderHome(){
    var hc = document.getElementById("homeCats");
    hc.innerHTML = "";
    CATEGORIES.forEach(function(c){
      var d = document.createElement("button");
      d.className = "chip";
      d.innerHTML = c.icon + " " + c.name;
      d.addEventListener("click", function(){ gotoPage("services"); });
      hc.appendChild(d);
    });
    renderPopular();
    renderRecommended();
    renderOffers();
    renderUpcomingCard();
    var gp = document.getElementById("galPreview");
    renderGalleryInto(gp, galList(), 6);
    var gg = document.getElementById("galGrid");
    renderGalleryInto(gg, galList());
  }

  /* ---------- services ---------- */
  var activeCat = "all";
  function svcList(){
    return DB_SERVICES.length ? DB_SERVICES : SERVICES.map(function(s, i){
      return { id: "local-" + i, name: s.name, price: s.price,
               duration_min: s.dur || 30, category: s.cat,
               description: s.desc || "" };
    });
  }

  function renderServices(){
    var tabs = document.getElementById("catTabs");
    tabs.innerHTML = "";
    var all = document.createElement("button");
    all.className = "cat-tab" + (activeCat === "all" ? " active" : "");
    all.textContent = "All";
    all.onclick = function(){ activeCat = "all"; renderServices(); };
    tabs.appendChild(all);
    CATEGORIES.forEach(function(c){
      var b = document.createElement("button");
      b.className = "cat-tab" + (activeCat === c.id ? " active" : "");
      b.textContent = c.icon + " " + c.name;
      b.onclick = function(){ activeCat = c.id; renderServices(); };
      tabs.appendChild(b);
    });

    var q = document.getElementById("svcSearch").value.trim().toLowerCase();
    var list = document.getElementById("svcList");
    list.innerHTML = "";
    var any = false;
    var cats = activeCat === "all" ? CATEGORIES.map(function(c){ return c.id; }) : [activeCat];
    cats.forEach(function(cid){
      var items = svcList().filter(function(s){
        if (s.category !== cid) return false;
        if (q && (s.name + " " + (s.description || "")).toLowerCase().indexOf(q) < 0) return false;
        return true;
      });
      if (!items.length) return;
      any = true;
      var h = document.createElement("div");
      h.className = "svc-cat"; h.textContent = catName(cid);
      list.appendChild(h);
      items.forEach(function(s){
        var d = document.createElement("div");
        d.className = "svc";
        var info = document.createElement("div");
        info.className = "svc-info";
        info.innerHTML = "<strong>" + s.name + "</strong>" +
          (s.description ? "<span>" + s.description + "</span>" : "");
        info.style.cursor = "pointer";
        info.onclick = function(){ showServiceDetail(s.id); };
        var pr = document.createElement("div");
        pr.className = "svc-price";
        pr.innerHTML = rs(s.price) + " <small>• " + (s.duration_min || 30) + " min</small>";
        var fav = document.createElement("button");
        fav.className = "fav-btn";
        fav.title = "Favorite";
        fav.innerHTML = isFav(s.id) ? "&#10084;" : "&#9825;";
        fav.onclick = function(e){ e.stopPropagation(); toggleFav(s.id, fav); };
        var btn = document.createElement("button");
        btn.className = "book-btn"; btn.textContent = "Book";
        btn.onclick = function(){ Booking.startForService(s.id); };
        d.appendChild(info); d.appendChild(pr); d.appendChild(fav); d.appendChild(btn);
        list.appendChild(d);
      });
    });
    if (!any) list.innerHTML = '<div class="empty">No services found. Try another search.</div>';
  }

  /* ---------- v4: service details screen ---------- */
  function showServiceDetail(id){
    var s = findSvcById(id);
    if (!s) return;
    var body = document.getElementById("sdetBody");
    body.innerHTML = "<p style='padding:16px'>Loading...</p>";
    gotoPage("sdetail");
    window.scrollTo(0, 0);
    var revP = (String(s.id).indexOf("local-") === 0)
      ? Promise.resolve([])
      : DB.getServiceReviews(s.id);
    revP.then(function(revs){
      var count = revs.length;
      var avg = count ? revs.reduce(function(a, r){ return a + (r.rating || 0); }, 0) / count : 0;
      var starsHtml = count
        ? '<span class="stars">' + starRow(Math.round(avg)) + '</span> <span class="muted">' +
          avg.toFixed(1) + " (" + count + " review" + (count > 1 ? "s" : "") + ")</span>"
        : '<span class="muted">No reviews yet — be the first!</span>';
      var h = "";
      h += '<div class="sdet-hero">' +
             (s.image_url ? '<img src="' + s.image_url + '" alt="" onerror="this.style.display=\'none\'">' : "") +
             '<button class="fav-btn sdet-fav" id="sdetFav" title="Favorite">' +
               (isFav(s.id) ? "&#10084;" : "&#9825;") + "</button></div>";
      h += '<div class="sdet-body">';
      h += "<h2>" + esc(s.name) + "</h2>";
      h += '<div class="sdet-stars">' + starsHtml + "</div>";
      h += '<p class="sdet-price">' + rs(s.price) + " <span>• " + (s.duration_min || 30) + " min</span></p>";
      if (s.description) h += '<p class="sdet-desc">' + esc(s.description) + "</p>";
      h += '<h3 class="sec-title">Good to know</h3><ul class="sdet-tips">' +
           "<li>Please arrive 10 minutes before your appointment</li>" +
           "<li>Free cancellation up to 24 hours before</li>" +
           "<li>Patch test available on request for color &amp; skin treatments</li></ul>";
      h += '<button class="btn btn-gold btn-block" id="sdetBook">Book Now</button>';
      if (count) h += '<h3 class="sec-title" style="margin-top:18px">Customer Reviews</h3><div id="sdetRevs"></div>';
      h += "</div>";
      body.innerHTML = h;
      document.getElementById("sdetFav").addEventListener("click", function(){
        toggleFav(s.id, this);
      });
      document.getElementById("sdetBook").addEventListener("click", function(){
        Booking.startForService(s.id);
      });
      if (count){
        var rw = document.getElementById("sdetRevs");
        revs.slice(0, 10).forEach(function(r){
          var d = document.createElement("div");
          d.className = "review-card";
          d.innerHTML = '<div class="rev-head"><strong>' + esc(firstName(r.customer_name)) + "</strong>" +
                        '<span class="stars">' + starRow(r.rating || 0) + "</span></div>" +
                        (r.review ? "<p>" + esc(r.review) + "</p>" : "");
          rw.appendChild(d);
        });
      }
    }).catch(function(){
      body.innerHTML = "<p style='padding:16px'>Could not load details.</p>";
    });
  }

  /* ---------- loyalty page ---------- */
  function initLoyalty(){
    DB.getLoyaltyConfig().then(function(c){
      var ul = document.getElementById("loyalRules");
      ul.innerHTML =
        "<li>Earn <strong>" + c.points_per_100rs + " point(s)</strong> for every Rs.100 you spend</li>" +
        "<li><strong>" + c.redeem_points + " points = " + rs(c.redeem_value_rs) + " off</strong> your next booking</li>" +
        "<li>You need at least <strong>" + c.min_redeem_points + " points</strong> to redeem</li>" +
        "<li>Just give your mobile number when booking — points add automatically</li>";
    }).catch(function(){});
    document.getElementById("loyalCheck").addEventListener("click", function(){
      var phone = normPhone(document.getElementById("loyalPhone").value);
      if (!phone){ toast("Enter a valid mobile number"); return; }
      DB.getCustomer(phone).then(function(c){
        var box = document.getElementById("loyalResult");
        box.style.display = "";
        document.getElementById("loyalPts").textContent = c ? (c.loyalty_points || 0) : 0;
        if (!c) toast("No record found for this number yet");
      }).catch(function(){ toast("Could not check — check internet"); });
    });
  }

  /* ---------- database init + seed ---------- */
  function initDB(){
    DB.ping().then(function(st){
      if (st === "no-tables"){
        toast("Database tables not ready yet");
        return;
      }
      return DB.getServices().then(function(rows){
        if (rows && rows.length){
          DB_SERVICES = rows;
        } else if (CFG.SEED_ON_EMPTY){
          // first launch: seed default services, then reload
          return DB.seedServices(SERVICES).then(function(){
            return DB.getServices().then(function(r2){ DB_SERVICES = r2 || []; });
          });
        }
      });
    }).then(function(){
      renderServices();
      Booking.refreshServices();
      // home cards (Popular / Recommended) may have rendered from the local
      // fallback before the network fetch finished — re-render with DB data
      // so service pictures appear (or fall back to letters if none set)
      renderPopular();
      renderRecommended();
    }).catch(function(){
      // offline or tables missing — use local list
      renderServices();
      Booking.refreshServices();
    });
  }

  /* ---------- profile / auth (v3) ---------- */
  function statusPillUser(s){
    var map = { pending: "status-pending", confirmed: "status-confirmed",
                completed: "status-completed", cancelled: "status-cancelled" };
    return '<span class="bk-status ' + (map[s] || "status-pending") + '">' + s + '</span>';
  }

  /* ---------- v4 profile: tabs, ratings, favorites, notifications ---------- */
  var profTab = "upcoming";

  function renderProfile(){
    var s = Auth.current();
    document.getElementById("profileLoggedOut").style.display = s ? "none" : "";
    document.getElementById("profileLoggedIn").style.display = s ? "" : "none";
    if (!s) return;
    document.getElementById("profName").textContent = "Welcome, " + s.name;
    document.getElementById("profPhone").textContent = s.phone;
    renderMyBookings(s);
    renderFavSection();
    initNotifToggles();
    DB.getCustomer(s.phone).then(function(c){
      document.getElementById("profPoints").textContent = c ? (c.loyalty_points || 0) : 0;
    }).catch(function(){});
  }

  function renderMyBookings(s){
    var wrap = document.getElementById("myBookings");
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getBookingsByPhone(s.phone).then(function(rows){
      document.getElementById("profBookings").textContent = (rows || []).length;
      var today = new Date().toISOString().slice(0, 10);
      var list = (rows || []).filter(function(b){
        if (profTab === "upcoming") return (b.status === "pending" || b.status === "confirmed") && b.booking_date >= today;
        if (profTab === "completed") return b.status === "completed";
        return b.status === "cancelled";
      });
      wrap.innerHTML = "";
      if (!list.length){
        wrap.innerHTML = '<div class="empty">No ' + profTab + " bookings.</div>";
        return;
      }
      list.forEach(function(b){
        var d = document.createElement("div");
        d.className = "bk-item";
        d.innerHTML =
          '<div class="bk-head"><strong>' + esc(b.service_name) + "</strong>" + statusPillUser(b.status) + "</div>" +
          '<div class="bk-meta">' + fmtDate(b.booking_date) + " • " + fmtSlot(b.time_slot) +
          " • " + rs(b.price) +
          (b.ref_code ? '<br><span class="ref-chip">' + esc(b.ref_code) + "</span>" : "") + "</div>" +
          '<div class="bk-actions"></div>';
        var acts = d.querySelector(".bk-actions");
        function ab(label, fn){
          var x = document.createElement("button");
          x.className = "mini-btn"; x.textContent = label;
          x.onclick = fn;
          acts.appendChild(x);
        }
        if (profTab === "upcoming"){
          ab("Reschedule", function(){ Booking.reschedule(b.id, b.booking_date, b.time_slot); });
          ab("Cancel Booking", function(){
            if (!confirm("Cancel this booking?")) return;
            DB.cancelBooking(b.id).then(function(){
              toast("Booking cancelled");
              renderMyBookings(s);
              renderUpcomingCard();
            }).catch(function(){ toast("Failed — check internet"); });
          });
        }
        if (profTab === "completed"){
          ab(b.rating ? "Update Rating" : "Rate", function(){ openRateModal(b, s); });
        }
        wrap.appendChild(d);
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function openRateModal(b, s){
    var cur = b.rating || 0;
    openModal(
      '<h3 class="sec-title">Rate your visit</h3>' +
      '<p class="muted" style="margin-bottom:8px">' + esc(b.service_name) + "</p>" +
      '<div class="stars" id="rateStars"></div>' +
      '<div class="form-group" style="margin-top:10px"><label>Review (optional)</label>' +
      '<textarea id="rateText" rows="3" placeholder="How was your experience?"></textarea></div>' +
      '<button class="btn btn-gold btn-block" id="rateSave">Save Rating</button>' +
      '<button class="btn btn-outline btn-block" id="rateCancel">Cancel</button>'
    );
    var box = document.getElementById("rateStars");
    function paint(){
      box.innerHTML = "";
      for (var i = 1; i <= 5; i++){
        (function(i){
          var st = document.createElement("button");
          st.type = "button";
          st.className = "star-btn" + (i <= cur ? " on" : "");
          st.innerHTML = "&#9733;";
          st.onclick = function(){ cur = i; paint(); };
          box.appendChild(st);
        })(i);
      }
    }
    paint();
    document.getElementById("rateText").value = b.review || "";
    document.getElementById("rateCancel").onclick = closeModal;
    document.getElementById("rateSave").onclick = function(){
      if (!cur){ toast("Please tap the stars to rate"); return; }
      var txt = document.getElementById("rateText").value.trim();
      toast("Saving...");
      DB.updateBooking(b.id, { rating: cur, review: txt }).then(function(){
        closeModal();
        toast("Thanks for your feedback!");
        renderMyBookings(s);
      }).catch(function(){ toast("Failed — check internet"); });
    };
  }

  function renderFavSection(){
    var sec = document.getElementById("favSection");
    var list = document.getElementById("favList");
    if (!sec || !list) return;
    sec.style.display = "none";
    var s = Auth.current();
    if (!s || !FAVS.length) return;
    var items = svcList().filter(function(x){ return FAVS.indexOf(String(x.id)) >= 0; });
    if (!items.length) return;
    list.innerHTML = "";
    items.forEach(function(svc){
      var d = document.createElement("div");
      d.className = "svc";
      d.innerHTML = '<div class="svc-info"><strong>' + esc(svc.name) + "</strong></div>" +
        '<div class="svc-price">' + rs(svc.price) + "</div>" +
        '<button class="fav-btn" title="Remove">&#10084;</button>';
      d.querySelector(".svc-info").style.cursor = "pointer";
      d.querySelector(".svc-info").onclick = function(){ showServiceDetail(svc.id); };
      d.querySelector(".fav-btn").onclick = function(){ toggleFav(svc.id, null); };
      list.appendChild(d);
    });
    sec.style.display = "";
  }

  function initNotifToggles(){
    function get(k, def){
      try { var v = localStorage.getItem("kashish_notif_" + k); return v === null ? def : v === "1"; }
      catch(e){ return def; }
    }
    function set(k, v){
      try { localStorage.setItem("kashish_notif_" + k, v ? "1" : "0"); } catch(e){}
    }
    var r = document.getElementById("ntfRemind"), o = document.getElementById("ntfOffers");
    if (!r || !o) return;
    r.checked = get("remind", true);
    o.checked = get("offers", true);
    r.onchange = function(){ set("remind", r.checked); toast(r.checked ? "Reminders ON" : "Reminders OFF"); };
    o.onchange = function(){ set("offers", o.checked); toast(o.checked ? "Offers updates ON" : "Offers updates OFF"); };
  }

  function initProfileExtras(){
    document.querySelectorAll("#profBkTabs .cat-tab").forEach(function(t){
      t.onclick = function(){
        document.querySelectorAll("#profBkTabs .cat-tab").forEach(function(x){ x.classList.remove("active"); });
        t.classList.add("active");
        profTab = t.getAttribute("data-pt");
        var s = Auth.current();
        if (s) renderMyBookings(s);
      };
    });
    document.getElementById("privacyLink").addEventListener("click", function(e){
      e.preventDefault(); gotoPage("privacy");
    });
    document.getElementById("delAccountLink").addEventListener("click", function(){
      var s = Auth.current();
      if (!s) return;
      if (!confirm("Delete your account permanently? This cannot be undone.")) return;
      if (!confirm("Last chance — delete " + s.name + "'s account and all data?")) return;
      toast("Deleting...");
      DB.deleteCustomer(s.id).then(function(){
        Auth.logout();
        FAVS = [];
        toast("Account deleted");
        renderProfile();
        renderHome();
        gotoPage("home");
      }).catch(function(){ toast("Failed — check internet"); });
    });
  }

  function initAuth(){
    document.getElementById("loginBtn").addEventListener("click", function(){
      var phone = normPhone(document.getElementById("loginPhone").value);
      var pass = document.getElementById("loginPass").value;
      if (!phone){ toast("Enter a valid mobile number"); return; }
      if (!pass){ toast("Enter your password"); return; }
      toast("Logging in...");
      Auth.login(phone, pass).then(function(s){
        toast("Welcome, " + s.name + "!");
        document.getElementById("loginPass").value = "";
        renderProfile();
        loadFavs().then(function(){ renderHome(); });
        gotoPage("booking");
      }).catch(function(e){
        toast(e && e.message === "invalid" ? "Wrong phone or password" : "Login failed — check internet");
      });
    });
    document.getElementById("gotoSignup").addEventListener("click", function(e){
      e.preventDefault(); gotoPage("signup");
    });
    document.getElementById("gotoLogin").addEventListener("click", function(e){
      e.preventDefault(); gotoPage("profile");
    });
    document.getElementById("signupBtn").addEventListener("click", function(){
      var name = document.getElementById("suName").value.trim();
      var phone = normPhone(document.getElementById("suPhone").value);
      var wa = normPhone(document.getElementById("suWa").value) || phone;
      var p1 = document.getElementById("suPass").value;
      var p2 = document.getElementById("suPass2").value;
      if (name.length < 2){ toast("Enter your name"); return; }
      if (!phone){ toast("Enter a valid mobile number"); return; }
      if (p1.length < 4){ toast("Password must be at least 4 characters"); return; }
      if (p1 !== p2){ toast("Passwords do not match"); return; }
      toast("Creating account...");
      Auth.signup(name, phone, wa, p1).then(function(s){
        toast("Welcome, " + s.name + "!");
        renderProfile();
        loadFavs().then(function(){ renderHome(); });
        gotoPage("booking");
      }).catch(function(e){
        toast(e && e.message === "phone-exists" ? "This number is already registered — please login" : "Signup failed — check internet");
      });
    });
    document.getElementById("logoutBtn").addEventListener("click", function(){
      Auth.logout();
      FAVS = [];
      toast("Logged out");
      renderProfile();
      renderHome();
    });
  }

  /* ---------- forgot password (v3.1) ---------- */
  function initForgot(){
    document.getElementById("gotoForgot").addEventListener("click", function(e){
      e.preventDefault(); gotoPage("forgot");
    });
    document.getElementById("fgBackLogin").addEventListener("click", function(e){
      e.preventDefault(); gotoPage("profile");
    });
    document.getElementById("rsBackLogin").addEventListener("click", function(e){
      e.preventDefault(); gotoPage("profile");
    });
    document.getElementById("fgSendBtn").addEventListener("click", function(){
      var phone = normPhone(document.getElementById("fgPhone").value);
      if (!phone){ toast("Enter a valid mobile number"); return; }
      toast("Generating code...");
      DB.createResetOTP(phone).then(function(){
        document.getElementById("fgDone").style.display = "";
        document.getElementById("fgWaBtn").href =
          "whatsapp://send?phone=" + CFG.SALON.whatsapp +
          "&text=" + encodeURIComponent("Assalam-o-Alaikum! I forgot my Kashish Beauty Salon app password. My number is " + phone + ". Please send my reset code.");
        toast("Code generated");
      }).catch(function(e){
        toast(e && e.message === "no-account" ? "No account found for this number" : "Failed — check internet");
      });
    });
    document.getElementById("fgHasCodeBtn").addEventListener("click", function(){
      gotoPage("reset");
    });
    document.getElementById("rsBtn").addEventListener("click", function(){
      var phone = normPhone(document.getElementById("fgPhone").value);
      var otp = document.getElementById("rsOtp").value.trim();
      var p1 = document.getElementById("rsPass").value;
      var p2 = document.getElementById("rsPass2").value;
      if (!phone){ toast("Go back and enter your phone number first"); return; }
      if (otp.length !== 6){ toast("Enter the 6-digit code"); return; }
      if (p1.length < 4){ toast("Password must be at least 4 characters"); return; }
      if (p1 !== p2){ toast("Passwords do not match"); return; }
      toast("Resetting...");
      DB.sha256("kashish:" + p1).then(function(hash){
        return DB.resetPassword(phone, otp, hash);
      }).then(function(){
        toast("Password reset! Please login.");
        document.getElementById("rsOtp").value = "";
        document.getElementById("rsPass").value = "";
        document.getElementById("rsPass2").value = "";
        document.getElementById("fgDone").style.display = "none";
        gotoPage("profile");
      }).catch(function(e){
        toast(e && e.message === "invalid-otp" ? "Wrong or expired code" : "Reset failed — check internet");
      });
    });
  }

  /* ---------- in-app update notice (v3.2) ---------- */
  function checkForUpdate(){
    var banner = document.getElementById("updateBanner");
    if (!banner) return;
    Promise.all([
      DB.getSetting("latest_version_code"),
      DB.getSetting("latest_version"),
      DB.getSetting("latest_apk_url")
    ]).then(function(r){
      var remoteCode = parseInt(r[0] || "0", 10);
      var remoteVer = r[1] || "";
      var apkUrl = r[2] || "";
      if (!(remoteCode > (CFG.APP_VERSION_CODE || 0))) return;
      var dismissed = null;
      try{ dismissed = localStorage.getItem("kashish_update_dismissed"); }catch(e){}
      if (dismissed === String(remoteCode)) return;
      document.getElementById("updateText").textContent =
        "A new version (v" + remoteVer + ") of the app is available!";
      var btn = document.getElementById("updateBtn");
      if (apkUrl){ btn.href = apkUrl; btn.style.display = ""; }
      else { btn.style.display = "none"; }
      banner.style.display = "";
      document.getElementById("updateDismiss").onclick = function(){
        banner.style.display = "none";
        try{ localStorage.setItem("kashish_update_dismissed", String(remoteCode)); }catch(e){}
      };
    }).catch(function(){ /* offline — no notice */ });
  }

  /* ---------- public API for Owner panel ---------- */
  window.App = {
    applyInstagram: applyInstagram,
    renderProfile: renderProfile,
    renderHome: renderHome,
    openModal: openModal,
    closeModal: closeModal,
    detail: showServiceDetail,
    refreshOffers: renderOffers,
    refreshServices: function(){
      DB.getServices().then(function(rows){
        if (rows && rows.length) DB_SERVICES = rows;
        renderServices();
        renderPopular();
        renderRecommended();
        if (typeof Booking !== "undefined") Booking.refreshServices();
      }).catch(function(){});
    },
    refreshGallery: function(){ loadGallery(); }
  };

  /* ---------- boot ---------- */
  loadFavs().then(function(){ renderHome(); });
  loadGallery();
  loadInstagram();
  checkForUpdate();
  document.getElementById("svcSearch").addEventListener("input", renderServices);
  document.getElementById("sdetBack").addEventListener("click", function(e){
    e.preventDefault(); gotoPage("services");
  });
  Booking.init();
  Owner.init();
  initLoyalty();
  initAuth();
  initForgot();
  initProfileExtras();
  initDB();
})();
