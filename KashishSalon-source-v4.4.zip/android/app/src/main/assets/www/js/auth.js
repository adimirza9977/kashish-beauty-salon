/* Kashish Beauty Salon — customer auth session (v3) */
var Auth = (function(){
  "use strict";
  var KEY = "kashish_session";

  function save(s){ localStorage.setItem(KEY, JSON.stringify(s)); }
  function clear(){ localStorage.removeItem(KEY); }

  return {
    current: function(){
      try { return JSON.parse(localStorage.getItem(KEY) || "null"); }
      catch(e){ return null; }
    },
    isLoggedIn: function(){ return !!this.current(); },

    signup: function(name, phone, whatsapp, password){
      return DB.sha256("kashish:" + password).then(function(hash){
        return DB.signupCustomer(name, phone, whatsapp, hash);
      }).then(function(c){
        if (!c) throw new Error("signup failed");
        var s = { id: c.id, name: c.name, phone: c.phone };
        save(s);
        return s;
      }).catch(function(e){
        if (e && e.status === 409) throw new Error("phone-exists");
        throw e;
      });
    },

    login: function(phone, password){
      return DB.sha256("kashish:" + password).then(function(hash){
        return DB.loginCustomer(phone, hash);
      }).then(function(c){
        if (!c) throw new Error("invalid");
        var s = { id: c.id, name: c.name, phone: c.phone };
        save(s);
        return s;
      });
    },

    logout: function(){ clear(); },

    refresh: function(){
      var s = this.current();
      if (!s) return Promise.resolve(null);
      return DB.getCustomerById(s.id).then(function(c){
        if (!c) { clear(); return null; }
        var ns = { id: c.id, name: c.name, phone: c.phone };
        save(ns);
        return ns;
      }).catch(function(){ return s; });
    }
  };
})();
