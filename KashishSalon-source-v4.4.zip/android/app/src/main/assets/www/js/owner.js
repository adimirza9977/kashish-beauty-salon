/* Kashish Beauty Salon — owner (private) panel v3 */
var Owner = (function(){
  "use strict";

  var pin = "", unlocked = false, pinHashCache = null;
  var bkFilter = "upcoming";
  var editingSvcId = null, svcImgFile = null;

  function el(id){ return document.getElementById(id); }
  function esc(s){ return String(s == null ? "" : s).replace(/&/g,"&amp;").replace(/</g,"&lt;"); }

  /* ---------- PIN (stored in Supabase — survives reinstall) ---------- */
  function getPinHash(){
    if (pinHashCache) return Promise.resolve(pinHashCache);
    return DB.getSetting("owner_pin_hash").then(function(h){
      if (h){ pinHashCache = h; try{ localStorage.setItem(CFG.OWNER_PIN_KEY + "_hash", h); }catch(e){} return h; }
      var legacy = null;
      try{ legacy = localStorage.getItem(CFG.OWNER_PIN_KEY) || CFG.DEFAULT_PIN; }catch(e){ legacy = CFG.DEFAULT_PIN; }
      return DB.sha256("kashish-pin:" + legacy).then(function(lh){ pinHashCache = lh; return lh; });
    }).catch(function(){
      try{
        var c = localStorage.getItem(CFG.OWNER_PIN_KEY + "_hash");
        if (c){ pinHashCache = c; return c; }
      }catch(e){}
      var legacy2 = CFG.DEFAULT_PIN;
      try{ legacy2 = localStorage.getItem(CFG.OWNER_PIN_KEY) || CFG.DEFAULT_PIN; }catch(e2){}
      return DB.sha256("kashish-pin:" + legacy2);
    });
  }

  function initPad(){
    el("pinDisplay").innerHTML = "&bull;&bull;&bull;&bull;";
    pin = "";
    var keys = document.querySelectorAll("#pinPad .pin-key");
    keys.forEach(function(k){
      k.onclick = function(){
        var v = k.getAttribute("data-k") || k.textContent.trim();
        if (v === "clear"){ pin = ""; }
        else if (v === "ok"){ tryUnlock(); return; }
        else if (pin.length < 4){ pin += v; }
        el("pinDisplay").textContent = "\u2022".repeat(pin.length) + "\u25CB".repeat(4 - pin.length);
        if (pin.length === 4) setTimeout(tryUnlock, 250);
      };
    });
  }

  function tryUnlock(){
    toast("Checking...");
    getPinHash().then(function(expected){
      return DB.sha256("kashish-pin:" + pin).then(function(got){
        if (got === expected){
          unlocked = true;
          el("ownerLogin").style.display = "none";
          el("ownerPanel").style.display = "";
          loadAll();
        } else {
          toast("Wrong PIN");
          pin = "";
          el("pinDisplay").innerHTML = "&bull;&bull;&bull;&bull;";
        }
      });
    }).catch(function(){
      toast("Could not verify — check internet");
      pin = "";
      el("pinDisplay").innerHTML = "&bull;&bull;&bull;&bull;";
    });
  }

  function lock(){
    unlocked = false; pin = "";
    el("ownerPanel").style.display = "none";
    el("ownerLogin").style.display = "";
    initPad();
  }

  /* ---------- tabs ---------- */
  function switchOwnerTab(k){
    var t = document.querySelector('#ownerTabs .otab[data-ot="' + k + '"]');
    if (t) t.click();
  }

  function initTabs(){
    var tabs = document.querySelectorAll("#ownerTabs .otab");
    tabs.forEach(function(t){
      t.onclick = function(){
        tabs.forEach(function(x){ x.classList.remove("active"); });
        t.classList.add("active");
        var k = t.getAttribute("data-ot");
        ["dashboard","bookings","customers","services","offers","beauticians","gallery","resets","payments","settings"].forEach(function(p){
          var pane = el("otPane-" + p);
          if (pane) pane.style.display = (p === k) ? "" : "none";
        });
        if (k === "dashboard") loadDashboard();
        if (k === "bookings") loadBookings();
        if (k === "customers") loadCustomers();
        if (k === "services") loadOwnerServices();
        if (k === "offers") loadOffersMgr();
        if (k === "beauticians") loadBeauts();
        if (k === "gallery") loadOwnerGallery();
        if (k === "resets") loadResets();
        if (k === "payments") loadPayments();
        if (k === "settings") loadSettings();
      };
    });
    var fb = document.querySelectorAll(".fbtn");
    fb.forEach(function(b){
      b.onclick = function(){
        fb.forEach(function(x){ x.classList.remove("active"); });
        b.classList.add("active");
        bkFilter = b.getAttribute("data-bf");
        el("ownerDate").value = "";
        loadBookings();
      };
    });
  }

  /* ---------- bookings ---------- */
  function statusPill(s){
    var map = { pending: "status-pending", confirmed: "status-confirmed",
                completed: "status-completed", cancelled: "status-cancelled" };
    return '<span class="bk-status ' + (map[s] || "status-pending") + '">' + esc(s) + '</span>';
  }

  function bookingCard(b, showDate){
    var d = document.createElement("div");
    d.className = "bk-item";
    var payLine = esc(b.payment_method || "cash") + " / " + esc(b.payment_status || "unpaid");
    if (b.payment_tid) payLine += " \u2022 TID " + esc(b.payment_tid);
    d.innerHTML =
      '<div class="bk-head"><strong>' + esc(b.service_name) + '</strong>' + statusPill(b.status) + '</div>' +
      '<div class="bk-meta">' + (showDate ? esc(fmtDate(b.booking_date)) + " \u2022 " : "") +
        esc(fmtSlot(b.time_slot)) + " \u2022 " + rs(b.price) + '<br>' +
        esc(b.customer_name) + ' \u2022 <a href="tel:+' + esc(String(b.customer_phone).replace(/\D/g,"")) + '">' +
        esc(b.customer_phone) + '</a><br>' + payLine + '</div>' +
      '<div class="bk-actions"></div>';
    var acts = d.querySelector(".bk-actions");
    function btn(label, fn){
      var x = document.createElement("button");
      x.className = "mini-btn"; x.textContent = label;
      x.onclick = function(){ fn(b); };
      acts.appendChild(x);
    }
    if (b.status === "pending") btn("Confirm", function(x){ setStatus(x, "confirmed"); });
    if (b.status === "pending" || b.status === "confirmed"){
      btn("Complete", function(x){ setStatus(x, "completed"); });
      btn("Cancel", function(x){ setStatus(x, "cancelled"); });
    }
    var wa = document.createElement("a");
    wa.className = "mini-btn"; wa.target = "_blank";
    wa.textContent = "WhatsApp";
    wa.href = "whatsapp://send?phone=" + String(b.customer_phone).replace(/\D/g,"") +
      "&text=" + encodeURIComponent("Assalam-o-Alaikum " + b.customer_name +
        "! Kashish Beauty Salon: your booking for " + b.service_name +
        " on " + fmtDate(b.booking_date) + " at " + fmtSlot(b.time_slot) +
        " is " + b.status + ".");
    acts.appendChild(wa);
    return d;
  }

  function setStatus(b, st){
    var done = function(){
      toast("Booking " + st);
      loadBookings();
    };
    if (st === "completed"){
      // award loyalty points on completion
      DB.getLoyaltyConfig().then(function(cfg){
        var pts = Math.floor((b.price || 0) / 100) * (cfg.points_per_100rs || 1);
        return DB.upsertCustomer(b.customer_name, String(b.customer_phone).replace(/\D/g,""), pts, 1);
      }).then(function(){ return DB.setBookingStatus(b.id, st); })
        .then(done).catch(function(){ toast("Failed — check internet"); });
    } else {
      DB.setBookingStatus(b.id, st).then(done).catch(function(){ toast("Failed — check internet"); });
    }
  }

  function loadBookings(){
    var wrap = el("ownerBookings");
    var date = el("ownerDate").value;
    wrap.innerHTML = "<p>Loading...</p>";
    var p, showDate = true;
    if (date){ p = DB.getBookingsByDate(date); showDate = false; }
    else if (bkFilter === "upcoming"){ p = DB.getUpcomingBookings(); }
    else { p = DB.getAllBookings(200); }
    p.then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No bookings.</div>'; return; }
      rows.forEach(function(b){ wrap.appendChild(bookingCard(b, showDate)); });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  /* ---------- customers (v4) ---------- */
  var custCache = [];

  function loadCustomers(){
    var wrap = el("ownerCustomers");
    if (!wrap) return;
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getCustomers().then(function(rows){
      custCache = rows || [];
      paintCustomers("");
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function paintCustomers(q){
    var wrap = el("ownerCustomers");
    wrap.innerHTML = "";
    q = (q || "").toLowerCase();
    var rows = custCache.filter(function(c){
      return !q || ((c.name || "") + " " + (c.phone || "")).toLowerCase().indexOf(q) >= 0;
    });
    if (!rows.length){ wrap.innerHTML = '<div class="empty">No customers found.</div>'; return; }
    rows.forEach(function(c){
      var d = document.createElement("div");
      d.className = "svc";
      d.style.cursor = "pointer";
      d.innerHTML = '<div class="svc-info"><strong>' + esc(c.name || "Guest") + "</strong>" +
        "<span>" + esc(c.phone || "") + " • " + (c.total_visits || 0) + " visits • " +
        (c.loyalty_points || 0) + " pts</span></div>";
      d.onclick = function(){ showCustomer(c); };
      wrap.appendChild(d);
    });
  }

  function showCustomer(c){
    App.openModal(
      '<h3 class="sec-title">' + esc(c.name || "Guest") + "</h3>" +
      '<p class="muted">' + esc(c.phone || "") + (c.whatsapp ? " • WA " + esc(c.whatsapp) : "") + "</p>" +
      '<p class="muted">' + (c.total_visits || 0) + " visits • " + (c.loyalty_points || 0) + " loyalty points</p>" +
      '<h3 class="sec-title" style="margin-top:12px">Booking History</h3>' +
      '<div id="custHist"><p>Loading...</p></div>' +
      '<button class="btn btn-outline btn-block" id="custClose">Close</button>'
    );
    document.getElementById("custClose").onclick = App.closeModal;
    DB.getBookingsByPhone(c.phone || "").then(function(rows){
      var w = document.getElementById("custHist");
      if (!w) return;
      if (!rows || !rows.length){ w.innerHTML = '<div class="empty">No bookings yet.</div>'; return; }
      w.innerHTML = "";
      rows.forEach(function(b){
        var d = document.createElement("div");
        d.className = "bk-item";
        d.innerHTML = '<div class="bk-head"><strong>' + esc(b.service_name) + "</strong>" + statusPill(b.status) + "</div>" +
          '<div class="bk-meta">' + esc(fmtDate(b.booking_date)) + " • " + esc(fmtSlot(b.time_slot)) +
          " • " + rs(b.price) + "</div>";
        w.appendChild(d);
      });
    }).catch(function(){
      var w2 = document.getElementById("custHist");
      if (w2) w2.innerHTML = "<p>Could not load.</p>";
    });
  }

  /* ---------- offers & coupons manager (v4) ---------- */
  var editingOfferId = null, offerImgFile = null;
  var editingCouponId = null;

  function initOfferSubtabs(){
    document.querySelectorAll("[data-osub]").forEach(function(t){
      t.onclick = function(){
        document.querySelectorAll("[data-osub]").forEach(function(x){ x.classList.remove("active"); });
        t.classList.add("active");
        var k = t.getAttribute("data-osub");
        el("osub-offers").style.display = k === "offers" ? "" : "none";
        el("osub-coupons").style.display = k === "coupons" ? "" : "none";
      };
    });
  }

  function loadOffersMgr(){ loadOwnerOffers(); loadOwnerCoupons(); }

  function loadOwnerOffers(){
    var wrap = el("ownerOffers");
    if (!wrap) return;
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getAllOffers().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No offers yet.</div>'; return; }
      rows.forEach(function(o){
        var d = document.createElement("div");
        d.className = "svc mgr-svc";
        d.innerHTML = '<div class="svc-info"><strong>' + esc(o.title) + "</strong>" +
          "<span>" + esc(o.discount_text || "") +
          (o.valid_till ? " • till " + esc(fmtDate(o.valid_till)) : "") +
          (o.is_active ? "" : ' • <span class="bk-status status-cancelled">off</span>') + "</span></div>" +
          '<div class="bk-actions" style="margin:0"></div>';
        var acts = d.querySelector(".bk-actions");
        mkMini(acts, "Edit", function(){ openOfferForm(o); });
        mkMini(acts, o.is_active ? "Deactivate" : "Activate", function(){
          DB.updateOffer(o.id, { is_active: !o.is_active }).then(function(){
            toast("Offer updated"); loadOwnerOffers();
            if (window.App && App.refreshOffers) App.refreshOffers();
          }).catch(function(){ toast("Failed — check internet"); });
        });
        wrap.appendChild(d);
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function openOfferForm(o){
    editingOfferId = o ? o.id : null;
    el("offerFormTitle").textContent = o ? "Edit Offer" : "Add Offer";
    el("offerFTitle").value = o ? o.title : "";
    el("offerFDesc").value = o ? (o.description || "") : "";
    el("offerFDisc").value = o ? (o.discount_text || "") : "";
    el("offerFValid").value = o ? (o.valid_till || "") : "";
    el("offerFTerms").value = o ? (o.terms || "") : "";
    el("offerFImgPrev").src = (o && o.image_url) ? o.image_url : "";
    el("offerFImgPrev").style.display = (o && o.image_url) ? "" : "none";
    el("offerFImg").value = "";
    offerImgFile = null;
    el("offerForm").style.display = "";
    el("offerForm").scrollIntoView();
  }

  function saveOffer(){
    var title = el("offerFTitle").value.trim();
    if (!title){ toast("Enter offer title"); return; }
    toast("Saving...");
    var finish = function(imageUrl){
      var row = {
        title: title,
        description: el("offerFDesc").value.trim(),
        discount_text: el("offerFDisc").value.trim(),
        valid_till: el("offerFValid").value || null,
        terms: el("offerFTerms").value.trim(),
        is_active: true
      };
      if (imageUrl !== undefined) row.image_url = imageUrl;
      var p = editingOfferId ? DB.updateOffer(editingOfferId, row) : DB.addOffer(row);
      p.then(function(){
        toast("Offer saved");
        el("offerForm").style.display = "none";
        loadOwnerOffers();
        if (window.App && App.refreshOffers) App.refreshOffers();
      }).catch(function(){ toast("Failed — check internet"); });
    };
    if (offerImgFile){
      DB.uploadImage(offerImgFile).then(finish).catch(function(){ toast("Image upload failed"); });
    } else {
      finish(editingOfferId ? undefined : "");
    }
  }

  function loadOwnerCoupons(){
    var wrap = el("ownerCoupons");
    if (!wrap) return;
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getAllCoupons().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No coupons yet.</div>'; return; }
      rows.forEach(function(c){
        var disc = c.discount_percent ? c.discount_percent + "%" : rs(c.discount_rs || 0);
        var d = document.createElement("div");
        d.className = "svc mgr-svc";
        d.innerHTML = '<div class="svc-info"><strong>' + esc(c.code) + "</strong>" +
          "<span>" + esc(String(disc)) + " off" +
          (c.min_amount ? " • min " + rs(c.min_amount) : "") +
          (c.valid_till ? " • till " + esc(fmtDate(c.valid_till)) : "") +
          (c.is_active ? "" : ' • <span class="bk-status status-cancelled">off</span>') + "</span></div>" +
          '<div class="bk-actions" style="margin:0"></div>';
        var acts = d.querySelector(".bk-actions");
        mkMini(acts, "Edit", function(){ openCouponForm(c); });
        mkMini(acts, "Share", function(){
          var discTxt = c.discount_percent ? c.discount_percent + "% off" : rs(c.discount_rs || 0) + " off";
          var msg = "Kashish Beauty Salon ki taraf se khaas discount! Coupon code: " + c.code +
            " — " + discTxt +
            (c.min_amount ? " (minimum order " + rs(c.min_amount) + ")" : "") +
            (c.valid_till ? ", valid till " + fmtDate(c.valid_till) : "") +
            ". App mein booking karte waqt yeh code lagayen!";
          window.location.href = "whatsapp://send?text=" + encodeURIComponent(msg);
        });
        mkMini(acts, c.is_active ? "Deactivate" : "Activate", function(){
          DB.updateCoupon(c.id, { is_active: !c.is_active }).then(function(){
            toast("Coupon updated"); loadOwnerCoupons();
          }).catch(function(){ toast("Failed — check internet"); });
        });
        wrap.appendChild(d);
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function openCouponForm(c){
    editingCouponId = c ? c.id : null;
    el("couponFormTitle").textContent = c ? "Edit Coupon" : "Add Coupon";
    el("couponFCode").value = c ? c.code : "";
    el("couponFPct").value = c ? (c.discount_percent || "") : "";
    el("couponFRs").value = c ? (c.discount_rs || "") : "";
    el("couponFMin").value = c ? (c.min_amount || 0) : 0;
    el("couponFValid").value = c ? (c.valid_till || "") : "";
    el("couponForm").style.display = "";
    el("couponForm").scrollIntoView();
  }

  function saveCoupon(){
    var code = el("couponFCode").value.trim().toUpperCase();
    var pct = parseFloat(el("couponFPct").value) || 0;
    var drs = parseInt(el("couponFRs").value, 10) || 0;
    if (!code){ toast("Enter coupon code"); return; }
    if (!(pct > 0) && !(drs > 0)){ toast("Enter discount percent or Rs"); return; }
    toast("Saving...");
    var row = {
      code: code,
      discount_percent: pct > 0 ? pct : null,
      discount_rs: pct > 0 ? null : drs,
      min_amount: parseInt(el("couponFMin").value, 10) || 0,
      valid_till: el("couponFValid").value || null,
      is_active: true
    };
    var p = editingCouponId ? DB.updateCoupon(editingCouponId, row) : DB.addCoupon(row);
    p.then(function(){
      toast("Coupon saved");
      el("couponForm").style.display = "none";
      loadOwnerCoupons();
    }).catch(function(e){
      toast(e && e.status === 409 ? "This code already exists" : "Failed — check internet");
    });
  }

  /* ---------- beauticians manager (v4) ---------- */
  var editingBeautId = null;

  function loadBeauts(){
    var wrap = el("ownerBeauts");
    if (!wrap) return;
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getAllBeauticians().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No beauticians yet. Add one above.</div>'; return; }
      rows.forEach(function(b){
        var d = document.createElement("div");
        d.className = "svc mgr-svc";
        d.innerHTML = '<div class="svc-info"><strong>' + esc(b.name) + "</strong>" +
          "<span>" + esc(b.specialty || "") + (b.phone ? " • " + esc(b.phone) : "") +
          (b.is_active ? "" : ' • <span class="bk-status status-cancelled">off</span>') + "</span></div>" +
          '<div class="bk-actions" style="margin:0"></div>';
        var acts = d.querySelector(".bk-actions");
        mkMini(acts, "Edit", function(){ openBeautForm(b); });
        mkMini(acts, b.is_active ? "Deactivate" : "Activate", function(){
          DB.updateBeautician(b.id, { is_active: !b.is_active }).then(function(){
            toast("Updated"); loadBeauts();
          }).catch(function(){ toast("Failed — check internet"); });
        });
        wrap.appendChild(d);
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function openBeautForm(b){
    editingBeautId = b ? b.id : null;
    el("beautFormTitle").textContent = b ? "Edit Beautician" : "Add Beautician";
    el("beautFName").value = b ? b.name : "";
    el("beautFSpec").value = b ? (b.specialty || "") : "";
    el("beautFPhone").value = b ? (b.phone || "") : "";
    el("beautForm").style.display = "";
    el("beautForm").scrollIntoView();
  }

  function saveBeaut(){
    var name = el("beautFName").value.trim();
    if (!name){ toast("Enter name"); return; }
    var row = {
      name: name,
      specialty: el("beautFSpec").value.trim(),
      phone: normPhone(el("beautFPhone").value) || el("beautFPhone").value.trim(),
      is_active: true
    };
    toast("Saving...");
    var p = editingBeautId ? DB.updateBeautician(editingBeautId, row) : DB.addBeautician(row);
    p.then(function(){
      toast("Saved");
      el("beautForm").style.display = "none";
      loadBeauts();
    }).catch(function(){ toast("Failed — check internet"); });
  }

  /* ---------- services manager ---------- */
  function loadOwnerServices(){
    var wrap = el("ownerServices");
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getServices().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No services yet. Add one above.</div>'; return; }
      var byCat = {};
      rows.forEach(function(s){
        (byCat[s.category || "general"] = byCat[s.category || "general"] || []).push(s);
      });
      Object.keys(byCat).forEach(function(cat){
        var h = document.createElement("h3");
        h.className = "svc-cat"; h.textContent = catName(cat);
        wrap.appendChild(h);
        byCat[cat].forEach(function(s){
          var d = document.createElement("div");
          d.className = "svc mgr-svc";
          d.innerHTML =
            '<div class="svc-info"><strong>' + esc(s.name) + '</strong>' +
            '<span>' + rs(s.price) + ' \u2022 ' + (s.duration_min || 30) + ' min</span></div>' +
            '<div class="bk-actions" style="margin:0"></div>';
          var acts = d.querySelector(".bk-actions");
          var eb = document.createElement("button");
          eb.className = "mini-btn"; eb.textContent = "Edit";
          eb.onclick = function(){ openSvcForm(s); };
          var fb2 = document.createElement("button");
          fb2.className = "mini-btn"; fb2.textContent = s.is_featured ? "Unfeature" : "Feature";
          fb2.onclick = (function(svc){
            return function(){
              DB.updateService(svc.id, { is_featured: !svc.is_featured }).then(function(){
                toast(svc.is_featured ? "Removed from Featured" : "Added to Featured");
                loadOwnerServices(); App.refreshServices();
              }).catch(function(){ toast("Failed"); });
            };
          })(s);
          var db = document.createElement("button");
          db.className = "mini-btn"; db.textContent = "Delete";
          db.onclick = function(){
            if (confirm("Delete '" + s.name + "'?")) {
              DB.deleteService(s.id).then(function(){ toast("Deleted"); loadOwnerServices(); App.refreshServices(); })
                .catch(function(){ toast("Failed"); });
            }
          };
          acts.appendChild(eb); acts.appendChild(fb2); acts.appendChild(db);
          wrap.appendChild(d);
        });
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function catName(id){
    var c = (typeof CATEGORIES !== "undefined" ? CATEGORIES : []).filter(function(x){ return x.id === id; })[0];
    return c ? c.name : id;
  }

  function openSvcForm(s){
    editingSvcId = s ? s.id : null;
    el("svcFormTitle").textContent = s ? "Edit Service" : "Add Service";
    el("svcFName").value = s ? s.name : "";
    el("svcFPrice").value = s ? s.price : "";
    el("svcFDur").value = s ? (s.duration_min || 30) : 30;
    el("svcFDesc").value = s ? (s.description || "") : "";
    el("svcFImgPrev").src = (s && s.image_url) ? s.image_url : "";
    el("svcFImgPrev").style.display = (s && s.image_url) ? "" : "none";
    el("svcFImg").value = "";
    svcImgFile = null;
    var sel = el("svcFCat");
    sel.innerHTML = "";
    (typeof CATEGORIES !== "undefined" ? CATEGORIES : [{id:"general",name:"General"}]).forEach(function(c){
      var o = document.createElement("option");
      o.value = c.id; o.textContent = c.name;
      if (s && s.category === c.id) o.selected = true;
      sel.appendChild(o);
    });
    el("svcForm").style.display = "";
    el("svcForm").scrollIntoView();
  }

  function saveService(){
    var name = el("svcFName").value.trim();
    var price = parseInt(el("svcFPrice").value, 10);
    if (!name){ toast("Enter service name"); return; }
    if (!(price >= 0)){ toast("Enter price"); return; }
    toast("Saving...");
    var finish = function(imageUrl){
      var row = {
        name: name,
        description: el("svcFDesc").value.trim(),
        price: price,
        duration_min: parseInt(el("svcFDur").value, 10) || 30,
        category: el("svcFCat").value,
        active: true
      };
      if (imageUrl !== undefined) row.image_url = imageUrl;
      var p = editingSvcId ? DB.updateService(editingSvcId, row) : DB.addService(row);
      p.then(function(){
        toast("Service saved");
        el("svcForm").style.display = "none";
        loadOwnerServices();
        App.refreshServices();
      }).catch(function(){ toast("Failed — check internet"); });
    };
    if (svcImgFile){
      DB.uploadImage(svcImgFile).then(finish).catch(function(){ toast("Image upload failed"); });
    } else {
      finish(editingSvcId ? undefined : "");
    }
  }

  /* ---------- gallery manager ---------- */
  function loadOwnerGallery(){
    var wrap = el("ownerGallery");
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getGallery().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No pictures yet. Upload one above.</div>'; return; }
      rows.forEach(function(g){
        var d = document.createElement("div");
        d.className = "gal-item";
        d.innerHTML = '<img src="' + esc(g.image_url) + '" alt="">' +
          '<button class="gal-del" title="Delete">\u00D7</button>';
        d.querySelector(".gal-del").onclick = function(){
          if (confirm("Delete this picture?")){
            DB.deleteGalleryItem(g.id).then(function(){ toast("Deleted"); loadOwnerGallery(); App.refreshGallery(); })
              .catch(function(){ toast("Failed"); });
          }
        };
        wrap.appendChild(d);
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  function uploadGallery(){
    var f = el("galFile").files[0];
    if (!f){ toast("Choose a picture first"); return; }
    toast("Uploading...");
    DB.uploadImage(f).then(function(url){
      return DB.addGalleryItem(url, el("galCap").value.trim());
    }).then(function(){
      toast("Picture added to gallery");
      el("galFile").value = ""; el("galCap").value = "";
      loadOwnerGallery();
      App.refreshGallery();
    }).catch(function(){ toast("Upload failed — check internet"); });
  }

  /* ---------- password reset requests (v3.1) ---------- */
  function loadResets(){
    var wrap = el("ownerResets");
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getPendingResets().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){ wrap.innerHTML = '<div class="empty">No reset requests.</div>'; return; }
      // attach customer names
      var phones = {};
      rows.forEach(function(r){ phones[r.phone] = true; });
      var nameP = Promise.all(Object.keys(phones).map(function(ph){
        return DB.getCustomer(ph).then(function(c){ return { phone: ph, name: c ? c.name : ph }; });
      }));
      nameP.then(function(pairs){
        var names = {};
        pairs.forEach(function(p){ names[p.phone] = p.name; });
        rows.forEach(function(r){
          var d = document.createElement("div");
          d.className = "bk-item";
          d.innerHTML =
            '<div class="bk-head"><strong>' + esc(names[r.phone] || r.phone) + '</strong>' +
            '<span class="bk-status status-pending">reset</span></div>' +
            '<div class="bk-meta">' + esc(r.phone) + '<br>Code: <strong style="font-size:1.2rem;letter-spacing:4px">' +
            esc(r.otp) + '</strong><br><span class="muted">Expires: ' +
            new Date(r.expires_at).toLocaleString() + '</span></div>' +
            '<div class="bk-actions"></div>';
          var acts = d.querySelector(".bk-actions");
          var send = document.createElement("a");
          send.className = "mini-btn"; send.target = "_blank"; send.textContent = "Send Code via WhatsApp";
          send.href = "whatsapp://send?phone=" + String(r.phone).replace(/\D/g,"") +
            "&text=" + encodeURIComponent("Assalam-o-Alaikum! Your Kashish Beauty Salon password reset code is: " +
              r.otp + " (valid 15 minutes).");
          var done = document.createElement("button");
          done.className = "mini-btn"; done.textContent = "Dismiss";
          done.onclick = (function(id){
            return function(){
              DB.markResetSent(id).then(function(){ loadResets(); });
            };
          })(r.id);
          acts.appendChild(send); acts.appendChild(done);
          wrap.appendChild(d);
        });
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  /* ---------- payments ---------- */
  function loadPayments(){
    var wrap = el("ownerPayments");
    wrap.innerHTML = "<p>Loading...</p>";
    DB.getPendingPayments().then(function(rows){
      wrap.innerHTML = "";
      if (!rows.length){
        wrap.innerHTML = '<div class="empty">No payment proofs waiting.</div>';
        return;
      }
      rows.forEach(function(b){
        var card = bookingCard(b, true);
        var acts = card.querySelector(".bk-actions");
        var ok = document.createElement("button");
        ok.className = "mini-btn"; ok.textContent = "Verify payment";
        ok.onclick = function(){
          DB.setPaymentStatus(b.id, "verified").then(function(){
            toast("Payment verified"); loadPayments();
          }).catch(function(){ toast("Failed"); });
        };
        var no = document.createElement("button");
        no.className = "mini-btn"; no.textContent = "Reject";
        no.onclick = function(){
          DB.setPaymentStatus(b.id, "rejected").then(function(){
            toast("Payment rejected"); loadPayments();
          }).catch(function(){ toast("Failed"); });
        };
        acts.appendChild(ok); acts.appendChild(no);
        wrap.appendChild(card);
      });
    }).catch(function(){ wrap.innerHTML = "<p>Could not load. Check internet.</p>"; });
  }

  /* ---------- settings ---------- */
  function loadSettings(){
    DB.getLoyaltyConfig().then(function(c){
      el("setPp100").value = c.points_per_100rs;
      el("setRedeemPts").value = c.redeem_points;
      el("setRedeemRs").value = c.redeem_value_rs;
      el("setMinPts").value = c.min_redeem_points;
    }).catch(function(){});
    var acc = {};
    try { acc = JSON.parse(localStorage.getItem(CFG.PAY_ACCOUNTS_KEY) || "{}"); } catch(e){}
    var d = CFG.DEFAULT_PAY_ACCOUNTS || {};
    function one(k, tId, nId){
      var dd = d[k] || {}, sv = acc[k] || {};
      if (typeof sv === "string") sv = { number: sv };
      el(tId).value = sv.title || dd.title || "";
      el(nId).value = sv.number || dd.number || "";
    }
    one("easypaisa", "setEpT", "setEp");
    one("jazzcash", "setJcT", "setJc");
    one("bank", "setBankT", "setBank");
    DB.getSetting("instagram_url").then(function(v){
      el("setInsta").value = v || CFG.DEFAULT_INSTAGRAM || "";
    }).catch(function(){ el("setInsta").value = CFG.DEFAULT_INSTAGRAM || ""; });
    DB.getSetting("latest_version").then(function(v){ if (v) el("setVerName").value = v; }).catch(function(){});
    DB.getSetting("latest_version_code").then(function(v){ if (v) el("setVerCode").value = v; }).catch(function(){});
    DB.getSetting("latest_apk_url").then(function(v){ if (v) el("setApkUrl").value = v; }).catch(function(){});
  }

  function saveUpdateNotice(){
    var ver = el("setVerName").value.trim();
    var code = parseInt(el("setVerCode").value, 10);
    var url = el("setApkUrl").value.trim();
    if (!ver || !(code > 0) || !url){ toast("Fill version name, code and APK link"); return; }
    toast("Publishing...");
    Promise.all([
      DB.setSetting("latest_version", ver),
      DB.setSetting("latest_version_code", String(code)),
      DB.setSetting("latest_apk_url", url)
    ]).then(function(){
      toast("Update notice published — all users will see it");
    }).catch(function(){ toast("Failed — check internet"); });
  }

  function saveLoyalty(){
    var cfg = {
      points_per_100rs: parseInt(el("setPp100").value, 10) || 1,
      redeem_points: parseInt(el("setRedeemPts").value, 10) || 100,
      redeem_value_rs: parseInt(el("setRedeemRs").value, 10) || 100,
      min_redeem_points: parseInt(el("setMinPts").value, 10) || 100
    };
    DB.saveLoyaltyConfig(cfg).then(function(){
      toast("Loyalty settings saved");
    }).catch(function(){ toast("Failed — check internet"); });
  }

  function savePayAccounts(){
    var acc = {
      easypaisa: { title: el("setEpT").value.trim(), number: el("setEp").value.trim() },
      jazzcash: { title: el("setJcT").value.trim(), number: el("setJc").value.trim() },
      bank: { title: el("setBankT").value.trim(), number: el("setBank").value.trim() }
    };
    try{ localStorage.setItem(CFG.PAY_ACCOUNTS_KEY, JSON.stringify(acc)); }catch(e){}
    DB.setSetting("pay_accounts", JSON.stringify(acc)).then(function(){
      toast("Payment accounts saved");
    });
  }

  function saveInstagram(){
    var v = el("setInsta").value.trim();
    if (!v){ toast("Enter the Instagram link"); return; }
    DB.setSetting("instagram_url", v).then(function(){
      toast("Instagram link saved");
      if (window.App && App.applyInstagram) App.applyInstagram(v);
    }).catch(function(){ toast("Failed — check internet"); });
  }

  function changePin(){
    var v = el("setPin").value.trim();
    if (!/^\d{4}$/.test(v)){ toast("PIN must be 4 digits"); return; }
    toast("Saving PIN...");
    DB.sha256("kashish-pin:" + v).then(function(h){
      pinHashCache = h;
      try{
        localStorage.setItem(CFG.OWNER_PIN_KEY + "_hash", h);
        localStorage.setItem(CFG.OWNER_PIN_KEY, v);
      }catch(e){}
      return DB.setSetting("owner_pin_hash", h);
    }).then(function(){
      el("setPin").value = "";
      toast("PIN changed — saved online, survives reinstall");
    }).catch(function(){ toast("Failed — check internet"); });
  }

  function loadAll(){
    el("ownerDate").value = "";
    bkFilter = "upcoming";
    var fb = document.querySelectorAll(".fbtn");
    fb.forEach(function(x){ x.classList.toggle("active", x.getAttribute("data-bf") === "upcoming"); });
    switchOwnerTab("dashboard");
  }

  /* ---------- dashboard (v4): stats, alerts, quick actions ---------- */
  function loadDashboard(){
    var today = new Date().toISOString().slice(0, 10);
    Promise.all([DB.getBookingsByDate(today), DB.getUpcomingBookings()]).then(function(r){
      var todays = r[0] || [], upcoming = r[1] || [];
      var live = todays.filter(function(b){ return b.status !== "cancelled"; });
      el("dashToday").textContent = live.length;
      var rev = live.reduce(function(a, b){ return a + (Number(b.price) || 0); }, 0);
      el("dashRevenue").textContent = rs(rev);
      el("dashPending").textContent = todays.filter(function(b){ return b.status === "pending"; }).length;
      el("dashUpcoming").textContent = upcoming.length;
      // overlap alert: same beautician + date + slot booked twice today
      var seen = {}, dups = 0;
      live.forEach(function(b){
        var key = (b.beautician_id || "any") + "|" + b.time_slot;
        if (seen[key]) dups++;
        else seen[key] = true;
      });
      var al = el("dashAlerts");
      if (dups){
        al.style.display = "";
        al.textContent = "Warning: " + dups + " overlapping booking(s) detected today — check the Bookings tab.";
      } else {
        al.style.display = "none";
      }
    }).catch(function(){ /* stats stay at 0 */ });
  }

  function mkMini(parent, label, fn){
    var b = document.createElement("button");
    b.className = "mini-btn"; b.textContent = label;
    b.onclick = fn;
    parent.appendChild(b);
    return b;
  }

  /* ---------- walk-in booking (v4) ---------- */
  function initWalkin(){
    var ss = el("wiService"); ss.innerHTML = "";
    (typeof DB_SERVICES !== "undefined" ? DB_SERVICES : []).forEach(function(s){
      var o = document.createElement("option");
      o.value = s.id; o.textContent = s.name + " — " + rs(s.price);
      ss.appendChild(o);
    });
    var bs = el("wiBeaut"); bs.innerHTML = "";
    var any = document.createElement("option");
    any.value = ""; any.textContent = "Any Available";
    bs.appendChild(any);
    DB.getBeauticians().then(function(rows){
      (rows || []).forEach(function(b){
        var o = document.createElement("option");
        o.value = b.id; o.textContent = b.name + (b.specialty ? " (" + b.specialty + ")" : "");
        bs.appendChild(o);
      });
    }).catch(function(){});
    var d = el("wiDate");
    var today = new Date(), max = new Date();
    max.setDate(max.getDate() + 14);
    d.min = today.toISOString().slice(0, 10);
    d.max = max.toISOString().slice(0, 10);
    d.value = d.min;
    var sl = el("wiSlot"); sl.innerHTML = "";
    for (var h = CFG.SALON.openHour; h <= CFG.SALON.closeHour - 1; h++){
      var t = (h < 10 ? "0" : "") + h + ":00";
      var o2 = document.createElement("option");
      o2.value = t; o2.textContent = fmtSlot(t);
      sl.appendChild(o2);
    }
  }

  function saveWalkin(){
    var sid = el("wiService").value;
    var svc = (typeof DB_SERVICES !== "undefined" ? DB_SERVICES : [])
      .filter(function(s){ return String(s.id) === String(sid); })[0];
    var name = el("wiName").value.trim();
    var phone = normPhone(el("wiPhone").value);
    var date = el("wiDate").value, slot = el("wiSlot").value;
    var beautId = el("wiBeaut").value || null;
    if (!svc){ toast("No services available"); return; }
    if (name.length < 2){ toast("Enter customer name"); return; }
    if (!phone){ toast("Enter a valid phone number"); return; }
    toast("Creating...");
    DB.getBookingsByDate(date).then(function(rows){
      var clash = rows.filter(function(x){
        return x.time_slot === slot && x.status !== "cancelled" &&
          String(x.beautician_id || "") === String(beautId || "");
      });
      if (clash.length) throw new Error("slot-taken");
      var ref = (typeof genRefCode === "function") ? genRefCode() : "KBS-" + Date.now().toString().slice(-6);
      var row = {
        customer_name: name, customer_phone: phone,
        service_id: String(svc.id).indexOf("local-") === 0 ? null : svc.id,
        service_name: svc.name, price: svc.price,
        booking_date: date, time_slot: slot,
        ref_code: ref,
        beautician_id: beautId,
        status: "confirmed", payment_method: "cash", payment_status: "unpaid",
        loyalty_earned: 0, loyalty_redeemed: 0, notes: "Walk-in"
      };
      return DB.createBooking(row).catch(function(){
        // older DB without v4 columns
        var core = {
          customer_name: name, customer_phone: phone,
          service_id: row.service_id, service_name: svc.name, price: svc.price,
          booking_date: date, time_slot: slot,
          status: "confirmed", payment_method: "cash", payment_status: "unpaid",
          loyalty_earned: 0, loyalty_redeemed: 0, notes: "Walk-in"
        };
        return DB.createBooking(core);
      });
    }).then(function(){
      toast("Walk-in booking created");
      el("walkinForm").style.display = "none";
      el("wiName").value = ""; el("wiPhone").value = "";
      loadDashboard();
    }).catch(function(e){
      toast(e && e.message === "slot-taken" ? "That slot is already booked" : "Failed — check internet");
    });
  }

  return {
    init: function(){
      initPad();
      initTabs();
      initOfferSubtabs();
      el("ownerDate").addEventListener("change", loadBookings);
      el("setLoyalSave").addEventListener("click", saveLoyalty);
      el("setPaySave").addEventListener("click", savePayAccounts);
      el("setInstaSave").addEventListener("click", saveInstagram);
      el("setVerSave").addEventListener("click", saveUpdateNotice);
      el("setPinSave").addEventListener("click", changePin);
      el("ownerLockTop").addEventListener("click", lock);
      /* dashboard quick actions */
      el("dashWalkin").addEventListener("click", function(){
        var f = el("walkinForm");
        var show = f.style.display === "none";
        f.style.display = show ? "" : "none";
        if (show) initWalkin();
      });
      el("wiCancel").addEventListener("click", function(){ el("walkinForm").style.display = "none"; });
      el("wiSave").addEventListener("click", saveWalkin);
      el("dashAddSvc").addEventListener("click", function(){
        switchOwnerTab("services");
        setTimeout(function(){ openSvcForm(null); }, 200);
      });
      el("dashAddOffer").addEventListener("click", function(){
        switchOwnerTab("offers");
        setTimeout(function(){ openOfferForm(null); }, 200);
      });
      /* customers */
      el("custSearch").addEventListener("input", function(){ paintCustomers(el("custSearch").value); });
      /* offers */
      el("offerAddBtn").addEventListener("click", function(){ openOfferForm(null); });
      el("offerFSave").addEventListener("click", saveOffer);
      el("offerFCancel").addEventListener("click", function(){ el("offerForm").style.display = "none"; });
      el("offerFImg").addEventListener("change", function(){
        offerImgFile = el("offerFImg").files[0] || null;
        if (offerImgFile){
          var r = new FileReader();
          r.onload = function(){ el("offerFImgPrev").src = r.result; el("offerFImgPrev").style.display = ""; };
          r.readAsDataURL(offerImgFile);
        }
      });
      /* coupons */
      el("couponAddBtn").addEventListener("click", function(){ openCouponForm(null); });
      el("couponFSave").addEventListener("click", saveCoupon);
      el("couponFCancel").addEventListener("click", function(){ el("couponForm").style.display = "none"; });
      /* beauticians */
      el("beautAddBtn").addEventListener("click", function(){ openBeautForm(null); });
      el("beautFSave").addEventListener("click", saveBeaut);
      el("beautFCancel").addEventListener("click", function(){ el("beautForm").style.display = "none"; });
      /* existing */
      el("svcAddBtn").addEventListener("click", function(){ openSvcForm(null); });
      el("svcFSave").addEventListener("click", saveService);
      el("svcFCancel").addEventListener("click", function(){ el("svcForm").style.display = "none"; });
      el("svcFImg").addEventListener("change", function(){
        svcImgFile = el("svcFImg").files[0] || null;
        if (svcImgFile){
          var r = new FileReader();
          r.onload = function(){ el("svcFImgPrev").src = r.result; el("svcFImgPrev").style.display = ""; };
          r.readAsDataURL(svcImgFile);
        }
      });
      el("galUploadBtn").addEventListener("click", uploadGallery);
    },
    open: function(){
      gotoPage("owner");
      if (!unlocked){ el("ownerLogin").style.display = ""; el("ownerPanel").style.display = "none"; initPad(); }
    }
  };
})();
