/* Kashish Beauty Salon — booking wizard */
var Booking = (function(){
  "use strict";

  var S = {
    service: null,   // {id,name,price,dur,...}
    date: "",
    slot: "",
    beautId: "",             // v4: beautician id ("" = Any Available)
    beautName: "Any Available",
    coupon: null,            // v4: coupon row
    couponDiscount: 0,
    pay: "cash",
    redeem: false,
    redeemDiscount: 0,
    customer: null,
    loyalCfg: null
  };

  function genRefCode(){
    var chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    var s = "";
    for (var i = 0; i < 6; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
    return "KBS-" + s;
  }
  window.genRefCode = genRefCode;

  function slots(){
    var out = [], h;
    for (h = CFG.SALON.openHour; h <= CFG.SALON.closeHour - 1; h++){
      out.push((h < 10 ? "0" : "") + h + ":00");
    }
    return out;
  }

  function el(id){ return document.getElementById(id); }

  function gotoStep(n){
    [1,2,3,4].forEach(function(i){
      el("bkPane" + i).style.display = (i === n) ? "" : "none";
    });
    el("bkPaneDone").style.display = "none";
    var steps = document.querySelectorAll("#bkSteps .bk-step");
    steps.forEach(function(st){
      var k = parseInt(st.getAttribute("data-s"), 10);
      st.classList.toggle("active", k === n);
      st.classList.toggle("done", k < n);
    });
    window.scrollTo(0, 0);
  }

  function serviceList(){
    return DB_SERVICES.length ? DB_SERVICES : SERVICES.map(function(s, i){
      return { id: "local-" + i, name: s.name, price: s.price,
               duration_min: s.dur || 30, category: s.cat,
               description: s.desc || "" };
    });
  }

  function findService(id){
    return serviceList().filter(function(s){ return String(s.id) === String(id); })[0] || null;
  }

  /* ---------- step 1 ---------- */
  function initStep1(){
    var sel = el("bkService");
    sel.innerHTML = "";
    serviceList().forEach(function(s){
      var o = document.createElement("option");
      o.value = s.id;
      o.textContent = s.name + " — " + rs(s.price);
      sel.appendChild(o);
    });
    if (S.service) sel.value = S.service.id;
    var d = el("bkDate");
    var today = new Date(), max = new Date();
    max.setDate(max.getDate() + 14);
    d.min = today.toISOString().slice(0, 10);
    d.max = max.toISOString().slice(0, 10);
    if (!d.value) d.value = d.min;
    renderBeautChips();
  }

  /* v4: beautician chips — "Any Available" + active beauticians from DB */
  function renderBeautChips(){
    var wrap = el("bkBeautChips");
    if (!wrap) return;
    wrap.innerHTML = "";
    function chip(id, name, sub){
      var b = document.createElement("button");
      b.type = "button";
      b.className = "chip" + (S.beautId === id ? " active" : "");
      b.innerHTML = esc(name) + (sub ? ' <small style="opacity:.7">' + esc(sub) + "</small>" : "");
      b.onclick = function(){
        S.beautId = id; S.beautName = name;
        wrap.querySelectorAll(".chip").forEach(function(x){ x.classList.remove("active"); });
        b.classList.add("active");
      };
      wrap.appendChild(b);
    }
    chip("", "Any Available");
    DB.getBeauticians().then(function(rows){
      (rows || []).forEach(function(bt){
        chip(String(bt.id), bt.name, bt.specialty || "");
      });
    }).catch(function(){ /* table missing — Any Available stays */ });
  }

  function startForService(id){
    if (typeof Auth !== "undefined" && !Auth.isLoggedIn()){
      toast("Please login or sign up to book");
      gotoPage("profile");
      return;
    }
    S.service = findService(id);
    S.slot = "";
    S.beautId = ""; S.beautName = "Any Available";
    S.coupon = null; S.couponDiscount = 0;
    if (el("bkCoupon")) el("bkCoupon").value = "";
    // pre-fill from logged-in profile
    if (typeof Auth !== "undefined"){
      var s = Auth.current();
      if (s){
        if (el("bkName") && !el("bkName").value) el("bkName").value = s.name;
        if (el("bkPhone") && !el("bkPhone").value) el("bkPhone").value = s.phone;
      }
    }
    initStep1();
    gotoStep(1);
    gotoPage("booking");
  }

  /* ---------- step 2 ---------- */
  function loadSlots(){
    S.service = findService(el("bkService").value);
    S.date = el("bkDate").value;
    if (!S.service || !S.date){ toast("Please choose a service and date"); return; }
    el("bkSlotSummary").textContent = S.service.name + " • " + fmtDate(S.date);
    var grid = el("slotGrid");
    grid.innerHTML = "<p>Loading slots...</p>";
    gotoStep(2);
    paintSlotGrid(grid, S.date, null, function(t, b){
      S.slot = t;
      var all = grid.querySelectorAll(".slot");
      all.forEach(function(x){ x.classList.remove("selected"); });
      b.classList.add("selected");
      setTimeout(initStep3, 350);
    }).catch(function(){
      grid.innerHTML = "<p>Could not load slots. Check your internet and try again.</p>";
    });
  }

  /* Shared slot grid: paints free slots for a date; excludeId skips one booking
     (used by reschedule so the booking's own slot is not marked taken).
     onPick(t, btn) fires when a free slot is tapped. */
  function paintSlotGrid(grid, dateIso, excludeId, onPick){
    return DB.getBookingsByDate(dateIso).then(function(rows){
      var taken = {};
      rows.forEach(function(r){
        if (String(r.id) === String(excludeId)) return;
        if (r.status === "cancelled") return;
        taken[r.time_slot] = true;
      });
      // past slots today are unavailable
      var nowH = -1;
      var todayIso = new Date().toISOString().slice(0, 10);
      if (dateIso === todayIso) nowH = new Date().getHours();
      grid.innerHTML = "";
      slots().forEach(function(t){
        var b = document.createElement("button");
        b.type = "button";
        b.className = "slot";
        b.textContent = fmtSlot(t);
        var h = parseInt(t.split(":")[0], 10);
        if (taken[t] || h <= nowH){
          b.classList.add("taken");
          b.disabled = true;
        } else {
          b.addEventListener("click", function(){ onPick(t, b); });
        }
        grid.appendChild(b);
      });
      if (!grid.children.length) grid.innerHTML = "<p>No slots configured.</p>";
    });
  }

  /* ---------- step 3 ---------- */
  function payAccounts(){
    var d = CFG.DEFAULT_PAY_ACCOUNTS || {};
    function one(k){
      var dd = d[k] || {};
      var s = {};
      try { s = JSON.parse(localStorage.getItem(CFG.PAY_ACCOUNTS_KEY) || "{}")[k] || {}; }
      catch(e){ s = {}; }
      if (typeof s === "string") s = { number: s };
      return { title: s.title || dd.title || "", number: s.number || dd.number || "" };
    }
    return { easypaisa: one("easypaisa"), jazzcash: one("jazzcash"), bank: one("bank") };
  }

  function initStep3(){
    gotoStep(3);
    // logged-in user: hide manual name/phone, show "booking as"
    var sess = (typeof Auth !== "undefined") ? Auth.current() : null;
    var asUser = el("bkAsUser");
    if (sess){
      el("bkNameWrap").style.display = "none";
      el("bkPhoneWrap").style.display = "none";
      asUser.style.display = "";
      asUser.textContent = "Booking as " + sess.name + " (" + sess.phone + ")";
    } else {
      el("bkNameWrap").style.display = "";
      el("bkPhoneWrap").style.display = "";
      asUser.style.display = "none";
    }
    // payment cards
    var cards = document.querySelectorAll("#payMethods .pay-card");
    cards.forEach(function(c){
      c.classList.toggle("selected", c.getAttribute("data-pay") === S.pay);
      c.onclick = function(){
        S.pay = c.getAttribute("data-pay");
        cards.forEach(function(x){ x.classList.remove("selected"); });
        c.classList.add("selected");
        syncPayExtra();
      };
    });
    syncPayExtra();
    maybeLoyalty();
    initCoupon();
  }

  /* v4: coupon code input + validation */
  function initCoupon(){
    var msg = el("bkCouponMsg");
    if (!msg) return;
    if (S.coupon){
      msg.textContent = "Coupon " + S.coupon.code + " applied (−" + rs(S.couponDiscount) + ")";
      msg.className = "coupon-msg ok";
    } else {
      msg.textContent = "";
      msg.className = "coupon-msg";
    }
  }

  function applyCoupon(){
    var code = el("bkCoupon").value.trim().toUpperCase();
    var msg = el("bkCouponMsg");
    S.coupon = null; S.couponDiscount = 0;
    if (!code){ initCoupon(); return; }
    if (!S.service){ msg.textContent = "Choose a service first"; return; }
    msg.textContent = "Checking...";
    msg.className = "coupon-msg";
    DB.getCoupon(code).then(function(c){
      var today = new Date().toISOString().slice(0, 10);
      if (!c){ msg.textContent = "Invalid coupon code"; return; }
      if (c.valid_till && c.valid_till < today){ msg.textContent = "This coupon has expired"; return; }
      var subtotal = S.service.price;
      if ((c.min_amount || 0) > subtotal){
        msg.textContent = "Needs a minimum order of " + rs(c.min_amount);
        return;
      }
      var disc = c.discount_percent ? Math.round(subtotal * c.discount_percent / 100) : (c.discount_rs || 0);
      disc = Math.min(disc, subtotal);
      S.coupon = c; S.couponDiscount = disc;
      msg.textContent = "Coupon " + c.code + " applied (−" + rs(disc) + ")";
      msg.className = "coupon-msg ok";
      toast("Coupon applied: −" + rs(disc));
    }).catch(function(){ msg.textContent = "Could not check — try again"; });
  }

  function syncPayExtra(){
    var online = (S.pay !== "cash");
    el("payExtra").style.display = online ? "" : "none";
    if (online){
      var acc = (payAccounts()[S.pay]) || {};
      var labels = { easypaisa: "Easypaisa", jazzcash: "JazzCash", bank: "Bank" };
      el("payAccLabel").textContent = labels[S.pay] || "Account";
      el("payAccTitle").textContent = acc.title || "-";
      el("payAccTitleRow").style.display = acc.title ? "" : "none";
      el("payAccNum").textContent = acc.number || "Not set — ask salon on WhatsApp";
    }
  }

  function maybeLoyalty(){
    var card = el("redeemCard");
    card.style.display = "none";
    S.redeem = false; S.redeemDiscount = 0; S.customer = null;
    var phone = normPhone(el("bkPhone").value);
    if (!phone) return;
    Promise.all([DB.getCustomer(phone), DB.getLoyaltyConfig()]).then(function(r){
      var c = r[0]; S.loyalCfg = r[1];
      if (!c || !(c.loyalty_points > 0)) return;
      S.customer = c;
      var cfg = S.loyalCfg;
      if (c.loyalty_points >= cfg.min_redeem_points){
        el("redeemPts").textContent = c.loyalty_points;
        var units = Math.floor(c.loyalty_points / cfg.redeem_points);
        S.redeemDiscount = units * cfg.redeem_value_rs;
        el("redeemHint").textContent = "Use " + (units * cfg.redeem_points) +
          " points for " + rs(S.redeemDiscount) + " off";
        el("redeemChk").checked = false;
        card.style.display = "";
      }
    }).catch(function(){});
  }

  /* ---------- step 4 : review + confirm ---------- */
  function review(){
    var sess = (typeof Auth !== "undefined") ? Auth.current() : null;
    var name = sess ? sess.name : el("bkName").value.trim();
    var phone = sess ? sess.phone : normPhone(el("bkPhone").value);
    if (!sess){
      name = el("bkName").value.trim();
      if (name.length < 2){ toast("Please enter your name"); return; }
    }
    if (!phone){ toast("Please enter a valid mobile number (03XXXXXXXXX)"); return; }
    if (S.pay !== "cash" && !el("bkTid").value.trim()){
      toast("Please enter the Transaction ID (TID)"); return;
    }
    S.redeem = el("redeemChk").checked && S.redeemDiscount > 0;
    var loyalDisc = S.redeem ? S.redeemDiscount : 0;
    var couponDisc = S.couponDiscount || 0;
    var total = Math.max(0, S.service.price - couponDisc - loyalDisc);
    var payNames = { cash: "Cash at salon", easypaisa: "Easypaisa", jazzcash: "JazzCash", bank: "Bank transfer" };
    var html = "";
    html += '<div class="bill-row"><span>Service</span><strong>' + esc(S.service.name) + '</strong></div>';
    html += '<div class="bill-row"><span>Beautician</span><strong>' + esc(S.beautName) + '</strong></div>';
    html += '<div class="bill-row"><span>Date</span><strong>' + fmtDate(S.date) + '</strong></div>';
    html += '<div class="bill-row"><span>Time</span><strong>' + fmtSlot(S.slot) + '</strong></div>';
    html += '<div class="bill-row"><span>Name</span><strong>' + esc(name) + '</strong></div>';
    html += '<div class="bill-row"><span>Phone</span><strong>' + esc(phone) + '</strong></div>';
    html += '<div class="bill-row"><span>Payment</span><strong>' + payNames[S.pay] + '</strong></div>';
    html += '<div class="bill-row"><span>Price</span><strong>' + rs(S.service.price) + '</strong></div>';
    if (couponDisc) html += '<div class="bill-row"><span>Coupon ' + esc(S.coupon.code) + '</span><strong>− ' + rs(couponDisc) + '</strong></div>';
    if (loyalDisc) html += '<div class="bill-row"><span>Loyalty discount</span><strong>− ' + rs(loyalDisc) + '</strong></div>';
    html += '<div class="bill-row bill-total"><span>Total</span><strong>' + rs(total) + '</strong></div>';
    el("billCard").innerHTML = html;
    S._review = { name: name, phone: phone, total: total, loyalDisc: loyalDisc, couponDisc: couponDisc };
    gotoStep(4);
  }

  function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;"); }

  /* v4: create booking with graceful fallback if the v4 columns do not exist yet */
  function createBookingSafe(row){
    return DB.createBooking(row).catch(function(){
      var core = {
        customer_name: row.customer_name, customer_phone: row.customer_phone,
        service_id: row.service_id, service_name: row.service_name, price: row.price,
        booking_date: row.booking_date, time_slot: row.time_slot,
        status: row.status, payment_method: row.payment_method,
        payment_status: row.payment_status, payment_tid: row.payment_tid,
        loyalty_earned: row.loyalty_earned, loyalty_redeemed: row.loyalty_redeemed,
        notes: row.notes
      };
      return DB.createBooking(core);
    });
  }

  function confirm(){
    var btn = el("bkConfirm");
    btn.disabled = true; btn.textContent = "Booking...";
    var r = S._review;
    // final overlap check, then insert
    DB.getBookingsByDate(S.date).then(function(rows){
      var clash = rows.filter(function(x){
        return x.time_slot === S.slot && x.status !== "cancelled";
      });
      if (clash.length) throw new Error("slot-taken");
      var cfgP = S.loyalCfg ? Promise.resolve(S.loyalCfg) : DB.getLoyaltyConfig();
      return cfgP.then(function(cfg){
        S.loyalCfg = cfg;
        var earned = Math.floor(r.total / 100) * (cfg.points_per_100rs || 1);
        var row = {
          customer_name: r.name, customer_phone: r.phone,
          service_id: String(S.service.id).indexOf("local-") === 0 ? null : S.service.id,
          service_name: S.service.name, price: r.total,
          booking_date: S.date, time_slot: S.slot,
          ref_code: genRefCode(),
          beautician_id: S.beautId ? S.beautId : null,
          coupon_code: S.coupon ? S.coupon.code : "",
          discount_rs: r.couponDisc || 0,
          status: "pending", payment_method: S.pay,
          payment_status: S.pay === "cash" ? "unpaid" : "proof_submitted",
          payment_tid: S.pay === "cash" ? "" : el("bkTid").value.trim(),
          loyalty_earned: earned,
          loyalty_redeemed: S.redeem ? Math.floor(S.redeemDiscount / (S.loyalCfg.redeem_value_rs || 100)) * (S.loyalCfg.redeem_points || 100) : 0,
          notes: el("bkNotes").value.trim()
        };
        return createBookingSafe(row).then(function(created){
          var b = (created && created[0]) || row;
          var ptsDelta = earned - (row.loyalty_redeemed || 0);
          return DB.upsertCustomer(r.name, r.phone, ptsDelta, 1).then(function(){ return b; });
        });
      });
    }).then(function(b){
      done(b, r);
    }).catch(function(e){
      btn.disabled = false; btn.textContent = "Confirm Booking";
      if (e && e.message === "slot-taken"){
        toast("Sorry, this slot just got booked. Please pick another.");
        loadSlots();
      } else if (e && e.status === 409){
        toast("This slot is already booked. Please pick another.");
        loadSlots();
      } else {
        toast("Booking failed — check internet and try again.");
      }
    });
  }

  /* v4: full confirmation screen with reference code */
  function done(b, r){
    ["bkPane1","bkPane2","bkPane3","bkPane4"].forEach(function(id){ el(id).style.display = "none"; });
    el("bkPaneDone").style.display = "";
    var ref = b.ref_code || ("KS-" + String(b.id || "").slice(0, 8).toUpperCase());
    el("doneRef").textContent = ref;
    var payNames = { cash: "Cash at salon", easypaisa: "Easypaisa", jazzcash: "JazzCash", bank: "Bank transfer" };
    var payStatus = S.pay === "cash" ? "Pay at salon" : "Proof submitted — salon will verify";
    var html = "";
    html += '<div class="bill-row"><span>Service</span><strong>' + esc(S.service.name) + '</strong></div>';
    html += '<div class="bill-row"><span>Beautician</span><strong>' + esc(S.beautName) + '</strong></div>';
    html += '<div class="bill-row"><span>Date</span><strong>' + fmtDate(S.date) + '</strong></div>';
    html += '<div class="bill-row"><span>Time</span><strong>' + fmtSlot(S.slot) + '</strong></div>';
    html += '<div class="bill-row"><span>Location</span><strong>Kashish Beauty Salon, Sahiwal</strong></div>';
    html += '<div class="bill-row"><span>Payment</span><strong>' + payNames[S.pay] + '</strong></div>';
    html += '<div class="bill-row"><span>Payment status</span><strong>' + payStatus + '</strong></div>';
    html += '<div class="bill-row bill-total"><span>Total</span><strong>' + rs(r.total) + '</strong></div>';
    el("doneDetails").innerHTML = html;
    var msg = "Assalam-o-Alaikum! New booking at Kashish Beauty Salon\n" +
      "Ref: " + ref + "\n" +
      "Name: " + r.name + "\n" +
      "Phone: " + r.phone + "\n" +
      "Service: " + S.service.name + "\n" +
      "Beautician: " + S.beautName + "\n" +
      "Date: " + fmtDate(S.date) + "\n" +
      "Time: " + fmtSlot(S.slot) + "\n" +
      "Total: " + rs(r.total) + "\n" +
      "Payment: " + S.pay +
      (S.pay !== "cash" ? "\nTID: " + el("bkTid").value.trim() : "");
    el("doneWa").href = "whatsapp://send?phone=" + CFG.SALON.whatsapp + "&text=" + encodeURIComponent(msg);
    window.scrollTo(0, 0);
  }

  function reset(){
    S.slot = ""; S.redeem = false; S.redeemDiscount = 0;
    S.beautId = ""; S.beautName = "Any Available";
    S.coupon = null; S.couponDiscount = 0;
    ["bkName","bkPhone","bkTid","bkNotes","bkCoupon"].forEach(function(id){ if (el(id)) el(id).value = ""; });
    el("redeemChk").checked = false;
    initStep1();
    gotoStep(1);
  }

  /* ---------- v4: reschedule an upcoming booking ---------- */
  var RS = { id: null, date: "", slot: "" };

  function openReschedule(id, curDate, curSlot){
    RS.id = id; RS.date = curDate || ""; RS.slot = "";
    var html =
      '<h3 class="sec-title">Reschedule Booking</h3>' +
      '<div class="form-group"><label>New date</label><input type="date" id="rsDate"></div>' +
      '<div class="slot-grid" id="rsSlots"></div>' +
      '<button class="btn btn-gold btn-block" id="rsGo">Confirm Reschedule</button>' +
      '<button class="btn btn-outline btn-block" id="rsCancel">Cancel</button>';
    App.openModal(html);
    var d = document.getElementById("rsDate");
    var today = new Date(), max = new Date();
    max.setDate(max.getDate() + 14);
    d.min = today.toISOString().slice(0, 10);
    d.max = max.toISOString().slice(0, 10);
    d.value = (RS.date >= d.min && RS.date <= d.max) ? RS.date : d.min;
    RS.date = d.value;
    function loadRs(){
      RS.date = d.value; RS.slot = "";
      var grid = document.getElementById("rsSlots");
      grid.innerHTML = "<p>Loading slots...</p>";
      paintSlotGrid(grid, RS.date, RS.id, function(t, b){
        RS.slot = t;
        grid.querySelectorAll(".slot").forEach(function(x){ x.classList.remove("selected"); });
        b.classList.add("selected");
      }).catch(function(){ grid.innerHTML = "<p>Could not load slots.</p>"; });
    }
    d.addEventListener("change", loadRs);
    document.getElementById("rsCancel").onclick = function(){ App.closeModal(); };
    document.getElementById("rsGo").onclick = function(){
      if (!RS.slot){ toast("Pick a time slot"); return; }
      toast("Rescheduling...");
      DB.updateBooking(RS.id, { booking_date: RS.date, time_slot: RS.slot }).then(function(){
        App.closeModal();
        toast("Booking rescheduled");
        App.renderProfile();
      }).catch(function(){ toast("Failed — check internet"); });
    };
    loadRs();
  }

  /* ---------- public ---------- */
  return {
    init: function(){
      el("bkToStep2").addEventListener("click", loadSlots);
      el("bkToStep4").addEventListener("click", review);
      el("bkConfirm").addEventListener("click", confirm);
      el("doneNew").addEventListener("click", reset);
      el("payCopyBtn").addEventListener("click", function(){
        var t = el("payAccNum").textContent;
        copyText(t);
      });
      el("bkPhone").addEventListener("change", maybeLoyalty);
      el("bkCouponApply").addEventListener("click", applyCoupon);
      el("doneView").addEventListener("click", function(e){
        e.preventDefault();
        App.renderProfile();
        gotoPage("profile");
      });
      var backs = document.querySelectorAll("[data-bkback]");
      backs.forEach(function(a){
        a.addEventListener("click", function(e){
          e.preventDefault();
          gotoStep(parseInt(a.getAttribute("data-bkback"), 10));
        });
      });
      initStep1();
    },
    startForService: startForService,
    reset: reset,
    reschedule: openReschedule,
    refreshServices: initStep1
  };
})();

function copyText(t){
  function ok(){ toast("Copied!"); }
  if (navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(t).then(ok, function(){ fallback(); });
  } else fallback();
  function fallback(){
    var ta = document.createElement("textarea");
    ta.value = t; document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); ok(); } catch(e){ toast("Copy manually: " + t); }
    document.body.removeChild(ta);
  }
}
