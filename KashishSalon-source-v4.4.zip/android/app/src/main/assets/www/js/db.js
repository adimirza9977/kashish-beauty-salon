/* Kashish Beauty Salon — Supabase REST wrapper (PostgREST via fetch) */
var DB = (function(){
  "use strict";
  var base = CFG.SUPABASE_URL + "/rest/v1";

  function hdrs(){
    return {
      "apikey": CFG.SUPABASE_ANON_KEY,
      "Authorization": "Bearer " + CFG.SUPABASE_ANON_KEY,
      "Content-Type": "application/json"
    };
  }

  function handle(res){
    if (!res.ok) {
      return res.text().then(function(t){
        var err = new Error("DB error " + res.status);
        err.status = res.status; err.body = t;
        throw err;
      });
    }
    return res.json().catch(function(){ return []; });
  }

  function get(table, params){
    var qs = params ? "?" + params : "";
    return fetch(base + "/" + table + qs, { headers: hdrs() }).then(handle);
  }

  function insert(table, row){
    return fetch(base + "/" + table, {
      method: "POST",
      headers: Object.assign({ "Prefer": "return=representation" }, hdrs()),
      body: JSON.stringify(row)
    }).then(handle);
  }

  function update(table, params, patch){
    return fetch(base + "/" + table + "?" + params, {
      method: "PATCH",
      headers: Object.assign({ "Prefer": "return=representation" }, hdrs()),
      body: JSON.stringify(patch)
    }).then(handle);
  }

  function enc(v){ return encodeURIComponent(v); }

  function sha256(str){
    var buf = new TextEncoder().encode(str);
    return crypto.subtle.digest("SHA-256", buf).then(function(hash){
      return Array.prototype.map.call(new Uint8Array(hash), function(b){
        return ("0" + b.toString(16)).slice(-2);
      }).join("");
    });
  }

  return {
    sha256: sha256,
    /* ---- services ---- */
    getServices: function(){
      return get("services", "select=*&active=eq.true&order=category,name");
    },
    seedServices: function(list){
      // insert defaults one by one (simple + reliable on free tier)
      var chain = Promise.resolve();
      list.forEach(function(s){
        chain = chain.then(function(){
          return insert("services", {
            name: s.name, description: s.desc || "",
            price: s.price, duration_min: s.dur || 30,
            category: s.cat, active: true
          }).catch(function(){ /* already seeded / ignore */ });
        });
      });
      return chain;
    },

    /* ---- bookings ---- */
    getBookingsByDate: function(dateIso){
      return get("bookings",
        "select=*&booking_date=eq." + enc(dateIso) +
        "&status=neq.cancelled&order=time_slot");
    },
    getAllBookings: function(limit){
      return get("bookings",
        "select=*&order=booking_date.desc,time_slot.desc&limit=" + (limit || 200));
    },
    getPendingPayments: function(){
      return get("bookings",
        "select=*&payment_status=eq.proof_submitted&order=created_at.desc");
    },
    createBooking: function(row){ return insert("bookings", row); },
    setBookingStatus: function(id, status){
      return update("bookings", "id=eq." + enc(id), { status: status });
    },
    setPaymentStatus: function(id, payment_status){
      return update("bookings", "id=eq." + enc(id), { payment_status: payment_status });
    },

    /* ---- customers / loyalty ---- */
    getCustomer: function(phone){
      return get("customers", "select=*&phone=eq." + enc(phone)).then(function(r){ return r[0] || null; });
    },
    upsertCustomer: function(name, phone, pointsDelta, visitDelta){
      var self = this;
      return self.getCustomer(phone).then(function(c){
        if (c) {
          return update("customers", "id=eq." + enc(c.id), {
            name: name,
            loyalty_points: (c.loyalty_points || 0) + (pointsDelta || 0),
            total_visits: (c.total_visits || 0) + (visitDelta || 0)
          }).then(function(r){ return r[0]; });
        }
        return insert("customers", {
          name: name, phone: phone,
          loyalty_points: Math.max(0, pointsDelta || 0),
          total_visits: visitDelta || 0
        }).then(function(r){ return r[0]; });
      });
    },

    /* ---- loyalty config ---- */
    getLoyaltyConfig: function(){
      return get("loyalty_config", "select=*&id=eq.1").then(function(r){
        return r[0] || { points_per_100rs: 1, redeem_points: 100, redeem_value_rs: 100, min_redeem_points: 100 };
      });
    },
    saveLoyaltyConfig: function(cfg){
      cfg.updated_at = new Date().toISOString();
      return update("loyalty_config", "id=eq.1", cfg);
    },

    /* ---- connectivity probe ---- */
    ping: function(){
      return get("services", "select=id&limit=1").then(function(){ return true; })
        .catch(function(e){ if (e && e.status === 404) return "no-tables"; throw e; });
    },

    /* ---- customer auth (v3) ---- */
    signupCustomer: function(name, phone, whatsapp, passwordHash){
      return insert("customers", {
        name: name, phone: phone, whatsapp: whatsapp || "",
        password_hash: passwordHash, loyalty_points: 0, total_visits: 0
      }).then(function(r){ return r[0]; });
    },
    loginCustomer: function(phone, passwordHash){
      return get("customers",
        "select=*&phone=eq." + enc(phone) +
        "&password_hash=eq." + enc(passwordHash)
      ).then(function(r){ return r[0] || null; });
    },
    getCustomerById: function(id){
      return get("customers", "select=*&id=eq." + enc(id)).then(function(r){ return r[0] || null; });
    },
    setCustomerWhatsapp: function(id, whatsapp){
      return update("customers", "id=eq." + enc(id), { whatsapp: whatsapp });
    },
    getBookingsByPhone: function(phone){
      return get("bookings",
        "select=*&customer_phone=eq." + enc(phone) +
        "&order=booking_date.desc,time_slot.desc&limit=100");
    },
    cancelBooking: function(id){
      return update("bookings", "id=eq." + enc(id), { status: "cancelled" });
    },

    /* ---- owner bookings view (v3): all upcoming first ---- */
    getUpcomingBookings: function(){
      var today = new Date().toISOString().slice(0, 10);
      return get("bookings",
        "select=*&booking_date=gte." + today +
        "&status=in.(pending,confirmed)&order=booking_date,time_slot&limit=200");
    },

    /* ---- services manager (v3) ---- */
    addService: function(row){ return insert("services", row).then(function(r){ return r[0]; }); },
    updateService: function(id, patch){ return update("services", "id=eq." + enc(id), patch); },
    deleteService: function(id){
      return update("services", "id=eq." + enc(id), { active: false });
    },

    /* ---- gallery (v3) ---- */
    getGallery: function(){
      return get("gallery", "select=*&order=sort_order,created_at");
    },
    addGalleryItem: function(imageUrl, caption){
      return insert("gallery", { image_url: imageUrl, caption: caption || "" })
        .then(function(r){ return r[0]; });
    },
    deleteGalleryItem: function(id){
      return fetch(base + "/gallery?id=eq." + enc(id), {
        method: "DELETE", headers: hdrs()
      }).then(handle);
    },

    /* ---- salon settings (v3): owner PIN etc., survives reinstall ---- */
    getSetting: function(key){
      return get("salon_settings", "select=value&key=eq." + enc(key))
        .then(function(r){ return r.length ? r[0].value : null; })
        .catch(function(){ return null; });
    },
    setSetting: function(key, value){
      var self = this;
      return self.getSetting(key).then(function(existing){
        if (existing === null) {
          return insert("salon_settings", { key: key, value: value }).catch(function(){ return null; });
        }
        return update("salon_settings", "key=eq." + enc(key), {
          value: value, updated_at: new Date().toISOString()
        }).catch(function(){ return null; });
      });
    },

    /* ---- forgot password / OTP reset (v3.1) ---- */
    createResetOTP: function(phone){
      var self = this;
      return self.getCustomer(phone).then(function(c){
        if (!c) throw new Error("no-account");
        var otp = String(Math.floor(100000 + Math.random() * 900000));
        var exp = new Date(Date.now() + 15 * 60000).toISOString();
        return insert("password_resets", {
          phone: phone, otp: otp, expires_at: exp, used: false
        }).then(function(){ return { otp: otp, name: c.name }; });
      });
    },
    getPendingResets: function(){
      var now = new Date().toISOString();
      return get("password_resets",
        "select=*&used=eq.false&expires_at=gt." + enc(now) + "&order=created_at.desc&limit=50");
    },
    verifyResetOTP: function(phone, otp){
      var now = new Date().toISOString();
      return get("password_resets",
        "select=*&phone=eq." + enc(phone) + "&otp=eq." + enc(otp) +
        "&used=eq.false&expires_at=gt." + enc(now) + "&limit=1")
        .then(function(r){ return r[0] || null; });
    },
    resetPassword: function(phone, otp, newHash){
      var self = this;
      return self.verifyResetOTP(phone, otp).then(function(rec){
        if (!rec) throw new Error("invalid-otp");
        return update("password_resets", "id=eq." + enc(rec.id), { used: true })
          .then(function(){ return self.getCustomer(phone); })
          .then(function(c){
            if (!c) throw new Error("no-account");
            return update("customers", "id=eq." + enc(c.id), { password_hash: newHash });
          });
      });
    },
    markResetSent: function(id){
      // optional: owner can delete the request after sending the code
      return fetch(base + "/password_resets?id=eq." + enc(id), {
        method: "DELETE", headers: hdrs()
      }).then(handle).catch(function(){ return null; });
    },

    /* ---- image upload to Supabase Storage (v3) ---- */
    uploadImage: function(file){
      var ext = (file.name && file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      var filename = "img_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8) + "." + ext;
      var url = CFG.SUPABASE_URL + "/storage/v1/object/salon-media/" + filename;
      return fetch(url, {
        method: "POST",
        headers: {
          "apikey": CFG.SUPABASE_ANON_KEY,
          "Authorization": "Bearer " + CFG.SUPABASE_ANON_KEY,
          "Content-Type": file.type || "image/jpeg"
        },
        body: file
      }).then(function(res){
        if (!res.ok) throw new Error("upload failed " + res.status);
        return CFG.SUPABASE_URL + "/storage/v1/object/public/salon-media/" + filename;
      });
    },

    /* ---- beauticians (v4) ---- */
    getBeauticians: function(){
      return get("beauticians", "select=*&is_active=eq.true&order=name").catch(function(){ return []; });
    },
    getAllBeauticians: function(){
      return get("beauticians", "select=*&order=name").catch(function(){ return []; });
    },
    addBeautician: function(row){
      return insert("beauticians", row).then(function(r){ return r[0]; });
    },
    updateBeautician: function(id, patch){
      return update("beauticians", "id=eq." + enc(id), patch);
    },

    /* ---- offers (v4) ---- */
    getOffers: function(){
      var today = new Date().toISOString().slice(0, 10);
      return get("offers",
        "select=*&is_active=eq.true&or=(valid_till.is.null,valid_till.gte." + today + ")&order=created_at.desc"
      ).catch(function(){ return []; });
    },
    getAllOffers: function(){
      return get("offers", "select=*&order=created_at.desc").catch(function(){ return []; });
    },
    addOffer: function(row){
      return insert("offers", row).then(function(r){ return r[0]; });
    },
    updateOffer: function(id, patch){
      return update("offers", "id=eq." + enc(id), patch);
    },

    /* ---- coupons (v4) ---- */
    getCoupon: function(code){
      return get("coupons",
        "select=*&code=eq." + enc(String(code || "").toUpperCase()) + "&is_active=eq.true"
      ).then(function(r){ return r[0] || null; }).catch(function(){ return null; });
    },
    getAllCoupons: function(){
      return get("coupons", "select=*&order=created_at.desc").catch(function(){ return []; });
    },
    addCoupon: function(row){
      return insert("coupons", row).then(function(r){ return r[0]; });
    },
    updateCoupon: function(id, patch){
      return update("coupons", "id=eq." + enc(id), patch);
    },

    /* ---- favorites (v4) ---- */
    getFavorites: function(customerId){
      return get("favorites", "select=service_id&customer_id=eq." + enc(customerId))
        .catch(function(){ return []; });
    },
    addFavorite: function(customerId, serviceId){
      return insert("favorites", { customer_id: customerId, service_id: String(serviceId) })
        .then(function(r){ return r[0] || null; })
        .catch(function(){ return null; });
    },
    removeFavorite: function(customerId, serviceId){
      return fetch(base + "/favorites?customer_id=eq." + enc(customerId) +
        "&service_id=eq." + enc(String(serviceId)), {
        method: "DELETE", headers: hdrs()
      }).then(handle).catch(function(){ return null; });
    },

    /* ---- ratings & generic booking updates (v4) ---- */
    updateBooking: function(id, patch){
      return update("bookings", "id=eq." + enc(id), patch);
    },
    getServiceReviews: function(serviceId){
      return get("bookings",
        "select=rating,review,customer_name,created_at&service_id=eq." + enc(serviceId) +
        "&rating=not.is.null&order=created_at.desc&limit=20"
      ).catch(function(){ return []; });
    },

    /* ---- customers list / delete (v4) ---- */
    getCustomers: function(){
      return get("customers", "select=*&order=total_visits.desc,loyalty_points.desc&limit=300")
        .catch(function(){ return []; });
    },
    deleteCustomer: function(id){
      return fetch(base + "/customers?id=eq." + enc(id), {
        method: "DELETE", headers: hdrs()
      }).then(handle);
    }
  };
})();
