# Kashish Beauty Salon — Version Log (MASTER APK)

Package: com.kashish.salon
Source of truth for version: AndroidManifest.xml (versionCode + versionName)

RULE (adeel's order 2026-10-12): every update bumps versionCode by 1 and
updates versionName. Same package always — updates install OVER the old APK,
never a new app.

## History
- v1.0 (versionCode 1) — 2026-10-09: first app (services list, gallery, contact)
- v2.0 (versionCode 2) — 2026-10-12: full rebuild — online booking (Supabase),
  payments (Cash/Easypaisa/JazzCash/Bank/Card), loyalty points, owner panel
  (PIN 1234), WhatsApp booking alerts, rose-gold redesign, Redmi Note 13 fix
  (minSdk 24 / targetSdk 34), WhatsApp external-intent fix, topbar owner button.
- v2.1 (versionCode 3) — 2026-10-12: WhatsApp deep-link fix (whatsapp://send opens
  chat directly; wa.me fallback if WhatsApp not installed); owner-panel WhatsApp
  button param fix (?text= -> &text=).
- v3.0 (versionCode 4) — 2026-10-12: customer accounts — signup/login/profile;
  booking requires login; user sees own bookings + statuses + cancel option;
  owner PIN stored in Supabase (survives reinstall); owner bookings show all
  upcoming by default; OWNER MANAGERS: services (add/edit/delete, rates, pictures),
  gallery (upload/delete pictures); file picker support in app.
- v3.1 (versionCode 5) — 2026-10-12: forgot password — 6-digit OTP reset flow
  (user requests code via WhatsApp to salon, owner sends code from new Resets
  tab, user sets new password); OTP valid 15 min.
- v3.2 (versionCode 6) — 2026-10-12: in-app update notice — non-blocking English
  banner on Home when a newer version is published; owner sets latest version +
  APK link in Owner > Settings > App Update Notice (stored in Supabase).
- v3.3 (versionCode 7) — 2026-10-12: owner editable featured services (star toggle
  in Services manager + custom pictures); Instagram link editable in Owner >
  Settings (default fixed to @kashish_beautysalon); payment accounts now have
  separate title (holder name) + number fields, title shown to customers.
- v3.4 (versionCode 8) — 2026-10-12: prominent owner logout — Lock Panel button
  moved to the top of the owner panel (always visible golden bar), no longer
  buried in Settings.
- v3.5 (versionCode 9) — 2026-10-12: real salon branding — Instagram page
  (kashish_salon_sahiwal) logo as app icon + in-app header/splash logo;
  Instagram link corrected; gallery replaced with 8 HD salon pictures
  (old stock photos deleted).
- v4.0 (versionCode 10) — 2026-10-12: MODERN LUXURY redesign (ChatGPT UI/UX
  plan): HOME — hero banner with Book Appointment CTA, Popular Services row,
  Recommended For You, Today's Offers carousel (owner-managed), Upcoming
  Appointment card, Visit Us (address/hours/Call/WhatsApp/Instagram);
  SERVICE DETAILS screen (image, price, duration, ratings, inclusions, prep
  tips, Book Now, favorite heart); BOOKING — beautician selection (Any
  Available + staff list), coupon code apply (percent/flat, min amount,
  expiry), booking reference number (KBS-XXXXXX), full confirmation screen
  (View My Bookings, WhatsApp salon); reschedule upcoming bookings;
  PROFILE — Upcoming/Completed/Cancelled tabs, 5-star ratings + reviews on
  completed bookings, My Favorites, WhatsApp reminder toggles, delete
  account, privacy policy; OWNER — Dashboard (today's bookings/revenue,
  pending, upcoming, overlap alerts, walk-in booking, quick actions),
  Customers list + history, Offers manager, Coupons manager, Beauticians
  manager. DB: services.duration_min, bookings ref_code/rating/review/
  coupon_code/discount_rs/beautician_id, new tables beauticians, favorites,
  offers, coupons.
- v4.1 (versionCode 11) — 2026-10-12: LUXURY RESKIN (Dribbble inspiration
  pictures from the ChatGPT plan): blush-pink canvas with gold/rose glows,
  white floating cards (20-28px radii), royal burgundy #4B2438 + champagne
  gold #C9AC78 + rose #D96C85, Playfair Display serif headings + Jost body
  (Google Fonts, offline fallbacks), gold eyebrow section headers, maroon
  gradient pill CTAs, floating white pill bottom nav, taller hero with
  burgundy gradient overlay, photo offer banners with gold badges, gold
  loyalty card, gold-ringed splash. Pure visual redesign — all features and
  IDs unchanged.

## v4.2 (versionCode 12) — 2026-10-12
- Hero kicker text: "Ladies Beauty Salon" → "Kashish Beauty Salon · Sahiwal" (user's correction)
- Page horizontal-scroll lock: `overflow-x:hidden` + `overscroll-behavior-x:none` on html/body — app no longer wobbles side-to-side like a website; fixed like a proper app
- All 40 services now have real cover pictures (10 per-category stock photos uploaded to Supabase salon-media bucket; owner can change any picture from Owner → Services → edit)

## v4.3 (versionCode 13) — 2026-10-12
- FIX: home "Popular Services" / "Recommended For You" cards showed letter placeholders instead of pictures. Root cause: home rendered from the local fallback list before the network fetch of services finished, and never re-rendered. Now home cards re-render after DB services load (initDB + refreshServices), so pictures show whenever set — letters only when a service truly has no picture.

## v4.4 (versionCode 14) — 2026-10-12
- Owner → Offers → Coupons: new "Share" button on every coupon — opens WhatsApp with a ready discount message (code, discount, min order, validity) so the owner can send the coupon to customers. Coupon creation itself (code, % or Rs discount, min order, valid-till) already existed.

## v5.0 (versionCode 15) — 2026-10-12 — SECURITY HARDENING
- Closed 4 critical holes: (1) RLS locked down — anon key can only read the
  public catalog (services/offers/coupons/gallery/beauticians/loyalty config);
  customers/bookings/favorites/password_resets are INVISIBLE to the anon key.
  (2) Owner PIN now verified SERVER-SIDE (12-hour session tokens) — the hash is
  no longer readable or comparable from the app. (3) Loyalty points are computed
  and awarded SERVER-SIDE inside place_booking — cannot be forged from the app.
  (4) Coupon validation + prices validated server-side on every booking.
- New: customer signup/login/password-hash auth via secure functions; booking
  cancel/reschedule/rate by ref code + password proof; owner does everything
  through an allow-listed server dispatcher (booking_walkin, loyalty_award with
  ledger, pin_change, etc.).
- New: Owner PIN recovery — "Forgot PIN?" on the PIN pad + a one-time
  8-character recovery code in Owner → Settings. The code is shown once (write
  it down); entering it resets the PIN and issues a fresh code.
- Requires Supabase migration: supabase_v5_security.sql + supabase_v5_delta.sql
  (both idempotent; add pgcrypto extension).
- Source backup: KashishSalon-source-v5.0.zip (build_apk.sh now auto-creates it).

## v5.0 rebuild 2 (versionCode 15, versionName 5.0 — NO bump, adeel's order)
- Owner → Customers → customer detail: new **Block/Unblock** button (blocked
  customers cannot login or book; their sessions are dropped) and **Delete**
  button (double-confirm; bookings stay in history). Blocked badge in the list.
- Server: customers.is_blocked; customer_login/customer_get return blocked
  state; place_booking rejects blocked customers; new owner functions
  owner_customers_list / owner_customer_set_blocked / owner_customer_bookings.
- Migration: supabase_v5_patch4.sql (also removed the v5 test customer).

## v5.1 (versionCode 16) — 2026-10-12
- Version bump from 5.0 rebuild 2 (adeel's order: banner should appear).
  No functional changes vs 5.0 rebuild 2 — same block/delete features.
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@105b8bb1bb943d35cb3a274b3a2c8e108497a8c9/KashishBeautySalon.apk (commit 105b8bb "Update to v5.1 APK (fixed: internal version now 5.1/16)" — first v5.1 build had stale internal config.js 5.0/15 because the version sync ran AFTER aapt2 packaging; build_apk.sh fixed: sync now runs BEFORE packaging + QA gate 2 verifies the version inside the built APK). Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@c5e51a8bf8d7183942bc08c29c9a5c5a2f5fe2d/KashishSalon-source-v5.1.zip (commit c5e51a8 "Update v5.1 source backup zip" — zip now also includes patch SQL files + checklist).

## v5.2 (versionCode 17) — 2026-10-12
- Luxury animated offer banner pinned at the very top of Home: newest active
  offer shows in premium gold style (percent + offer title + valid-till) with
  shimmer sweep, twinkling sparkles, glowing gold border and crown.
  Tap opens the offer detail. Refreshes live when the owner saves an offer.
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@51af3aa9e5472cbc1fe38d1985047f4473cb9d36/KashishBeautySalon.apk (commit 51af3aa "Update to v5.2 APK"). Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@239e27e58e61eb5563afd0632e272a04a3a8901d/KashishSalon-source-v5.2.zip (commit 239e27e "Add v5.2 source backup zip"). Update notice set to 5.2/17.

## v5.3 (versionCode 18) — 2026-10-12
- Per-service percent off (adeel's order): Owner → Services → each service has
  "Discount % off" (0-90). The percent comes off the total booking price
  (server-side in place_booking + walk-in; shown in the booking bill).
- New luxury banner at top of Home listing ALL discounted services in ONE
  banner (never separate banners): 1 service → big % + name; multiple →
  "N Services on Sale" + list, tap opens an animated luxury modal with the
  full list (name, discounted price, struck original, % badge). Service cards
  also show a gold % OFF badge + struck price.
- NEW: "Download App" section on Home — QR code (encodes the latest APK URL,
  self-updating every version) + the link written below it + Copy Link +
  WhatsApp Share buttons (wa.me share with message text).
- ANDROID COMPATIBILITY: minSdkVersion lowered 24 → 21 (Android 5.0+) — app
  installs on EVERY Android phone (his standing order "har mobile mein
  install honi chahie, lazmi").
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@44198efbb54ed4bab341573fce1d031fc5aac220/KashishBeautySalon.apk (commit 44198ef "Update to v5.3 APK (Download App QR + minSdk 21)" — download-verified: versionCode 18, internal config 5.3/18, QR lib bundled, all features present). Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@cd73fef3f3d713e00916d7cacd3ead5f144c843c/KashishSalon-source-v5.3.zip (commit cd73fef "Update to v5.3 APK (Download App QR + minSdk 21)"). Update notice set to 5.3/18 (SELECT-verified 2026-10-12 ~12:17 PKT).
- Server: supabase_v5_patch5.sql (services.discount_percent; svc_upsert +
  place_booking + booking_walkin apply the discount, clamped 0-90) — applied
  and verified 2026-10-12.
- CURRENT MASTER: v5.3 (delivered 2026-10-12 ~12:17 PKT). adeel will share with
  people for testing and report results tomorrow (2026-10-13).

## v5.4 (versionCode 19) — 2026-10-12 — PHONE NOTIFICATIONS
- adeel's order: "jab bhi koi new offer ya kisi service par % off lage, sabko
  mobile par app ka notification aaye (jaise baaki apps ka hota hai)".
- New native notification system (framework APIs only — no external libraries,
  safe for the manual aapt2 build): OfferCheckJob (JobScheduler, every 4h,
  persisted) + BootReceiver (re-schedules after reboot) + NotifHelper.
  Checks Supabase for NEW active offers and NEW/INCREASED service discounts
  vs last-seen state; posts a phone notification ("New Offer at Kashish!" /
  "% OFF on <service>") that opens the app on tap. First run seeds silently
  (no spam for old offers). Also checks immediately on every app start.
  Android 13+ asks for POST_NOTIFICATIONS permission once on launch.
- NOTE: this is background-polling notification (up to ~4h delay), NOT
  instant FCM push. adeel created the Firebase project himself 2026-10-12
  (project kashish-beauty-salon, package com.kashish.salon — google-services.json
  saved at ~/workspace/kashish_salon/firebase/, kept out of git/zip); instant
  FCM push is the future upgrade path (needs FCM SDK in the manual build +
  a server sender — high risk, deferred).
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@f8ac6db3408ec3630fa1c6644ccc75999554ffac/KashishBeautySalon.apk (commit f8ac6db "Update to v5.4 APK (offer/discount phone notifications)" — download-verified: versionCode 19, internal config 5.4/19, NotifHelper/OfferCheckJob/BootReceiver in dex, bell icon present). Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@b1dd0561cd0bf791e043c55d02bb254a1d0fc623/KashishSalon-source-v5.4.zip (commit b1dd056 "Add v5.4 source backup zip"). Update notice set to 5.4/19.
- CURRENT MASTER: v5.4 (delivered 2026-10-12).

## v5.5 (versionCode 20) — 2026-10-12 — INSTANT FCM PUSH NOTIFICATIONS
- adeel's order: notifications must be INSTANT (not polling) for EVERYTHING
  new — new offer, new/increased service % off, new service, new app update —
  "fori" (immediately), like other apps.
- TRUE FCM push (his explicit demand; replaces the v5.4 polling as the primary
  channel — the 4h poll remains as a backup):
  CLIENT (manual aapt2 build, no Gradle): firebase-messaging:24.1.2 (latest
  with minSdk 21 — 25.x/26.x need minSdk 23/24, breaking his "har mobile"
  rule) + full transitive AAR tree (68 artifacts) resolved via
  fcm/fetch_aars.py (Maven POM resolver), merged via fcm/merge_fcm.py
  (classes -> d8, res/ -> aapt2). Solved: library R-class references via
  fcm/gen_r_stubs.py (generates androidx.core / gms / mediacompat R stubs
  from the app's R.java); unresolvable appcompat symbols stubbed in
  res/values/fcm_stubs.xml; NotificationCompat UI resources pruned from the
  merge. Manifest: FirebaseInitProvider, FirebaseInstanceIdReceiver,
  KashishMessagingService (MESSAGING_EVENT), ComponentDiscoveryService (+7
  registrars), datatransport services/receiver, GoogleApiActivity.
  google-services.json values -> res/values/firebase.xml.
  KashishMessagingService: onNewToken -> registers token in Supabase
  push_tokens (upsert); onMessageReceived -> shows notification from data
  payload (title/body/type). MainActivity syncs token on every start.
  SERVER: push_tokens table (token PK, RLS: anon INSERT+SELECT); Edge Function
  `send-push` (Deno): verifies ?secret=, maps DB-webhook payloads to
  notification text (offer/service_new/service_off/app_update/test), gets
  FCM OAuth token via service-account JWT (jose), sends FCM HTTP v1 data
  messages to all tokens. Secrets: PUSH_SECRET, FIREBASE_SA_JSON,
  SUPABASE_URL (+ built-in anon key; dashboard rejects SUPABASE_ custom
  prefix). JWT enforcement OFF. DB webhooks: push-on-offer (offers
  INSERT/UPDATE), push-on-service (services INSERT/UPDATE),
  push-on-app-update (salon_settings UPDATE).
  OWNER: Settings -> "Send Test Notification" button (calls the function
  directly) so adeel can verify anytime.
- adeel's Firebase project: kashish-beauty-salon (created by him 2026-10-12);
  google-services.json + service-account.json saved privately at
  ~/workspace/kashish_salon/firebase/ (NOT in git, NOT in source zip).
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@c02eb7098eaa6f1175f3cfa72ca8031f0cb317cb/KashishBeautySalon.apk (commit c02eb70 "Update to v5.5 APK (instant FCM push notifications)" — download-verified: versionCode 20, internal config 5.5/20, FCM classes in dex, test button present). Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@c5e6eb1616c3f87e9a56abe1921203d238b0b10c/KashishSalon-source-v5.5.zip (commit c5e6eb1 "Add v5.5 source backup zip"). Update notice set to 5.5/20 (SELECT-verified).
- CURRENT MASTER: v5.5 (delivered 2026-10-12).

## v5.5.1 (versionCode 21) — 2026-10-12 — CRASH DIAGNOSIS BUILD
- v5.5 crashed instantly on launch on adeel's phone ("keeps stopping", then
  white blink -> back to launcher). Static analysis ruled out: R stubs (real
  values, in dex), firebase.xml strings (in resources.arsc), manifest (valid),
  my Java (all try/catch). Exact cause unknown -> this build adds
  CrashInitProvider (initOrder 101, runs BEFORE FirebaseInitProvider):
  installs a global uncaught-exception handler that saves the stack trace to
  crash.log and POSTs it to Supabase crash_reports (anon INSERT). Next launch
  flushes any saved log. Temporary diagnostic build, not a feature release.
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@b30722a4a87d63f8d44d9e980b261f16264edba4/KashishBeautySalon.apk (commit b30722a "Update to v5.5.1 APK (crash reporter to diagnose startup crash)" — download-verified: versionCode 21, versionName 5.5.1, CrashInitProvider in dex). Source: KashishSalon-source-v5.5.1.zip (same commit). Update notice set to 5.5.1/21.

## v5.5.2 (versionCode 22) — 2026-10-12 — STARTUP CRASH FIX
- Root cause (from crash_reports table, adeel's device): NoSuchFieldError
  common_google_play_services_unknown_issue in gms/common/R$string <-
  StringResourceValueReader.<init> <- FirebaseOptions.fromResource <-
  FirebaseApp.initializeApp <- FirebaseInitProvider.onCreate.
  Play-services string resources were MISSING from the APK because
  merge_fcm.py used FIRST-ONE-WINS for res/values/values.xml
  (coordinatorlayout's file won alphabetically; play-services-base/basement
  values silently dropped).
- Fix: merge_fcm.py now MERGES all values XMLs by (tag,name) entry
  (regex-based, keeps xmlns:xliff decl); deleted fcm_stubs.xml (its stub
  dimens now conflict with the real merged values). aapt2 compiles clean.
- LESSON: never first-one-wins resource merging — always merge values by entry.

## v5.6 (versionCode 23) — 2026-10-12 — PROFILE EDITING + OPTIONAL EMAIL
- adeel's order: clients must be able to view/edit their profile after signup;
  email field added but OPTIONAL (not mandatory).
- DB (supabase_v5_patch6.sql): customers.email column; customer_signup accepts
  p_email; customer_login/customer_get return email; new
  customer_update_profile(p_phone, p_hash, p_name, p_email) (server-verified).
- App: Profile tab shows "Edit Profile" button + email display; edit modal
  (name, email optional, phone read-only); signup form has optional email
  field with format validation.

## v5.6 DELIVERY (2026-10-12 ~13:55 PKT)
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@7a7d10092e07a1f14bdd7b2b9720e97c65d17c5b/KashishBeautySalon.apk (commit 7a7d100, CDN+ aapt verified 23/5.6, internal config match)
- Source: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@7a7d10092e07a1f14bdd7b2b9720e97c65d17c5b/KashishSalon-source-v5.6.zip
- Notice: 5.6/23 + v5.6 URL (verified after reload)
- DB patch6: email column + customer_update_profile live (API-verified)
- CORS: send-push redeployed with Access-Control headers (verified)

## v5.7 (versionCode 24) — 2026-10-12 — NOTIFICATION PERMISSION POPUP FIX
- adeel's report: wife's phone showed NO notification permission popup on fresh install;
  his own phone's Settings > Notifications toggle was stuck OFF (greyed out).
- Fix: (1) in-app "Stay Updated!" dialog on first launch -> then system
  POST_NOTIFICATIONS request (ensures every new user sees a prompt);
  (2) notification channel created at startup so Settings shows it properly.
- APK: https://cdn.jsdelivr.net/gh/adimirza9977/kashish-beauty-salon@d4167bdd475e2f52f276dbe0d76c52a58442219d/KashishBeautySalon.apk (commit d4167bd, CDN+aapt verified 24/5.7)
- Notice: 5.7/24 + v5.7 URL (verified after reload 2026-10-12 ~14:24 PKT)
- DELIVERED to adeel 2026-10-12 ~14:24 PKT

## v5.8 (versionCode 25) — 2026-10-12 ~18:55 PKT
- adeel's report (sister's phone): (1) gallery picture upload shows "Upload failed — check internet"; (2) tapping a gallery picture does NOT enlarge it — stays small.
- Root cause of upload failure: Supabase storage bucket `salon-media` was NEVER created (API returned "Bucket not found") — the v3 migration SQL for it never ran. Uploads failed with 404, surfaced as "check internet".
- Fixes: (1) created `salon-media` bucket (public) + storage policies via SQL; (2) gallery lightbox — tap any picture to see it big fullscreen (close via × or tap outside); cursor pointer on gallery images.
- APK: pending GitHub upload — commit SHA TBD
- Notice: 5.8/25 (to be set after upload)
