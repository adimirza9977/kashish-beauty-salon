package com.kashish.salon;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            private boolean handleUrl(String url) {
                // Local app pages stay inside the WebView
                if (url.startsWith("file://") || url.startsWith("about:") || url.startsWith("data:")) {
                    return false;
                }
                // WhatsApp deep link: open directly in the WhatsApp app (most reliable).
                // If WhatsApp is not installed, fall back to the wa.me web link.
                if (url.startsWith("whatsapp://")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        String fallback = toWaMe(url);
                        if (fallback != null) {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                            } catch (ActivityNotFoundException ignored) {}
                        }
                    }
                    return true;
                }
                // Everything else (https, tel:, mailto:, ...) opens in the right app
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (ActivityNotFoundException e) {
                    // No app can handle it - stay put
                }
                return true;
            }

            // whatsapp://send?phone=923...&text=...  ->  https://wa.me/923...?text=...
            private String toWaMe(String waUrl) {
                try {
                    Uri u = Uri.parse(waUrl);
                    String phone = u.getQueryParameter("phone");
                    String text = u.getQueryParameter("text");
                    if (phone == null || phone.isEmpty()) return null;
                    String out = "https://wa.me/" + phone;
                    if (text != null && !text.isEmpty()) out += "?text=" + Uri.encode(text);
                    return out;
                } catch (Exception e) {
                    return null;
                }
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
        setContentView(webView);
        setupFileChooser();

        // Offer/discount phone notifications: background check every 4 hours
        // (also right now), plus runtime permission on Android 13+.
        NotifHelper.schedule(this);
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{"android.permission.POST_NOTIFICATIONS"}, 2001);
            }
        }
        new Thread(new Runnable() {
            @Override public void run() {
                NotifHelper.checkForUpdates(MainActivity.this);
            }
        }).start();

        // Instant push (FCM): register this device's token with the server
        try {
            KashishMessagingService.syncToken(this);
        } catch (Throwable ignored) {}
    }

    // File picker support for <input type="file"> (gallery / service picture uploads)
    private void setupFileChooser(){
        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params){
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose picture"), FILE_CHOOSER_REQ);
                } catch (ActivityNotFoundException e){
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQ && filePathCallback != null){
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null){
                results = new Uri[]{ data.getData() };
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
