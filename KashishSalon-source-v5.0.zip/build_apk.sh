#!/bin/bash
# Kashish Beauty Salon — manual APK build (aapt2 -> javac -> d8 -> zipalign -> apksigner)
# (Gradle daemon cannot run on this VM, so we compile manually.)
set -e
cd "$(dirname "$0")"
BASEDIR="$(pwd)"
OUT="$BASEDIR/build/apk-out"
SDK=/home/hatch/android-sdk
BT=$SDK/build-tools/34.0.0
PLATFORM=$SDK/platforms/android-34/android.jar
PROJ=android/app/src/main
KS=build/debug.keystore
KSPASS=android

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/dex"

echo "==> aapt2 compile (resources)"
$BT/aapt2 compile --dir "$PROJ/res" -o "$OUT/compiled_res.zip"

echo "==> aapt2 link"
$BT/aapt2 link -o "$OUT/app-unsigned.apk" \
  -I "$PLATFORM" \
  --manifest "$PROJ/AndroidManifest.xml" \
  --java "$OUT/gen" \
  -A "$PROJ/assets" \
  "$OUT/compiled_res.zip"

echo "==> javac"
find "$OUT/gen" -name "*.java" > "$OUT/sources.txt"
echo "$PROJ/java/com/kashish/salon/MainActivity.java" >> "$OUT/sources.txt"
javac -source 8 -target 8 -cp "$PLATFORM" -d "$OUT/classes" @"$OUT/sources.txt" 2>/dev/null || \
javac --release 8 -cp "$PLATFORM" -d "$OUT/classes" @"$OUT/sources.txt"

echo "==> d8 (dex)"
$BT/d8 --lib "$PLATFORM" --output "$OUT/dex" $(find "$OUT/classes" -name "*.class")

echo "==> add classes.dex + align + sign"
cp "$OUT/app-unsigned.apk" "$OUT/app.apk"
# add dex at root of apk
(cd "$OUT/dex" && zip -q -j "$OUT/app.apk" classes.dex)
$BT/zipalign -f -p 4 "$OUT/app.apk" "$OUT/app-aligned.apk"
cp "$OUT/app-aligned.apk" "$OUT/KashishBeautySalon.apk"
$BT/apksigner sign --ks "$KS" --ks-pass pass:"$KSPASS" --out "$OUT/KashishBeautySalon-signed.apk" "$OUT/KashishBeautySalon.apk"

echo "==> verify"
$BT/apksigner verify --print-certs "$OUT/KashishBeautySalon-signed.apk" | head -3
ls -la "$OUT/KashishBeautySalon-signed.apk"

# publish to your_files
cp "$OUT/KashishBeautySalon-signed.apk" ~/workspace/your_files/KashishBeautySalon.apk
echo "DONE -> ~/workspace/your_files/KashishBeautySalon.apk"

# ---- source backup (standing rule: every version gets a source zip) ----
VNAME=$(grep -o 'android:versionName="[^"]*"' "$PROJ/AndroidManifest.xml" | cut -d'"' -f2)
SRCZIP=~/workspace/your_files/KashishSalon-source-v${VNAME}.zip
rm -f "$SRCZIP"
(cd "$BASEDIR" && zip -qr "$SRCZIP" android build_apk.sh VERSION.md supabase_schema.sql supabase_v3.sql supabase_v5_security.sql supabase_v5_delta.sql -x "*/build/*")
ls -la "$SRCZIP"
echo "BACKUP -> $SRCZIP"
